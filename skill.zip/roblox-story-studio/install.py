"""install.py : install Roblox Story Studio into Claude Code for this user.
  python install.py            copy the skill to ~/.claude/skills/roblox-story-studio and the slash commands to
                               ~/.claude/commands, then run the setup check
  python install.py --check    only run the setup check
After installing, open Claude Code anywhere and type /rss-setup."""
import os, sys, shutil, subprocess
from pathlib import Path

here = Path(__file__).resolve().parent
home = Path.home() / ".claude"
dst = home / "skills" / "roblox-story-studio"
if "--check" not in sys.argv:
    if here != dst:
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(here, dst, ignore=shutil.ignore_patterns("__pycache__", ".git", "research", "*.zip"))
        print("skill ->", dst)
    (home / "commands").mkdir(parents=True, exist_ok=True)
    for c in (here / "commands").glob("*.md"):
        shutil.copy(c, home / "commands" / c.name)
    print("commands ->", home / "commands", "(" + ", ".join("/" + c.stem for c in sorted((here / "commands").glob("*.md"))) + ")")
subprocess.run([sys.executable, str(dst / "scripts" / "check_setup.py")])
print("\nNext: open Claude Code and type /rss-setup")
