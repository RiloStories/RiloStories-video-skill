# Long-form compilations

Four finished stories back to back make a 5-6 minute 16:9 video: a cheap long-form upload that feeds the channel.

1. Render the 16:9 versions FRESH (never reuse older 16:9 files after a remake): `render.py NN --land --from gen`,
   check the previews, `--from render`. Each 16:9 file must pass verify.
2. compilations.json:
   `{"A": {"vids": ["50","51","53","55"], "title": "...(<=100 chars)", "tags": "...", "thumb_head": "EVERYTHING GETS BANNED!",
   "names": {"50": "In This Town, Cars Are Banned", ...}}}`
3. `compile.py A` -> out/comp_A.mp4 + out/comp_A_meta.md (chapters start at 0:00). There is no narrated intro montage:
   it opens on "STORY 1 OF 4" (viewers skipped intros, and the user asked for it to go).
4. `sync_check.py comp A` must pass (each story's audio offset within 0.08 s).
5. `mkthumb_comp.py A`, `small.py out/comp_A.mp4 upload/comp_A_small.mp4`, upload as long form (11-publishing.md).
