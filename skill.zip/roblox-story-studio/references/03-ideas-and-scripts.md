# Ideas and scripts

## Finding ideas (do the research, don't guess)
1. `research.py mine` (if they have a channel): outliers at 3x the median are the strongest signal of what this audience
   wants. Make more of those (same premise shape, new ban/rule).
2. `research.py niche "in this town roblox"` (or their format) and `research.py channel <top competitor>`: list
   premises that got big views on small channels.
3. If trends are on: `research.py trends roblox` (+ `trends tiktok`). A trend is the same topic or character or sound
   showing up across several small channels with high views this month.
4. Pitch 10 ideas as one line each: the hook line, why it should work (evidence), and the twist. Let the user pick or
   say "pick for me" (then choose the 3 with the strongest evidence).

## "In this town" format (and the general version)
- Line 1 is the hook and starts exactly with "In this town," + an absurd rule: "In this town, birthdays are banned."
  Every video in the format starts like that (it once was missing on some videos and that had to be redone).
- Structure (75-110 s, 150-185 words/min): rule (0-3 s) -> why/how it's enforced, 2-3 funny consequences (3-25 s) ->
  the main character's problem (25-45 s) -> escalation with a clear visual set piece (45-70 s) -> twist or warm payoff
  (70-95 s) -> one-line CTA ("Subscribe if your town should ban homework next!").
- Concrete nouns over abstractions: every sentence should be drawable. "The baker priced a shoe in onions" beats
  "money became confusing".
- Clauses, not paragraphs: the animation changes on clauses. 8-14 words per sentence.
- Running cast (Leo/Sam/the Mayor style): recurring characters build the channel. Names are short and distinct.
- General Roblox stories: same rules, a different hook pattern ("What if...", "Every day at 3 pm, ..."), still a
  rule or mystery in the first line.

## Files
- `scripts/NN.txt`: one script line per row (the last row is the subscribe line).
- `scripts/NN_spk.txt`: `SPEAKER|text` rows (N = narrator). Dialogue inside a line: `N|And Leo said ## LEO|Wait!`
- Characters speak in their own voice (cast_voices); the narrator carries the story. Kids' lines are short.
- If the user gives a script: keep their words; only fix the hook if the format needs it and they agree.
- If the user gives a voiceover file: put it at vo/NN_vo.mp3 and skip mkvo; run words.py.

## Script checklist
- Hook in line 1 (format check above), under 3 s when read aloud.
- Each line has something to SHOW (write the shot list next to it before you continue).
- One surprise every ~10 s; the ending lands on the twist, then CTA within 3 s.
- No real brands, real people, or other creators' characters unless allowed (02-onboarding.md).
- Read the word count: 75-110 s at ~170 wpm is 210-310 words.
