# Publishing to YouTube

Uploading publishes the user's work: confirm the plan (which videos, which slots) before the first upload of a batch.
Never delete anything without being asked. Old versions: switch to Private (reversible) rather than deleting.

## Upload files
- Shorts: `make_upload.py NN` -> upload/NN_upload.mp4 (under 50 MB, for browser uploaders). Long form: `small.py`.
- Metadata per video in publish/NN_meta.md (title, description, tags, thumbnail path, slot).
- Description credits: paste the relevant lines of the project's CREDITS.md (CC-BY models, music, fonts) and a note that
  any money figure shown is YouTube's estimate, not a payout.

## Browser upload (works with the T3 preview browser or Claude in Chrome, signed in as the channel)
1. Open `https://studio.youtube.com/channel/<id>/videos/short?d=ud` (long form: `/videos/upload?d=ud`). This opens
   the upload dialog directly. Load the page fresh for every video (stale dialogs and overlays break the next one).
2. Upload the file to `ytcp-uploads-file-picker input[type=file]` (only that input; on other pages a file input may be
   the thumbnail loader).
3. Wait for `ytcp-uploads-dialog #title-textarea #textbox`. If the dialog renders with zero size or behind a dark
   overlay (background tab), bring the tab to the front and remove `tp-yt-iron-overlay-backdrop` elements.
4. Type the title and description into the two `#textbox` fields with real typing (clear first). execCommand does not
   work there.
5. Thumbnail: upload to `ytcp-uploads-dialog input#file-loader`.
6. Click `tp-yt-paper-radio-button[name=VIDEO_MADE_FOR_KIDS_NOT_MFK]` (NOT made for kids, unless the user says so).
7. `#next-button` x3. Expand `#second-container-expand-button` (Schedule). Open `#datepicker-trigger`, click into the
   date input, select all, type e.g. "Nov 18, 2026", Enter. Click the `#time-of-day-container input`, select all, type
   "4:00 PM", Enter. Read both back before continuing.
8. Click `#done-button`. If a "We're still checking your content" dialog appears, click "Got it" and click done again
   (for an immediate public publish it offers "Publish anyway").
9. Confirm the "Video scheduled ... will be set to public on <date> at <time>" dialog. A "Video published" message
   can be stale: open the video's edit page and check Visibility says Scheduled.
10. Audit at the end: the Content > Shorts list must show every new video as Scheduled on the right day.

## Rhythm
- The user's slots (project.json publish.slots), e.g. 3 Shorts/day at 07:00, 16:00, 20:00 local time. Fill the earliest
  free slots in story order; one long-form compilation every few days at a quiet slot.
- Pinned comment once a video is public (not before): e.g. "Which rule should be banned next?" to drive replies.
- Log every upload (id, slot) in CHANNEL.md.
