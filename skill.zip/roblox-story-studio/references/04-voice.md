# Voice: finding, cloning and casting voices

## Providers (scripts/tts.py)
| provider | cost | key | strengths |
|---|---|---|---|
| edge | free | none | 400+ Microsoft voices, many accents, decent energy. Good default to start. |
| kokoro | free, offline | none | runs locally (`pip install kokoro soundfile`), clean, consistent; fewer voices |
| fish | paid (free tier) | FISH_API_KEY | huge community voice library, expressive, `[excited]` style tags, cloning |
| elevenlabs | paid | ELEVENLABS_API_KEY | best quality and emotion, voice library, cloning, also makes music |
| openai | paid | OPENAI_API_KEY | 11 voices, `instructions` for delivery ("excited kids' cartoon narrator") |

## Finding the perfect voice (don't skip; the voice is half the channel)
1. Decide the role: narrator energy (warm storyteller / hyped / deadpan), age, accent, gender.
2. `voices.py search <provider> "<words>"`, e.g. `voices.py search fish "energetic narrator"`,
   `voices.py search elevenlabs "british storyteller"`, `voices.py search edge "en-GB"`.
3. Pick 4-6 candidates. `voices.py audition <provider> id1,id2,... "<a real line from their script>"` writes
   work/auditions/index.html. Ask the user to open it and pick (you can't hear audio). Audition with a line that has a
   joke, a question and a shout.
4. `voices.py set N <provider> <id> --speed 1.0` (narrator); set each character the same way. Kids 1.12-1.2x and
   --lufs -12, adults 1.0-1.15x. Fish narrators: `--style "[excited]"` lifts the energy.

## Cloning (only with the voice owner's permission)
- `voices.py clone fish "My Voice" sample1.mp3 sample2.mp3 --i-own-this-voice` (or elevenlabs). Samples: 1-3 min total,
  clean, no music, one speaker, varied sentences. Then `voices.py set N fish <new id>`.
- The flag exists on purpose: never clone a voice the user doesn't own or have written permission for (no celebrities,
  no other creators).
- Local cloning (advanced, free): F5-TTS or XTTS-v2 can clone from ~10 s of audio on a GPU; not wired in by default.

## One voice or many
Default (`voice.single_voice: true` in project.json): every character is spoken by the narrator's voice; it is the style that
performs for these Shorts and keeps the channel's voice recognisable. Set it to `false` and run `voices.py set <SPEAKER> ...`
for each character to cast different voices. Either way scripts keep the `SPEAKER|text` format.

## Making the voiceover
- `mkvo.py NN` reads scripts/NN_spk.txt and speaks each row with its speaker's voice; re-running only re-voices deleted
  line files (vo/NN_parts/lNN_*.wav), so to fix one line delete its file and re-run.
- It rejects takes far longer than the word count implies (hallucinated speech) and warns if the total is odd.
- Then `words.py NN` (faster-whisper word timings) -> work/words_NN.json. Check the words read right (names!).
- Pace: Shorts 150-185 wpm. mkvo prints the wpm.
