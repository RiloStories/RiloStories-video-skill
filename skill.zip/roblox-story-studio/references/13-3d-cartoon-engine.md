# The 3D cartoon / stickman engine (no Roblox needed)

`engines/inkbeat/` is a complete toon-shaded 3D cartoon engine for Remotion + React Three Fiber (MIT licence; keep
its LICENSE and THIRD_PARTY_NOTICES.md when you share it). It makes "3D stickman"/cartoon Shorts and calm 16:9 films
with beat-driven cameras, ink outlines, captions and deterministic rendering. Use it when the user picks the
"3D cartoon / stickman" format in onboarding, or wants videos that don't depend on Roblox Studio.

Start by reading `engines/inkbeat/SKILL.md` (it is the full guide) and copying `engines/inkbeat/templates/` into the
project. Everything else in this skill still applies: ideas and scripts (03), voices (04, tts.py works the same),
music (05, music.py), research, thumbnails and publishing. Props for it come from Blender (`assets/blender/toykit.py`,
export GLB) or the engine's own primitives. Keep one character family per film (its characters.md).
