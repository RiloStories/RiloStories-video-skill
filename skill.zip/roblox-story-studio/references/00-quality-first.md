# Quality first: how to finish a video in ONE review round

The old way took about 12 review rounds per video, because problems were found after rendering. The fix is to spend the
effort up front, where it's cheap, and to gate every expensive step behind a check that can fail.

## Where the effort goes (aim for this split)
| Stage | Share of effort | Why |
|---|---|---|
| Story, script and voice | 10% | a weak hook can't be rescued by animation |
| **Sets, props and cast** | **45%** | this is what viewers judge in the first second; bad models made earlier videos look cheap |
| Shot planning (spec) | 20% | every clause of narration gets a matching picture |
| Audit + previews | 15% | fixing a preview costs seconds, a re-render costs 10+ minutes |
| Render, mix, QA | 10% | mostly automatic |

## The gates (render.py enforces 1, 3 and 5)
1. **Library gate** (before any spec): every location in the script exists as a finished set in `RiloSets` or is built
   now (07-sets-and-assets.md). Every named prop exists in `RiloAssets`. Every speaking character exists in
   `CastAvatars` with a unique outfit (`cast.py check` says "none"). Check each new item on the asset bench
   (`asset_check.lua`) and look at the capture. Write a library note for it (`library.py note`).
2. **Shot-list gate**: before writing the spec, write the clause list. Every clause gets one line: what the viewer
   sees, where (set), who, what is moving, and the camera. If a clause has no picture, the script changes or a prop gets
   built. Read the list against the voiceover timings (show the words with times).
3. **Audit gate** (`render.py NN` stops if it fails): camera never inside geometry, no character inside furniture, no
   z-fighting in view, no void through windows or past set edges.
4. **Preview gate**: `render.py` stops after the preview contact sheets. Look at EVERY sheet with the rubric below.
   Fix the spec and re-run from `gen` until every tile passes. Only then `--from render`.
5. **Verify gate**: frame count, audio and video lengths, caption spot checks, flicker scan.

## Preview rubric (every tile must pass every line)
- The picture shows the clause being spoken (the named object/action is visible and readable at phone size).
- Faces: the speaker's face is visible, in the upper 45% of the frame, not cut by the frame edge, expression matches
  the line (never neutral on a joke or a shock).
- The location matches the words (an "inside the school" line is INSIDE a classroom set, never a school model seen
  from outside unless the line is about arriving).
- 8+ visible props or set details in medium and wide shots; nothing floating; held props in the hand.
- Light: bright and saturated by day, readable at night (no muddy frames, no blown-out lamps).
- Nothing cut in half by the camera, no character standing in a wall, no empty void.
- Variety: no two consecutive shots with the same framing and angle; at least one close-up every ~6 s.

## Things that caused rejected videos before (never repeat)
- Stale frames reused for a different length of voiceover: the 16:9 copy kept 47 s of picture under 76 s of voice.
  Always render into an empty frame folder (render.py does).
- A TTS take that hallucinated 25 s of a different story: mkvo/tts reject takes far longer than the word count implies.
  Still listen to the first and last line.
- "In this town" missing from the first line on some videos: the hook line is checked in 03-ideas-and-scripts.md.
- Captions out of sync in a compilation: segments must be cut with video and audio the same length (compile.py does).
- Exterior building models standing in for interiors ("a model of a school behind it"): use real interior sets.
- Every character in the same outfit: use cast.py; `cast.py check` must report no duplicates.
- Props at silly scales (a book bigger than a head): sizes vs the 5-stud character (07-sets-and-assets.md).
