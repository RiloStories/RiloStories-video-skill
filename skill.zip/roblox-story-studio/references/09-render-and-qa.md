# Render and QA

## One command
`python <skill>/scripts/render.py NN` (from the project folder) runs gen -> stage -> audit -> preview and STOPS so you
can look at the preview sheets. After fixing and re-running until clean: `render.py NN --from render` runs render ->
finish -> verify -> qa -> thumb. 16:9 copy for compilations: `render.py NN --land --from gen` (then `--from render`).

## What each check catches
- **audit** (run.py audit, at every beat midpoint in the real render state): CAMERA_INSIDE <part>, HEAD_IN/BODY_IN
  (character inside furniture or walls), ZFIGHT (two different surfaces in one plane: flickers in the render),
  VOID (rays that see nothing: open windows with no outside, set edges). Fix in the spec (move camera/actor/prop) or
  in the set (nudge one surface 0.02 studs; add Eng.windowView), then re-run.
- **preview sheets** (work/pv_NN_*.png): look at every tile with the rubric in 00-quality-first.md.
- **verify** (sync_check.py): frames present with no gaps, video length == audio length, 4 caption spot-check frames
  saved as work/sync_NN/<time>_<word>.jpg (each must show that word).
- **qa** (qa_sheet.py): work/qa_NN.jpg, one tile per beat with the spoken words under it. Read it like a comic: does
  every tile show what is said? flicker.py lists one-frame spikes (a repeating stride = a capture problem).
- Loudness: finish.py prints integrated LUFS (target about -14) and true peak (<= -1 dBTP).

## Watch it
Before scheduling, watch the first 5 seconds and the last 10 seconds of every video at full speed with sound, and
skim the middle at 2x. That is where hook problems, CTA problems and audio glitches hide.

## Re-render only what changed
run.py fills missing frames, so to fix a range delete those frame files and run
`run.py auto StoryNN 30 <frames dir> <first> <last>`, then `render.py NN --from finish`.
Never reuse frames after the voiceover or spec timing changed: use `--from render` (it clears the folder).
