# Render and QA

## One command
`python <skill>/scripts/render.py NN` (from the project folder) runs gen -> stage -> audit -> preview and STOPS so you
can look at the preview sheets. After fixing and re-running until clean: `render.py NN --from render` runs render ->
finish -> verify -> qa -> thumb. 16:9 copy for compilations: `render.py NN --land --from gen` (then `--from render`).

## What each check catches
- **audit** (run.py audit, at every beat midpoint in the real render state): CAMERA_INSIDE <part>, HEAD_IN/BODY_IN
  (character inside furniture or walls), ZFIGHT (two different surfaces in one plane: flickers in the render),
  VOID (rays that see nothing: open windows with no outside, set edges). Fix in the spec (move camera/actor/prop) or
  in the set (nudge one surface 0.02 studs; add Eng.windowView), then re-run.
- **preview sheets** (work/pv_NN_*.png): look at every tile with the rubric in 00-quality-first.md.
- **verify** (sync_check.py): frames present with no gaps, video length == audio length, 4 caption spot-check frames
  saved as work/sync_NN/<time>_<word>.jpg (each must show that word).
- **qa** (qa_sheet.py): work/qa_NN.jpg, one tile per beat with the spoken words under it. Read it like a comic: does
  every tile show what is said? flicker.py lists one-frame spikes (a repeating stride = a capture problem).
- Loudness: finish.py prints integrated LUFS (target about -14) and true peak (<= -1 dBTP).

## Watch it
Before scheduling, watch the first 5 seconds and the last 10 seconds of every video at full speed with sound, and
skim the middle at 2x. That is where hook problems, CTA problems and audio glitches hide.

## Re-render only what changed
run.py fills missing frames, so to fix a range delete those frame files and run
`run.py auto StoryNN 30 <frames dir> <first> <last>`, then `render.py NN --from finish`.
Never reuse frames after the voiceover or spec timing changed: use `--from render` (it clears the folder).

## Before a long render
- [ ] audit PASS and every preview tile looked at; [ ] project and place saved; [ ] PC plugged in, sleep set to Never,
  screen saver off; [ ] disk space for the frames (about 1 MB per 1080p jpg frame; a 100 s Short at 30 fps is ~3 GB);
  [ ] nobody needs the PC (the capture drives the screen).
- If the render crashes or the PC sleeps: run `run.py` again. It only fills missing frames, and it also treats
  0-byte frame files as missing (a crash leaves those), so nothing needs deleting by hand.
- After: watch the finished file once (first 5 s, last 10 s, middle at 2x), check LUFS, then put the music/asset credits
  in the description (see 11-publishing.md).

## Common visual bugs -> root-cause fix (fix at the source, then re-check EVERY shot that shares it)
| What you see | Usual cause | Fix |
|---|---|---|
| a character vanishes mid-shot | an animation key sits on the cut frame, or the actor was parked off-screen too early | end every in-shot key one frame before the cut; park others only AFTER the cut |
| we see the back of a head | camera on the wrong side (avatars face +Z at yaw 180) | put the camera where the character faces, or set `look=` |
| feet inside / above the floor | fixed y instead of the real floor height | use the set's floor height (Eng.seatY for sitting) |
| rider slides off its vehicle | rider and vehicle use different tween/key types | same interpolation for both |
| a prop floating alone in a close-up | a close-up of an object with no character | make it a two-shot with the speaker |
| camera inside geometry | prop or wall in the path | audit CAMERA_INSIDE: re-stage or move the camera |
| fog/smoke invisible or dark | not enough density, no self-light | raise density, add a soft glow |
| camera spins 360 degrees between two shots | angle wrap-around | convert with the nearest equivalent angle |
| motion smear into the next shot | blur carried over the cut | no blur on the cut frame |
