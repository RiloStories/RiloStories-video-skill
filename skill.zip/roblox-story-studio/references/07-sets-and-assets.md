# Sets and assets: where most of the effort goes

**The target look is real Roblox**: catalog avatars, textured Creator Store sets and props, real materials, Future
lighting and a cinematic grade. Not flat blocks. (Flat chunky toy styling is just an option for stylised channels.)
Tested on a real channel: block-built rooms and "a school model seen from outside" made videos look cheap. A free
Creator Store classroom, dressed and lit, with real avatars inside, looked like a top channel's video on the first try.
These rules come from side-by-side tests of every method (see the asset ladder).

## The asset ladder (try in this order)
1. **Library** - reuse: `ReplicatedStorage.RiloSets` (interiors/buildings), `RiloAssets` (props), `CastAvatars`.
   The library notes (`library.py index`) say what exists. Reuse saves hours and keeps the world consistent.
2. **Creator Store set** (interiors, buildings, vehicles, big furniture packs) - best realism per minute:
   search 5-10 candidates (`search_asset`, scope creator_store, free, assetType Model, e.g. "classroom", "town hall
   interior", "kitchen", "hospital room", "court room", "school hallway", "living room"), insert 3-5 into
   workspace.RSS_SetCandidates, run `set_import.lua` PASS=review (strips ALL scripts, anchors, lines them up), capture
   each from the inside camera it prints AND the reverse angle, score them with the rubric below, keep the winner
   with PASS=keep (+ NAME, YAW so the main wall faces -Z). Save the place.
3. **Kitbash from parts** (`Kitbash.lua`) - props and small furniture, with the real material for the thing (Wood,
   Fabric, Metal, Glass...). Cleanest result when no textured model fits; blocky-flat only for toy-like props. Use for anything a story needs that the store doesn't have: signs with text, rule boards, story-
   specific gadgets, food, simple animals. Pattern: big shapes first, then 1-3 details that sell it, then ink eyes.
   Worked examples: `assets/studio/example_kitbash_props.lua` (dog, alarm clock).
4. **AI mesh** (`generate_mesh`, Roblox) - organic shapes (animals, plush toys, food, vehicles with curves).
   Prompt suffix for the real look: "stylised Roblox game asset, clean textured low-poly, facing the viewer" (add "blocky toy, flat
solid colours" only for the toy style);
   `segmentation="explicit"` with the moving parts named; maxTriangles 2000-4000. Then `ai_mesh_normalize.lua`:
   turntable (find the front in one capture), recolour from the palette, part-built eyes, scale, save. Tested: shapes
   are good but prompt-following is unreliable. Set KEEP_TEXTURE = true to keep the generated texture (real-Roblox look);
   leave false only to force the flat toy palette. Prompt-following is unreliable (a "four-legged cat" came back standing up). Check the turntable
   against the prompt; max 2 attempts, then kitbash.
5. **Blender** (`assets/blender/toykit.py`) - smooth hero props and everything for the 3D cartoon engine (GLB export).
   Settings that look right: Standard view transform, roughness 0.8, bevel 0.012 m. Reaches Roblox only via Studio's
   3D Importer, so it's the last resort for Roblox videos.
   Not recommended: `generate_procedural_model` (tested: unreadable shapes, faces on the wrong side).

## Set rubric (score 0-2 each; keep sets scoring 12+ of 16, else dress or pick another)
1 reads instantly as the place (classroom = desks in rows + board + windows) | 2 enough detail: 12+ distinct props in
a medium shot (posters, shelves, clocks, plants, lockers, bins) | 3 scale fits 5-stud characters (door ~7 studs, desk
height ~2.5) | 4 colour: bright, saturated, not grey/brown mush | 5 has a ceiling and lights (no sky indoors) |
6 windows can get an outside view (Eng.windowView) | 7 space to stage 3-6 characters with camera room | 8 clean: no
floating parts, no z-fighting, no giant logos, no scripts left, no other game's branding | 9 exposure: a white-heavy set
(white walls, white furniture) must not glow or burn out. `set_import keep` measures it and stores `Expo`/`BloomThr` attributes that
`Eng.set` applies automatically (>=50% near-white: exposure -0.8, bloom threshold +0.5; >=30%: -0.4, +0.3). Look at one wide shot
of every new set at the engine's lighting; if white still glows, lower `Expo` by 0.2 and re-check.

## Dressing a set for a story (after import, per video)
- Story props on top (the rule sign on the board, the banned item on the desks).
- Make it lived-in: 3-6 extra props from the library near where the action happens.
- Outside views through every window (`Eng.windowView`, done by the town template).
- Light: interiors look best with bright "morning"/"noon"; add 1-2 PointLights only where a practical lamp is.

## Characters vs props scale (R15 avatar ~5 studs tall)
mug 0.5 | book 0.6x0.8 | phone 0.35x0.7 | backpack 1.4 tall | chair seat 1.8-2.0 high | desk 2.5 high | door 3.5x7 |
bed 4x7 | car 4.4x9 | bus 8x20 | dog (sitting) 2.5-3.2 | cat 1.6-2.2 | tree 14-22 | house 18-24 high.

## Every model goes in the library
Saving is ON by default: every scene (set) and prop you build is kept and noted so the next video reuses it instead of rebuilding it. To turn it OFF set `"library": {"save": false}` in project.json (or create the project with `--no-library-save`); the scripts then record nothing. Ask the user during setup, and say what is lost (no reuse, no catalogue) before turning it off.
After an asset passes `asset_check.lua`: `library.py note prop|set|cast <Name> "<what, where it fits>" --source ...
--capture X,Y,Z:LX,LY,LZ --tags a,b`. Point `library_dir` at an Obsidian vault folder to browse it with thumbnails.
Save the Studio place after adding to the library (it is where the models live).

## References (for quality, never copied)
`research.py niche "in this town roblox"` and `research.py frames <url>` give private reference frames of how top
channels dress interiors. Use them to measure (prop density, light, camera height), never trace or copy their sets,
characters or thumbnails. The skill ships a research summary in research/*.md.

## Brands, logos and posters (check every set, every time)
`set_import keep` prints a BRAND/POSTER CHECK list: names/text containing known brands (Netflix, YouTube, Spotify, Apple, game names...)
and every decal on a poster/picture/sign/screen/TV part. Look at each one in a capture. If it is a real logo or another game's art:
delete the decal, rename the part/text to something neutral ("Films", "Videos", "Music"), or put a plain picture over it. Examples
from the first house test: a TV with Netflix/YouTube/Spotify icons (removed, labels renamed), a copyrighted game poster inside a
voxel house (rejected the whole house). Blank wall frames and generic office signs are fine.

## Ceilings and sky gaps
`set_import keep` reports "sky above N% of the floor plan". Single-room shells open at the top (a classroom) get a ceiling slab
automatically. Houses and halls with roofs or gardens are NEVER capped (an earlier version put slabs on top of the roofs); instead
choose camera angles away from the gaps and let the audit's SKY_INDOORS check catch the rest. Raycasts only hit objects in
workspace, so measure before moving a set into ReplicatedStorage.
