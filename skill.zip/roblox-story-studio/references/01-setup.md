# Setup (once per computer)

Run `python <skill>/scripts/check_setup.py --install`. It installs what it can (Python packages; ffmpeg via winget
on Windows) and prints MANUAL lines for the rest. The manual steps:

1. **Windows PC** with a GPU that runs Roblox Studio well. The Roblox renderer captures the Studio window, so it is
   Windows-only. The 3D cartoon engine (engines/inkbeat) runs on Windows, macOS and Linux.
2. **Python 3.10+** (python.org, tick "Add python.exe to PATH").
3. **Roblox Studio**: install from create.roblox.com, sign in, create a new Baseplate place and save it to Roblox
   (File > Save to Roblox). This is the render place. Keep one place per channel.
4. **Studio MCP server**: in Studio, open the Assistant panel > settings > enable "MCP server". Then register it with
   Claude Code (one time):
   `claude mcp add Roblox_Studio -- "%LOCALAPPDATA%\Roblox\Versions\<version>\StudioMCP.exe" --stdio`
   (check_setup.py prints the exact path). Restart Claude Code; `claude mcp list` must show it.
5. **Bootstrap the place**: with the place open in Edit mode, run `assets/studio/bootstrap_place.lua` through the
   MCP `execute_luau` tool (datamodel Edit). It creates ReplicatedStorage.Rilo, R15Template, PreviewRig,
   WardrobeRS, RiloAssets, RiloSets and the RiloDirector LocalScript. Save the place.
5b. **Future lighting (manual, 10 seconds)**: Explorer > Lighting > Properties. In older Studio set **Technology = Future**; in the newest Studio there is no Technology property: set **LightingStyle = Realistic** (leave PrioritizeLightingQuality on). Scripts
   can't set this, and it is the single biggest quality upgrade (accurate shadows, reflections, light bleed). Save the place.
6. **Calibrate the capture** once per screen setup: open the place, maximise Studio, then
   `python scripts/run.py calib` (writes work/crop.json in the project). Redo it if you change monitor or window size.
7. **Power settings**: never sleep while plugged in (renders take 5-15 min each).

Optional:
- **Voices**: free with `edge` (online, no key) or `kokoro` (offline: `pip install kokoro soundfile`). Paid with
  Fish Audio, ElevenLabs or OpenAI: put the key in an env var (FISH_API_KEY, ELEVENLABS_API_KEY, OPENAI_API_KEY) or in
  `~/.rss-keys/<name>.key`. Keys are never written into the project or printed.
- **Blender 4+** with MCP for Blender (`uvx mcp-for-blender install-addon`), for Blender props and the 3D cartoon
  engine's assets.
- **Node 20+**, only for engines/inkbeat.
- **yt-dlp** (`pip install -U yt-dlp`) for research.py.

## Rules while rendering
- Don't touch the mouse, keyboard or the Studio window during a render (a stuck cursor once got into a whole video).
- Don't run heavy CPU jobs (encodes, other renders) at the same time: the capture stalls.
- Studio must be in Edit mode (stopped) before a render starts; run.py starts and stops Play itself.
- If the person needs the PC, stop rendering and resume later: run.py only fills missing frames.
