# Specs and animation (Roblox engine)

A video = `specs/specNN.py` (Python) -> `gen_story.py` -> `lua/StoryNN.lua`, played by the engine (assets/lua: Kit,
Eng, Sets, Lib, Kitbash) in Studio Play mode. Every frame is a pure function of time, so any frame can be re-rendered.

## Spec file
```python
from common import *                      # helpers: B, C, D2, MC, CW, T, actor, walk, wide, cu, two, mk, kp, sign, held, at ...
BANNER = "NO HOMEWORK!"; BANNERCOL = "60, 120, 220"; HEADLINE = "NO HOMEWORK!"; RED = '"HOMEWORK"'
PROPS = [MKM_LINE, FLAP_LINE, mk("dog", "Dog_Kit", 1.0), kp("book", 0.6, 0.8, 0.15, (200, 60, 60)), sign("rule", 6, 3, "NO HOMEWORK", (255,255,255), (200,40,40))]
POPS = {"yay": ("YAY!", (60, 150, 90))}    # speech-bubble pops: pop("yay", pos, age) inside fx
AMB = [(0, 5, "street", -26), (6, 12, "room", -25)]   # ambience per script-line range
BEATS = [ ... ]                             # one per clause, see below
```
Run `show.py`-style word dump first (print work/words_NN.json as `t word` lines) and pin beats to clause times.

## Beats: one picture per clause
`T(beat, t0, t1, line)` pins a beat to voiceover seconds; the shorthand builders all take (t0, t1, line, ...):
- `B(t0, t1, ln, [actors...], cx=68, light="noon", fx=..., sfx=[...])` wide/medium shot of the plaza/set area
- `C(t0, t1, ln, "leo", pose="talk", face="joy", x=68, z=4, d=(4.0, 3.2))` close-up on one face (push-in d0 -> d1)
- `D2(t0, t1, ln, "leo", "sam", ...)` two-shot; `MC(...)` mayor at the podium; `CW(...)` cheering crowd
- Raw beat: `dict(lines=(a, b), light=..., cam="{...}", acts="{A(...), ...}", fx="lua", sfx=[...])`.
Camera table options (Eng.buildCam): `p0/p1` positions + `l0/l1` look targets (dolly), `fov={f0, f1}`, `face="leo"`
(close-up that tracks a face, `d`, `h`, `side`, `back`), `two={"leo","sam"}`, `follow="leo", off={V3, V3}`,
`shake`, `dofR`, `ease=K.easeOut`, `roll0/roll1`.
Actor: `A(who, V3(x, y, z), {yaw=180, pose="talk", face="joy", face2="shock", fs=1.5, to=V3(...), m={0, 2}, look="sam"})`.
yaw 180 faces +Z (towards a camera on +Z); `to` walks (yaw automatic); `look` faces another actor.
Poses: stand talk hold point cheer wave sad scared shrug cry read sit sitread sitsad sitdesk hug hands bow kneel
(+ custom via `Eng.poses.name = function(t) return K.pose({RS={...}, LS={...}, N={...}}) end`).
Faces: neutral smile bigsmile grin joy happy calm relief sleepy tired heavy droop sleep sad tearful cry worried confused
scared scream shock gasp wide determined angry suspicious smirk wince dizzy blank. Talking swaps to an open-mouth face.
Lights: morning noon golden dusk night home (indoor close-ups wash out under "home": use "morning" for them).
`fx` is Lua run every frame of the beat with `t` (time), `u` (0..1 through the beat), `E`, `rel` (seconds into beat):
place props `P("book", hand("leo", 0, -0.7, -1.2))`, pops `pop("yay", pos, rel)`, wobble/hop by offsetting
`E.cast.leo.hrp.CFrame`.

## Shot grammar that reads well in 9:16
- Change the picture on every clause (about every 1.5-3 s); never hold one framing longer than ~4 s.
- The camera always moves a little (slow push or drift); big moves only on beats that need energy.
- Faces in the upper 45% of the frame (captions sit in the middle/lower area), 3/4 angles beat flat front-on.
- Mix: ~40% close-ups, ~40% mediums/two-shots, ~20% wides/establishing. An establishing shot for every new location.
- Show the named action: if the line says "he slams the door", show the door slam, not a face.
- Interiors are inside real sets (Eng.set): put actors at the set's spots (chairs, desks, the board), not floating.
- Indoors the camera stays inside the room (audit checks it). Doors/windows show the windowView outside.
- Seated characters: pose sit/sitdesk with y from `Eng.seatY(c)`; check hands vs desks in the preview.

## Portrait framing numbers (learned in the first real test)
- `fov` is the camera's field of view across the **portrait width**; the portrait height sees about 1.6x more. So indoors a wide
  fov (50+) shows a huge empty ceiling. Interior wides: fov 36-42, aim the look target ~1.5 studs below eye height.
- Close-ups: `d=(6.0, 4.4)` or wider; chest-high hoodies fill the frame fast. Tight faces only on shocks and punchlines.
- Avatars with fringe hair can hide the eyes: check every close-up tile; pick a different hair if the eyes aren't visible.
- Put a seated/standing character 4-8 studs in front of walls and cubbies, never against them (they look like they stand on them).
- A preview sheet that is entirely black means Studio wasn't on screen (screen off, window minimised, PC in use): re-run it.

## Building order inside a video
1. Sets present? (library gate) 2. Props present? 3. Cast built? 4. Write beats in clause order. 5. `render.py NN`
(gen, stage, audit, preview) -> fix -> repeat -> `--from render`.
