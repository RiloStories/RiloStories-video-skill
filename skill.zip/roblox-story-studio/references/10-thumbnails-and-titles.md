# Thumbnails and titles

## Shorts thumbnail (9:16, mkthumb_short.py)
One strong frame full bleed + a big two-line headline at the top: "<PREFIX>" (e.g. "IN THIS TOWN,") in white, the
topic in yellow with the key word in red ("BIRTHDAYS ARE BANNED!"). Frame choice: the most colourful prop beat, or
pin one in work/thumb_picks.json {"NN": beat_index}. Custom headline: work/thumb_text.json {"NN": "TEXT"}.
Check: readable at 10% size, a face with a strong expression or the key object, no small text, nothing in the bottom
quarter (UI covers it). Shorts show the thumbnail in the shelf and on the channel page; the first frame matters too
(the hook frame should be just as clear).

## Long form (16:9, mkthumb_comp.py)
Header ("IN THIS TOWN, SCHOOL GETS BANNED!") over four vertical frames from four of the videos, white rounded tiles.
compilations.json: "thumb_head" per compilation.

## Titles (<= 100 characters; check length)
Shorts: "<emoji> In This Town, <TOPIC> Is/Are BANNED <emoji><emoji> | Roblox Animation". Variants that won in this
niche: "In This Town, The LAST One Awake VANISHES", "...Taking A PHOTO Traps You FOREVER". Pattern: the rule in caps,
2 emojis max at the front/end, a clear stakes word. Long form: list the 3-4 bans + "(Compilation)".
Descriptions: line 1 restates the hook in the words people search, then 1-2 sentences, "Subscribe so you never miss
the next ... story!", 6-8 hashtags (#roblox #robloxanimation #inthistown #shorts #robloxstory ...).
