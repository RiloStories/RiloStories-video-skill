# Growing and earning (keep it honest)

No tool guarantees money; consistency, a clear format and quality do most of the work. Say that plainly to users.

- **Format first**: one recognisable format (hook pattern, cast, look) for 50+ videos before experimenting.
- **Rhythm**: 1-3 Shorts a day beats bursts. Use the scheduler; never miss the slots.
- **Read the data weekly**: `research.py mine`. Double down on outliers (3x median), drop topics that flop twice.
- **YouTube Partner Program** (check YouTube's current rules): roughly 1,000 subscribers plus either 4,000 public
  watch hours in 12 months or 10 million public Shorts views in 90 days. Under 18s need a parent or guardian to
  handle AdSense. Long-form compilations help watch hours.
- **Not made for kids** is the user's legal call (COPPA); story content aimed at a general audience is usually
  marked not made for kids, but ask the user and record their answer.
- **Originality**: YouTube demonetises reused or mass-produced content. Every video needs its own script, voice
  performance, scenes and edit. Don't upload near-duplicates; don't reuse other creators' footage.
- **Rights**: Roblox's terms let you make videos of your own Roblox experiences. Creator Store models and catalog
  clothing are used inside your own place. Credit model creators when a model is a big part of a scene. Music: use
  generated tracks (music.py) or licensed ones. Never use brands, film/TV/game characters or real people.
