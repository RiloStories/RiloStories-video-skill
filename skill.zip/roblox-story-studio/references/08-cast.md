# Cast: real-looking Roblox characters, all different

Tested: avatars built from real catalog clothing and accessories (HumanoidDescription) look like the characters in
top "In this town" channels; colour-block rigs look like placeholders. Build every speaking character as an avatar.

## Make the cast
1. Write a one-line brief per character in CHANNEL.md: age, vibe, outfit, hair ("10-year-old boy, red hoodie, messy
   brown hair, always curious"). Main characters get a signature item (a cap, glasses, a backpack) that stays the same
   in every video so viewers recognise them.
2. `cast.py auto leo "10 year old boy, red hoodie, messy brown hair"` picks a shirt, pants and hair from the catalog
   that no other character uses. Or search yourself: `cast.py search shirt "school uniform"`,
   `cast.py search pants "jeans"`, `cast.py search hair "ponytail"`, `cast.py search hat "police"` and
   `cast.py add leo --shirt ID --pants ID --hair ID --hats ID --skin 234,184,146`.
   Vary skin tones across the cast (e.g. 255,214,180 / 234,184,146 / 198,140,100 / 160,110,80 / 110,74,50).
3. `cast.py check` must say no duplicates. Then `cast.py build` (Studio open, Edit mode) builds them into
   ReplicatedStorage.CastAvatars; save the place. The town template uses an avatar automatically when its key matches
   the character's lowercase name (Leo -> leo, HeadTeacher -> headteacher, Kid1 -> kid1).
4. Look at them: put them on the asset bench (`asset_check.lua` with their names in RiloAssets, or capture the
   CastAvatars folder copies in a set) and check the clothes read at phone size.
5. Library note for each: `library.py note cast leo "Main character, red hoodie" --tags main`.

## Rules
- Classic decal faces (the engine swaps expressions on them). Avoid dynamic heads for speaking characters.
- Crowd/extra characters also get catalog clothes (6+ different outfits), never copies of the mains.
- No brand logos, no real people, no other games' characters on clothing.
- Trending characters (only if the user said yes in onboarding and the creator allows reuse): insert the free rig,
  strip scripts, store it in ReplicatedStorage as `<Name>Template`, and add a K.charVerity-style loader. Credit the
  rig's creator in the description.
