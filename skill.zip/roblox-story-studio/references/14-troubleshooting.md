# Troubleshooting (every entry happened for real)

| Symptom | Cause | Fix |
|---|---|---|
| "Edit datamodel is not available in Play mode" | Studio stuck in Play | MCP start_stop_play is_start=false, wait, retry |
| run.py "Studio window not found" | Studio minimised or a second Studio window | restore/maximise the right window; close other places |
| frames missing after a pass | capture stalled (CPU load, window covered, cursor moved) | run.py fix StoryNN 30 <dir>; keep the PC idle |
| a stuck mouse cursor in frames | mouse moved during render | delete those frames, re-render the range |
| captions drift in a compilation | segment audio and video lengths differed, or stale 16:9 frames | re-render 16:9 fresh; compile.py pads audio; sync_check.py comp |
| voiceover far too long | TTS hallucinated extra speech | tts.py retries automatically; delete the bad line file, re-run mkvo |
| a prop floats or sinks | flat props on a plaza need y >= 0.85; sitting characters float | adjust y; sit poses use Eng.seatY |
| a character faces away | yaw 180 = faces +Z (camera side) | set yaw or `look=` |
| teddy/bench/sofa face the wrong way | the model's own front differs | turntable it once, then store with front +Z |
| night wide shots blown out | street lamps too bright | remove lamps near the camera (STREET helper) or lower brightness |
| indoor close-ups washed out | "home" light on faces | use "morning" for indoor close-ups |
| hair floats above an avatar | all avatar parts anchored | anchor only HumanoidRootPart (cast_build does) |
| catalog search returns errors | rate limited | cast.py caches and backs off; wait a minute |
| YouTube upload dialog empty or blank | background tab didn't render; stale overlay | bring tab to front, remove backdrop overlay, reload page per upload |
| "Video published" after scheduling | stale message | open the edit page: Visibility must say Scheduled |
| Python heredoc patches lose "\n" | shell quoting | write patch files with the Write tool |
| free model brought scripts | Creator Store models can hide malicious code | set_import.lua deletes every script; never run inserted scripts |

## Captions
- **A name or tool is misspelled in the captions** ("profit" for "prop", "cloud code" for "Claude Code"): Whisper spells what it
  hears. words.py now keeps Whisper's timing but uses the script's spelling wherever the two line up (scripts/NN.txt must hold
  the final spoken text; set `voice.align_to_script` to false in project.json to turn it off). If it prints a WARNING that
  voice and script differ a lot, the voice skipped or added words: listen to it.

## Found in the first full test (Nov 2026)
- **A spec edit "did nothing" in the preview**: `render.py NN --only preview` runs ONLY the preview. After editing a spec run
  `--only gen`, `--only stage`, then `--only preview` (or `--from gen`, which runs everything after gen). Check the sheet
  actually changed before concluding a fix failed.
- **Black smear across one eye in a close-up**: usually a hair fringe mesh falling over the face. Pick hair without a fringe
  (`cast.py search hair "medium curly"`), re-run `cast.py build`, re-preview. Check every close-up tile at full size.
- **Finish step silently makes no video**: post2.py needs music. render.py now composes a track automatically; to choose
  one, run `music.py compose --mood <mood> --out work/music_NN.wav` before finishing.
- **Thumbnail step "No such file scripts/1.txt"**: video numbers are strings ("01"); fixed in mkthumb_short.py.
- Face textures are preloaded once (K.preloadFaces) so a face that swaps in mid-shot never draws half-loaded.
- **Interior glows white / burnt out**: white-heavy sets under the engine's bright presets. Check the set has `Expo`/`BloomThr`
  attributes (`set_import keep` sets them); otherwise set `m:SetAttribute("Expo", -0.8)` and `("BloomThr", 0.5)`.
- **Added ceiling floating on top of a roof**: fixed (see 07); remove `AddedCeiling` and cap only single-room shells.
