# Music and sound effects

## Music (scripts/music.py)
- `music.py compose --mood quirky --seconds 100 --seed 3` makes an original track (free, no claims). Moods: happy,
  quirky, wholesome, mystery, spooky, epic, chill, sad. Try 2-3 seeds and let the user pick by listening.
  Then `music.py assign NN music/<file>.wav`.
- `music.py elevenlabs "<prompt>"` (paid key) for richer tracks; `music.py musicgen "<prompt>"` local (slow).
- Library music (YouTube Audio Library etc.): put files in <project>/music/, check each licence, expect possible claims.
- Match the act: quirky/happy for silly rules, mystery/spooky for creepy rules, wholesome for the warm payoff.
- Level: post2.py ducks music under the voice (sidechain) and mixes to about -14 LUFS overall, matching popular Shorts.
  Music is clearly audible between lines; if a user says "louder music", raise `volume=2.9` in post2.audio_filter.

## SFX
- The spec puts SFX on beats: `sfx=[(rel_seconds, "name", dur_or_None, dB)]`. "name" is matched against files in
  <project>/sfx/ and audio.sfx_dirs (case-insensitive substring), else a synthesised stand-in is used (whoosh, thud,
  chime, slam, footsteps, click, gasp...). `syn:chime(1.2, (880, 1108))` calls the synth directly.
- Free SFX sources: Pixabay, Freesound (CC0 filter), Sonniss GDC bundles. Keep a licence note per pack.
- 6-8 story SFX per 20 s on the exact word, each about 8 dB under the voice peak. Ambience beds per scene (AMB in the
  spec: street, room, night...).
