# Onboarding: the first conversation with a new user

Ask in batches with the AskUserQuestion tool (max 4 questions per call), recommended option first. Don't ask what you
can find yourself.

## Batch 1: channel
1. "Do you already have a YouTube channel?" Yes (paste the link or @handle) / No, help me set one up / I'll do it later.
   - If they paste a link or name: find it (`research.py channel <url>`; if only a name, `yt-dlp "ytsearch5:<name>
     channel" --print channel_url`), confirm it's theirs, then run `research.py mine` and summarise what's working.
     Read 3-5 of their best videos' titles; note the format, voice, length and posting rhythm in CHANNEL.md.
   - If no channel: explain the setup in 5 steps (Google account, create channel, name + handle that says the format,
     profile picture + banner made with the thumbnail tools, "not made for kids" default in Settings > Upload defaults).
2. "What do you want to make?" **"In this town" Roblox stories (recommended)** / general Roblox story animation /
   3D cartoon / stickman videos (no Roblox) / something else (describe).
3. "How many videos per day?" 3 Shorts/day (recommended once the pipeline is set up) / 1/day / a few per week.

## Batch 2: look
4. "Where should subtitles go?" **Middle of the screen (recommended)** / safe zone (a bit lower, clear of the Shorts UI and phone edges) / lower third / bottom (above the Shorts UI).
5. "Subtitle colour?" **Yellow (recommended)** / white / a custom colour (hex).
6. "Voice for the narrator?" Free voice (edge or kokoro) / Fish Audio / ElevenLabs / clone my own voice. Then run
   `voices.py search` + `voices.py audition` with 4-6 candidates and let them pick by listening (you can't hear).

## Batch 3: ideas
7. "Should stories feature trending characters (for example a viral horror mascot) as guest stars?" Yes / No
   (recommended unless they know the character is free to use). Explain: trending characters bring views, but some
   belong to other creators. Only use ones whose creator allows it (free community rigs that say so); never use
   brands, film/TV/game characters, or real people.
8. "Check TikTok / YouTube trends for ideas?" **Yes (recommended)** / No. A real trend once drove a whole run of
   videos (a squishy dumpling trend).
8b. "Save the scenes and props I build so future videos reuse them?" **Yes (recommended)** / No. Yes keeps every set and
   prop in the library (faster next video, consistent world). No records nothing (`--no-library-save`, project.json
   `library.save=false`). Can be changed any time.
9. "Do you have files to use?" A script, a voiceover, your own music, character designs, a logo. Ask them to drop
   paths. If they give a script or a voiceover, skip those steps.

## Batch 4: make it theirs (originality; see references/16-viral-patterns.md)
10. "What's the rule of your world?" Their universe/format in one line ("In this town...", "In this school...",
    "In this universe..."). This becomes the hook prefix and CHANNEL.md's first line.
11. "Pick a signature": one colour per main character + one accessory, a light/colour mood, a signature phrase, a
    caption look (already chosen). Offer 3 options for each so they only have to pick; write them into CHANNEL.md.
12. "Do you want me to check your videos against the mute test (would a viewer know it's yours without your name)?"
    Offer to run it after the first 5 videos.

Then run `new_project.py <folder> --name ... --channel-url ... --format ... --caption-position ... --caption-color
... --viral-characters yes|no --trends yes|no [--no-library-save]`, then `check_setup.py --install`, then the Studio bootstrap
(01-setup.md). Save what you learn about the channel in CHANNEL.md and keep it updated after every upload batch.
