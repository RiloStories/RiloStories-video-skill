# What makes viral Roblox-style Shorts work (and how to stay original)

Source: a public video by another creator who had Claude study 58 viral and flop Shorts from 13 channels, plus our own
research (research/SHORTS_REPORT.md, measured with research.py). Treat the numbers as starting points: re-measure on your
own niche with `research.py frames` and put your channel's real numbers in project.json "pacing".

## The measured patterns
1. **Speech from second zero.** No intro, no logo. The first frame already shows the thing the rule is about.
2. **The first sentence is a rule:** "In this town / world / universe, <one strange rule>." One rule, in the first sentence.
3. **Fast voice, music under it.** Viral Shorts talk much faster than normal speech (the study reported ~260 words/min;
   normal speech is ~150). Our default band is 170-260 wpm; tighten sentences before speeding the voice up.
   Music runs under the voice the whole time (mixed about -14 LUFS overall, the music a few dB under the voice).
4. **A new shot about every 1.5-2.2 seconds and the camera never stops.** The camera pushes in on more than half the
   frames. In 9 of 10 channels the viral Shorts moved more than the same creator's weak ones. Brighter highlights also
   correlated with views.
5. **The rule is about something everyone has** (your first word, your last meal, your birthday, your name), so the
   viewer imagines themselves in that world. Best ones put a friend or loved one at stake.
6. **Story, not just a hook.** Copycat channels copy the hook and title but tell stories a third as long with no twist,
   or stop mid-scene. Always: rule -> consequences -> problem -> escalation -> twist/payoff.

`pacing.py NN` checks 1-4 and 6 from the spec before you render. `research.py` gives you the numbers for your niche.

## Staying original (YouTube reads frames, audio and words, not just titles)
A near-copy of an existing video looks like something the platform already has, so it has no reason to show it to anyone
new. Take the style, build your own world on top:
- **One world per channel** and stay in it (a town, a universe, a school). Let the AI find rules inside that world.
- **Characters with a silhouette**: one strong colour each, one signature accessory, recognisable as a black shape.
- **A light and colour signature**: pick a mood and keep it in every Short (set it in CHANNEL.md).
- **A voice that's only yours**, the same in every Short (voices.py), and **a signature phrase** ("In this town,").
- **Captions with a recognisable look** (position, colour, pop style).
- **The mute test**: mute a Short and hide the channel name. Would someone still know it's yours? If not, push the
  signature harder.
- **Improve one thing per Short** (this one the light, the next the characters) and write what you learned into
  CHANNEL.md and the library; after 10 videos the system is yours.
Never copy another channel's characters, scripts, thumbnails or footage; research frames are private study only.

## Workflow habits that save hours (adopted from the same study)
- **3-second test render first** (`render.py NN --test`): proves the capture and GPU work before an hour-long job.
- **Stills before video**: preview sheets of every beat cost seconds; a full render costs minutes.
- **Motion test, then the full render**: a 12 s test render catches cheat mistakes (floating props, wrong facing).
- **Keep every version**: render.py archives the previous file to out/versions/ so a better old version is never lost.
- **Don't ask "is it good?"** - the model says yes. Give a hunt list of exact things to find (references/09 critique list).
  One test found 15 problems in v1 (a camera inside a prop, characters passing through each other, a cut-off price tag)
  and v3 was clean.
- **After each video**: save every new character, prop and set to the library and write new rules into the skill notes.
- If a model stops on a safety check, continue carefully and describe characters as the user's own original design.
