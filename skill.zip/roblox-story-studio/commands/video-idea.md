---
description: Research-backed video ideas for this channel
argument-hint: [topic or 'surprise me']
---

Use the roblox-story-studio skill, references/03-ideas-and-scripts.md. Topic: $ARGUMENTS. Run research.py mine (if the channel exists), research.py niche for the format, and research.py trends if project.json ideas.check_trends is true. Pitch 10 ideas, one line each with the hook line, the evidence and the twist. Ask which to make (or offer to pick the best 3).
