---
description: Make a finished video: script, voice, scenes, render, QA, thumbnail
argument-hint: [idea | script text | file paths]
---

Use the roblox-story-studio skill and follow its workflow end to end for: $ARGUMENTS. If the user gave a script, voiceover, music or designs, use those files and skip those steps (ask them to attach or paste paths if they mentioned files you can't see). Read references/00-quality-first.md first; most of the effort goes into sets, props and cast, and every gate must pass before the full render. Stop and show the preview sheets' verdicts before rendering only if the user asked to review; otherwise fix until they pass. Do not upload; offer /upload at the end.
