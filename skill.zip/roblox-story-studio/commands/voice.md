---
description: Find, audition, clone or assign voices
argument-hint: [role or 'clone']
---

Use the roblox-story-studio skill, references/04-voice.md. Request: $ARGUMENTS. Search voices on the providers the user has (free: edge, kokoro), audition 4-6 with a real line, let the user pick by listening to work/auditions/index.html, then voices.py set. Cloning only with --i-own-this-voice and the user's confirmation that they own or have permission for the voice.
