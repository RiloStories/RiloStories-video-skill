---
description: Create a real-looking Roblox character with a unique outfit
argument-hint: <key> "<brief>"
---

Use the roblox-story-studio skill, references/08-cast.md. Character: $ARGUMENTS. Use cast.py auto (or search + add for more control), make sure cast.py check shows no duplicates, cast.py build, look at the result in a capture, then library.py note cast. Show the user the capture.
