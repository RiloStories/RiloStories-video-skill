---
description: Build a 16:9 long-form compilation from four stories
argument-hint: [video numbers]
---

Use the roblox-story-studio skill, references/12-compilations.md. Stories: $ARGUMENTS. Render fresh 16:9 versions, add the entry to compilations.json, compile.py, sync_check.py comp, mkthumb_comp.py, small.py. Offer /upload.
