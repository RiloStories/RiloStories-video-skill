---
description: Find, import, score and save a scene set (interior or exterior)
argument-hint: "<place, e.g. classroom, town hall inside, hospital room>"
---

Use the roblox-story-studio skill, references/07-sets-and-assets.md. Place: $ARGUMENTS. Search the Creator Store for 5-10 candidates, insert 3-5, run set_import.lua review, capture inside views from both directions, score with the set rubric, keep the best (NAME, YAW so the main wall faces -Z), dress it, add a window view, check it with characters inside, save the place, and write a library note with a capture. Show the user the best capture.
