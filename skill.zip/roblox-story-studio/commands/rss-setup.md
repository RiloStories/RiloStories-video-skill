---
description: Set up Roblox Story Studio for a channel: onboarding questions, installs, Studio bootstrap
---

Use the roblox-story-studio skill. Run the onboarding in references/02-onboarding.md (ask in batches with AskUserQuestion, recommended options first: subtitles middle, yellow; trends yes). Then new_project.py with the answers, check_setup.py --install (explain each MANUAL line simply), and the Studio bootstrap in references/01-setup.md. Finish with a short summary of what is ready and what the user still has to do.
