---
description: Analyse a YouTube channel or niche: what works and why
argument-hint: <channel url | name | niche words>
---

Use the roblox-story-studio skill. Target: $ARGUMENTS. If it is a name, find the channel URL with yt-dlp search and confirm it. Run research.py channel (and research.py frames on its 2-3 best Shorts for pacing and shot rate). Report: what the channel posts, median and outlier views, winning title patterns, hook formulas, pacing numbers, posting rhythm, and 5 concrete things to copy in spirit (never copy their characters or footage). Save the summary to work/research/.
