---
description: Schedule finished videos to YouTube in the channel's slots
argument-hint: [video numbers]
---

Use the roblox-story-studio skill, references/11-publishing.md. Videos: $ARGUMENTS. List the plan (video, title, slot) and get the user's OK before uploading. Then upload each with a fresh page load, set not made for kids (unless the user said otherwise), thumbnail, schedule, and verify the Scheduled status. Log ids in CHANNEL.md.
