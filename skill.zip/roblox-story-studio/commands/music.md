---
description: Make an original background track
argument-hint: [mood] [video number]
---

Use the roblox-story-studio skill, references/05-music-and-sfx.md. Request: $ARGUMENTS. Generate 3 seeds with music.py compose in the right mood (or elevenlabs/musicgen if set up), let the user pick by listening, then music.py assign.
