---
name: roblox-story-studio
description: End-to-end studio for animated YouTube Shorts and long-form videos made in Roblox Studio (e.g. "In this town..." story channels) or as 3D cartoon/stickman videos. Covers onboarding a channel, setup and installs, niche/channel/trend research, video ideas, scripts, finding/auditioning/cloning voices (Fish, ElevenLabs, OpenAI, free Edge, offline Kokoro), original music, real-looking Roblox casts from catalog clothing, interior sets, kitbashed/AI/Blender props in one consistent style, an asset library, shot planning, scene glitch audits, rendering via the Studio MCP, captions/SFX/mix, QA, thumbnails, titles, scheduling uploads and compilations. Use it whenever someone wants to make, plan, fix, render, voice, upload or grow Roblox animation videos or story Shorts, analyse a YouTube channel or niche for video ideas, build Roblox scenes/characters for a video, or start a faceless animation channel, even if they don't name the skill.
---

# Roblox Story Studio

A production system for animated story videos. It was built and battle-tested on a real channel that posts 3 Roblox
Shorts a day; every rule below exists because something went wrong without it.

**The core idea: spend the effort on scenes and casts, and check before rendering, so a video is right after one
review round.** Read `references/00-quality-first.md` before making any video.

## Commands (installed by install.py; each is a short prompt that points back here)
| command | does |
|---|---|
| /rss-setup | onboarding questions + installs + Studio bootstrap |
| /video-idea [topic] | research-backed ideas: your channel's outliers, the niche, trends |
| /make-video [idea or script or files] | idea -> script -> voice -> sets/cast/props -> spec -> audit -> render -> QA -> thumbnail |
| /analyse-channel <url or name> | what works on a channel, titles, pacing, posting rhythm |
| /new-character "<brief>" | a real-looking avatar from catalog clothes, unique outfit, library note |
| /build-set "<place>" | find, import, score, dress and save an interior/exterior set |
| /voice | find, audition, clone or assign voices |
| /music [mood] | original track for a video |
| /upload [videos] | schedule uploads in the channel's slots |
| /compilation | 16:9 long-form from four stories |

## Workflow for one video (details in the numbered references)
1. **Project**: find project.json (cwd or parents). No project: run onboarding (`references/02-onboarding.md`).
2. **Idea + script** (03): hook line rules for the format, clause-level writing, the shot list beside it.
   If the user gave a script or voiceover file, use it.
3. **Voice** (04): `mkvo.py NN` -> `words.py NN`. Listen for problems the checks flag.
4. **Library gate** (07, 08): every location is a real set in the library or gets built now (Creator Store import,
   kitbash or AI mesh + normalise); every prop exists; every speaking character is a catalog avatar with a unique
   outfit. Check each on the asset bench. Library note for each new item. This is where most of the time goes.
5. **Spec** (06): one beat per clause pinned to voice times; real set spots; faces upper half; varied shots.
6. **render.py NN**: gen, stage, audit (must PASS), preview sheets (look at every tile with the rubric), fix, repeat.
   Then `render.py NN --from render` (render, finish, verify, qa, thumbnail).
7. **Music** (05) and **title/description** (10). **Upload/schedule** (11) after the user confirms the plan.
8. **Compilations** (12) from four finished stories.
For the 3D cartoon/stickman format, follow `references/13-3d-cartoon-engine.md` (engines/inkbeat).

## Scripts (python <skill>/scripts/<name>.py, run from the project folder)
setup: check_setup new_project | research: research | voice: tts voices mkvo words | music: music |
cast/assets: cast library | story: gen_story (spec -> Lua) | render: stage run render | post: finish post2 cta
make_upload small compile | QA: sync_check qa_sheet flicker | thumbs: mkthumb_short mkthumb_comp.
Studio snippets (run with MCP execute_luau, Edit): assets/studio/bootstrap_place, set_import, cast_build (via cast.py),
ai_mesh_normalize, asset_check, example_kitbash_props. Engine: assets/lua (Kit, Eng, Sets, Lib, Kitbash, director).
Blender: assets/blender/toykit.py. Templates: assets/templates/story_template_town.lua.

## Non-negotiables
- Never schedule, publish, delete or make public without the user's go-ahead for that batch. Uploads are
  "not made for kids" unless the user says otherwise.
- Never use other creators' footage, characters, brands, real people or voices without permission; research frames
  are private study material.
- API keys come from env vars or ~/.rss-keys; never write them into files or print them.
- Don't render while the user is using the PC (the capture needs the screen); stop when they ask.
- Free Creator Store models: strip every script before use (set_import.lua does).
- Keep CHANNEL.md and the library notes current; they are the memory of the channel.
- If a download, site, tool or permission is blocked or failing: STOP and tell the user what failed and the options.
  Do not quietly work around it (no scraping past a login, no swapping in a different asset without saying so).
- Credit what needs crediting: keep `CREDITS.md` in the project (name, author, licence, link) for every CC-BY model, font,
  track or sample, and paste it into the video description. Never redistribute assets you don't own (catalog items,
  other people's rigs or faces); tell the user to download those from the original authors.
- Before any big look change (lighting, time of day, new set style) render 5-10 stills, show them, and save the place
  first so it can be rolled back.
