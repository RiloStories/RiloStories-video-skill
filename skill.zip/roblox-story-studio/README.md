# RiloStories Video Skill

(Skill folder name: `roblox-story-studio`. Made by Rilo Stories. Free. Built for Claude Code.)

Use **Claude Code** (terminal or the Code tab), not a normal Claude chat: the skill needs to run commands on your computer, and a normal chat cannot.

Install: tell Claude Code "install this skill from https://github.com/RiloStories/RiloStories-video-skill", then run the setup command (`/rss-setup`).

Discord (help + community): https://discord.gg/33Yu9YGkM

A Claude Code skill that runs a whole animated-Shorts channel with you: research, ideas, scripts, voices, music,
Roblox sets and characters, rendering, quality checks, thumbnails, uploads and compilations. It also includes a 3D
cartoon/stickman engine for videos without Roblox.

## Install
1. Install Claude Code, Python 3.10+ and Roblox Studio (Windows for Roblox renders).
2. Unzip, then run `python install.py`.
3. Open Claude Code and type `/rss-setup`. It asks about your channel and style, installs what it can, and tells you
   exactly what to click for the rest.

## Commands
`/rss-setup` `/video-idea` `/make-video` `/analyse-channel` `/new-character` `/build-set` `/voice` `/music` `/upload`
`/compilation`

## What it needs
Free to run: edge/kokoro voices, the built-in music composer, Roblox Studio, ffmpeg, Python packages (auto-installed).
Optional paid: Fish Audio / ElevenLabs / OpenAI voices, ElevenLabs music.

## Licences
Skill code: see LICENSE. engines/inkbeat is MIT (its LICENSE and THIRD_PARTY_NOTICES.md must stay with it).
Fonts are downloaded at setup under the SIL Open Font License. You are responsible for the rights to anything you add
(music, models, voices) and for following YouTube's and Roblox's terms.
