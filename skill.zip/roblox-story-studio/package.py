"""package.py [version] : build the sellable zip (dist/roblox-story-studio-<version>.zip).
Leaves out research/ (other creators' frames: private study only, never redistribute), caches, git data and any key
files. Includes engines/inkbeat with its LICENSE and THIRD_PARTY_NOTICES.md (required by its MIT licence)."""
import sys, zipfile, re
from pathlib import Path

root = Path(__file__).resolve().parent
ver = sys.argv[1] if len(sys.argv) > 1 else "1.0.0"
out = root / "dist" / f"roblox-story-studio-{ver}.zip"
out.parent.mkdir(exist_ok=True)
skip_dirs = {"research", "__pycache__", ".git", "dist", "node_modules"}
n = 0
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob("*")):
        rel = p.relative_to(root)
        if p.is_dir() or any(part in skip_dirs for part in rel.parts):
            continue
        if p.suffix in (".key", ".pyc") or re.search(r"(secret|token|\.env)", p.name, re.I):
            continue
        z.write(p, Path("roblox-story-studio") / rel); n += 1
print(out, n, "files", round(out.stat().st_size / 1048576, 2), "MB")
