"""Shot helpers for spec files (import with `from common import *`). Positions are x,z on the plaza floor (y = 0); who = cast key ("leo", "p1", ...)."""

def _a(who, x, z, pose="stand", face="neutral", yaw=180, **o):
    y = o.pop("y", 0)
    extra = "".join(f", {k} = {v}" for k, v in o.items())
    return f'A({who}, V3({x}, {y}, {z}),{{yaw = {yaw}, pose = "{pose}", face = "{face}"{extra}}})'

def actor(who, x, z, pose="stand", face="neutral", yaw=180, **o):
    return _a(who if who in ("leo", "sam", "mayor", "head", "bell", "mum", "dad", "gran", "pete", "verity") else f'"{who}"', x, z, pose, face, yaw, **o)

def walk(who, x0, z0, x1, z1, m=4.0, pose="stand", face="smile"):
    w = who if who in ("leo", "sam", "mayor", "head", "bell", "mum", "dad", "gran", "pete", "verity") else f'"{who}"'
    return f'A({w}, V3({x0}, 0, {z0}), {{to = V3({x1}, 0, {z1}), m = {{0, {m}}}, pose = "{pose}", face = "{face}"}})'

def acts(*a): return "{" + ", ".join(a) + "}"

def cu(lines, who, x=68, z=4, pose="talk", face="neutral", light="noon", d=(4.0, 3.2), fx=None, sfx=None, frac=None, face2=None, fs=None, yaw=180, pops=None):
    """close-up on one character"""
    w = who if who in ("leo", "sam", "mayor", "head", "bell", "mum", "dad", "gran", "pete", "verity") else f'"{who}"'
    o = {}
    if face2: o["face2"] = f'"{face2}"'; o["fs"] = fs or 1.5
    d_ = dict(lines=lines, light=light, cam=f"{{face = {w}, d = {{{d[0]}, {d[1]}}}, fov = {{40, 34}}, h = 0.5, look = 0.9}}", acts=acts(actor(who, x, z, pose, face, yaw, **o)))
    if fx: d_["fx"] = fx
    if sfx: d_["sfx"] = sfx
    if frac: d_["frac"] = frac
    return d_

def two(lines, a, b, ax=66, bx=70, z=4, pa="talk", pb="stand", fa="smile", fb="smile", light="noon", d=(7.0, 5.6), fx=None, sfx=None, frac=None):
    aw = a if a in ("leo", "sam", "mayor", "head", "bell", "mum", "dad", "gran", "pete", "verity") else f'"{a}"'
    bw = b if b in ("leo", "sam", "mayor", "head", "bell", "mum", "dad", "gran", "pete", "verity") else f'"{b}"'
    d_ = dict(lines=lines, light=light, cam=f"{{two = {{{aw}, {bw}}}, d = {{{d[0]}, {d[1]}}}, fov = {{46, 40}}, h = 0.6, look = 0.9}}",
              acts=acts(actor(a, ax, z, pa, fa, 225), actor(b, bx, z, pb, fb, 135)))
    if fx: d_["fx"] = fx
    if sfx: d_["sfx"] = sfx
    if frac: d_["frac"] = frac
    return d_

def wide(lines, actors, light="noon", p0="V3(62, 4.4, 14)", p1="V3(72, 4.8, 12)", l0="V3(70, 2.4, 2)", fov=(54, 48), fx=None, sfx=None, frac=None):
    d_ = dict(lines=lines, light=light, cam=f"{{p0 = {p0}, p1 = {p1}, l0 = {l0}, fov = {{{fov[0]}, {fov[1]}}}, dofR = 16}}", acts=acts(*actors))
    if fx: d_["fx"] = fx
    if sfx: d_["sfx"] = sfx
    if frac: d_["frac"] = frac
    return d_

def mayor_cu(lines, face="determined", pose="talk", light="morning", fx=None, sfx=None, frac=None, face2=None):
    o = f', face2 = "{face2}", fs = 2.0' if face2 else ""
    d_ = dict(lines=lines, light=light, cam="{face = mayor, d = {5.0, 3.8}, fov = {42, 36}, h = 0.5, look = 0.9, shake = 0.04}",
              acts=f'{{A(mayor, MP, {{yaw = 180, pose = "{pose}", face = "{face}"{o}}})}}')
    if fx: d_["fx"] = fx
    if sfx: d_["sfx"] = sfx
    if frac: d_["frac"] = frac
    return d_

def crowd_wide(lines, pose="cheer", face="joy", light="golden", fx=None, sfx=None, frac=None):
    ac = [actor(k, x, z, pose, face if isinstance(face, str) else face[i % len(face)]) for i, (k, x, z) in enumerate([("p1", 62, 2), ("p2", 66, 4), ("p3", 70, 2), ("p4", 74, 4), ("p5", 78, 2), ("p6", 58, 4)])]
    return wide(lines, ac, light=light, p0="V3(60, 4.0, 14)", p1="V3(76, 4.4, 12)", l0="V3(68, 2.4, 0)", fov=(56, 50), fx=fx, sfx=sfx, frac=frac)

def ending(line, others=("p1", "p2", "p3")):
    ac = [actor("leo", 67, 8, "wave", "joy"), actor("sam", 72.6, 8, "wave", "joy")] + [actor(o, x, z, "cheer", "joy") for o, (x, z) in zip(others, [(60, 0), (64, 2), (76, 2)])] + [actor("mayor", 74, -2, "proud", "bigsmile")]
    return dict(lines=(line, line), light="golden", cam="{p0 = V3(64, 4.2, 22), p1 = V3(66, 6.4, 30), l0 = V3(70, 3.6, 4), fov = {50, 56}, ease = K.easeOut, dofR = 30}",
                acts=acts(*ac), sfx=[(0.5, "syn:chime(2.4, (659, 880, 1047, 1319))", None, -15)])

def title_shot(line=0, text_face="scream", fx=None):
    return mayor_cu((line, line), face=text_face, sfx=[(0.15, "deep hit", 1.6, -13)], fx=fx)

# ---- model-prop helpers (RiloAssets models; base sits at y, front faces camera when yaw=0) ----
MKM_LINE = 'local function mkM(key, nm, sc, col) local lib = RS:FindFirstChild("RiloAssets"); local src = lib and lib:FindFirstChild(nm); local m; if src then m = src:Clone() else m = Instance.new("Model"); m.Name = nm; local b = K.part(m, "Body", V3(2, 2, 2), CF(0, 1, 0), rgb(255, 0, 255), M.SmoothPlastic); m.PrimaryPart = b; warn("missing asset " .. nm .. " (magenta box placeholder)") end; m:ScaleTo(sc); for _, d in ipairs(m:GetDescendants()) do if d:IsA("BasePart") then d.Anchored = true; d.CanCollide = false end end; if col then local b = m:FindFirstChild("Body", true); if b then b.Color = col end end; m.Parent = stage; local o = {m = m, model = true, L = {}}; local wl, wr = m:FindFirstChild("WingL", true), m:FindFirstChild("WingR", true); if wl and wr then o.wl, o.wr = wl, wr; o.rl = m.PrimaryPart.CFrame:ToObjectSpace(wl:GetPivot()); o.rr = m.PrimaryPart.CFrame:ToObjectSpace(wr:GetPivot()) end; E.props[key] = o end'
FLAP_LINE = 'E.flap = function(key, cf, a) local o = E.props[key]; if not o or not o.wl then return end; o.wl:PivotTo(cf * o.rl * CFrame.Angles(0, 0, a)); o.wr:PivotTo(cf * o.rr * CFrame.Angles(0, 0, -a)) end'
def mk(key, asset, scale=1.0, col=None):
    return 'mkM("%s", "%s", %s%s)' % (key, asset, scale, (", " + col) if col else "")
def pm(key, x, y, z, yaw=0, extra=""):
    """Lua statement placing model prop `key` with its base at (x,y,z); yaw 0 faces the camera (+Z)."""
    return 'P("%s", CF(V3(%s, %s, %s)) * CFrame.Angles(0, rad(180 + %s), 0)%s)' % (key, x, y, z, yaw, extra)

# ---- clause-level beats: T(beat, t0, t1, line) pins a beat to absolute voiceover seconds ----
def T(d, t0, t1, ln):
    d["t"] = (t0, t1); d["lines"] = (ln, ln); return d
def V(x, y, z): return "V3(%s, %s, %s)" % (x, y, z)
def hand(who, dx=0.0, dy=0.6, dz=-1.5, extra=""):
    """Lua CFrame in front of a character's hands (for held props)"""
    return "E.cast.%s.hrp.CFrame * CF(%s, %s, %s)%s" % (who, dx, dy, dz, extra)

# ---- compact clause helpers (Nov 15 remake) ----
def _cam(cx=68, h=4.4, d=14, fov=(54, 48)):
    return dict(p0="V3(%s, %s, %s)" % (cx - 6, h, d), p1="V3(%s, %s, %s)" % (cx + 4, h + 0.4, d - 2), l0="V3(%s, 2.6, 2)" % cx, fov=fov)
def B(t0, t1, ln, actors, cx=68, light="noon", fx=None, sfx=None, fov=(54, 48), h=4.4, d=14, p0=None, p1=None, l0=None):
    c = _cam(cx, h, d, fov)
    return T(wide((ln, ln), actors, light=light, p0=p0 or c["p0"], p1=p1 or c["p1"], l0=l0 or c["l0"], fov=fov, fx=fx, sfx=sfx), t0, t1, ln)
def C(t0, t1, ln, who, pose="talk", face="neutral", light="noon", x=68, z=4, d=(4.0, 3.2), fx=None, sfx=None, face2=None, yaw=180):
    return T(cu((ln, ln), who, x, z, pose, face, light, d=d, fx=fx, sfx=sfx, face2=face2, yaw=yaw), t0, t1, ln)
def D2(t0, t1, ln, a, b, ax=66, bx=70, z=4, pa="talk", pb="stand", fa="smile", fb="smile", light="noon", d=(7.0, 5.6), fx=None, sfx=None):
    return T(two((ln, ln), a, b, ax, bx, z, pa, pb, fa, fb, light, d, fx, sfx), t0, t1, ln)
def MC(t0, t1, ln, face="determined", pose="talk", light="morning", fx=None, sfx=None, face2=None):
    return T(mayor_cu((ln, ln), face, pose, light, fx, sfx, face2=face2), t0, t1, ln)
def CW(t0, t1, ln, pose="cheer", face="joy", light="golden", fx=None, sfx=None):
    return T(crowd_wide((ln, ln), pose, face, light, fx, sfx), t0, t1, ln)
def grp(key, parts):
    s = ", ".join('box(stage, "%s", V3(%s, %s, %s), CF(%s, %s, %s), rgb(%s, %s, %s), M.%s)' % (n, *sz, *off, *col, mat) for n, sz, off, col, mat in parts)
    return 'E.props.%s = {L = {%s}}' % (key, s)
def kp(key, sx, sy, sz, col, mat="SmoothPlastic", name=None):
    return 'E.props.%s = K.part(stage, "%s", V3(%s, %s, %s), CF(), rgb(%s, %s, %s), M.%s)' % (key, name or key, sx, sy, sz, *col, mat)
def lab(key, text, fg, bg, face="Front"):
    return 'K.label(E.props.%s, "%s", rgb(%s, %s, %s), rgb(%s, %s, %s), Enum.NormalId.%s)' % (key, text, *fg, *bg, face)
def sign(key, sx, sy, text, fg, bg, thick=0.3):
    return kp(key, sx, sy, thick, bg) + "; " + lab(key, text, fg, bg, "Front") + "; " + lab(key, text, fg, bg, "Back")

STREET = 'for _, d in ipairs(street:GetChildren()) do if d.Name == "Lamp" then local pp = d:GetPivot().Position; if pp.Z > 6 and pp.Z < 40 and pp.X > 45 and pp.X < 100 then d:Destroy() end end end'
FACE = ' * CFrame.Angles(0, rad(180), 0)'
def crowd(pose, face, n=5):
    xs = [(62, 2), (66, 5), (70, 2), (74, 5), (78, 2)]; ks = ["p1", "p2", "p3", "p4", "bell"]
    fs = face if isinstance(face, list) else [face]
    return [actor(ks[i], xs[i][0], xs[i][1], pose, fs[i % len(fs)]) for i in range(n)]
def held(key, who, dx=0.0, dy=0.6, dz=-1.4, face=True):
    return 'P("%s", %s%s)' % (key, hand(who, dx, dy, dz), FACE if face else "")
def at(key, x, y, z, yaw=180):
    return 'P("%s", CF(V3(%s, %s, %s)) * CFrame.Angles(0, rad(%s), 0))' % (key, x, y, z, yaw)
