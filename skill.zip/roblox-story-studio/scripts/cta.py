"""Subscribe outro frames: custom line on top, a YouTube-style Subscribe button that pops in, gets pressed, turns into 'Subscribed' with a ringing bell.
usage: cta.py <last_frame.jpg> <out_dir> "<line>" [seconds=4.2] [start_number=1]
Frames are 1080x1920 jpg at 30 fps, named %05d.jpg from start_number."""
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import rss
import sys, math, os
from PIL import Image, ImageDraw, ImageFont, ImageFilter

FONT = rss.font_file()
SYM = rss.symbol_font()
LAND = rss.LAND      # 16:9 layout
BELL = os.environ.get('RSS_BELL') == '1' or os.environ.get('RILO_BELL') == '1'      # bell + 'turn on the bell' only for long form, never in Shorts
W, H = (1920, 1080) if LAND else (1080, 1920)
last, out, line = sys.argv[1], sys.argv[2], sys.argv[3]
secs = float(sys.argv[4]) if len(sys.argv) > 4 else 4.2
n0 = int(sys.argv[5]) if len(sys.argv) > 5 else 1
os.makedirs(out, exist_ok=True)

bg = Image.open(last).convert("RGB").resize((W, H))
bg = bg.filter(ImageFilter.GaussianBlur(26))
dark = Image.new("RGB", (W, H), (10, 10, 24)); bg = Image.blend(bg, dark, 0.55)

def ease_out_back(k):
    c1, c3 = 1.70158, 2.70158
    return 1 + c3 * (k - 1) ** 3 + c1 * (k - 1) ** 2
def clamp(x, a=0, b=1): return max(a, min(b, x))

def wrap(d, text, font, maxw):
    words, lines, cur = text.split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if d.textlength(t, font=font) <= maxw: cur = t
        else: lines.append(cur); cur = w
    lines.append(cur); return lines

def text_outline(d, xy, t, font, fill, ow=9, anchor="mm"):
    x, y = xy
    for dx in range(-ow, ow + 1, 3):
        for dy in range(-ow, ow + 1, 3):
            if dx * dx + dy * dy <= ow * ow: d.text((x + dx, y + dy), t, font=font, fill=(0, 0, 0), anchor=anchor)
    d.text(xy, t, font=font, fill=fill, anchor=anchor)

def bell(img, cx, cy, size, angle, color):
    s = Image.new("RGBA", (size * 2, size * 2), (0, 0, 0, 0)); d = ImageDraw.Draw(s); c = size
    d.pieslice((c - size * .55, c - size * .62, c + size * .55, c + size * .5), 180, 360, fill=color)
    d.rounded_rectangle((c - size * .55, c - size * .15, c + size * .55, c + size * .38), radius=size * .12, fill=color)
    d.ellipse((c - size * .16, c + size * .36, c + size * .16, c + size * .68), fill=color)
    d.ellipse((c - size * .09, c - size * .78, c + size * .09, c - size * .6), fill=color)
    s = s.rotate(angle, resample=Image.BICUBIC, center=(c, c - size * .6))
    img.alpha_composite(s, (int(cx - size), int(cy - size)))

def cursor(img, x, y, scale=1.0):
    s = Image.new("RGBA", (180, 220), (0, 0, 0, 0)); d = ImageDraw.Draw(s)
    pts = [(10, 10), (10, 150), (48, 118), (74, 176), (100, 164), (76, 108), (124, 104)]
    d.polygon([(a + 6, b + 8) for a, b in pts], fill=(0, 0, 0, 90))
    d.polygon(pts, fill=(255, 255, 255, 255), outline=(0, 0, 0, 255))
    d.line(pts + [pts[0]], fill=(0, 0, 0, 255), width=6)
    if scale != 1: s = s.resize((int(180 * scale), int(220 * scale)), Image.LANCZOS)
    img.alpha_composite(s, (int(x - 10 * scale), int(y - 10 * scale)))

fl = ImageFont.truetype(FONT, 104)
fb = ImageFont.truetype(FONT, 82)
fs = ImageFont.truetype(FONT, 56)
total = int(secs * 30)
for i in range(total):
    t = i / 30
    im = bg.copy().convert("RGBA"); d = ImageDraw.Draw(im)
    # custom line: pops in word block
    k = ease_out_back(clamp(t / 0.35)); sc = 0.6 + 0.4 * k
    lf = ImageFont.truetype(FONT, int(104 * sc))
    lines = wrap(d, line.upper(), lf, 1500 if LAND else 940)
    y = 190 if LAND else 470
    for ln in lines:
        text_outline(d, (W // 2, y), ln, lf, (255, 229, 51) if t < 99 else (255, 255, 255)); y += int(118 * sc)
    # button
    pop = ease_out_back(clamp((t - 0.55) / 0.4)) if t > 0.55 else 0
    press = clamp((t - 2.0) / 0.12) - clamp((t - 2.15) / 0.15)       # 0..1..0 squish around the click
    done = t >= 2.1
    bw, bh = 700, 220
    bs = pop * (1 - 0.07 * press)
    bx, by = (W // 2, 560) if LAND else (W // 2, 1080)
    if bs > 0.02:
        b = Image.new("RGBA", (bw + 80, bh + 80), (0, 0, 0, 0)); bd = ImageDraw.Draw(b)
        col = (96, 96, 104) if done else (255, 24, 24)
        bd.rounded_rectangle((46, 54, bw + 46, bh + 54), radius=110, fill=(0, 0, 0, 110))
        bd.rounded_rectangle((40, 40, bw + 40, bh + 40), radius=110, fill=col, outline=(255, 255, 255), width=8)
        label = "SUBSCRIBED" if done else "SUBSCRIBE"
        ff = fb if not done else ImageFont.truetype(FONT, 70)
        bd.text((40 + bw // 2 + 30, 40 + bh // 2), label, font=ff, fill=(255, 255, 255), anchor="mm")
        if not done:
            bd.polygon([(120, 80), (120, 180), (205, 130)], fill=(255, 255, 255))
        else:
            bd.text((120, 40 + bh // 2), "\u2713", font=ImageFont.truetype(SYM, 100), fill=(255, 255, 255), anchor="mm")
        b = b.resize((max(1, int(b.width * bs)), max(1, int(b.height * bs))), Image.LANCZOS)
        im.alpha_composite(b, (bx - b.width // 2, by - b.height // 2))
    # bell appears once subscribed and rings
    if done and BELL:
        bt = t - 2.1
        kk = ease_out_back(clamp(bt / 0.3))
        ang = math.sin(bt * 26) * 24 * math.exp(-bt * 1.6) if bt < 2 else 0
        bell(im, W // 2 + (560 if LAND else 0), 560 if LAND else 1370, int(150 * kk), ang, (255, 204, 40))
        if bt < 1.4:
            for j in range(3):
                r = 150 + bt * 90 + j * 34
                a = (255, 204, 40, int(255 * clamp(1 - bt / 1.4)))
                cx0, cy0 = (W // 2 + 560, 590) if LAND else (W // 2, 1400)
                d.arc((cx0 - r, cy0 - r, cx0 + r, cy0 + r), 150, 205, fill=a, width=8)
                d.arc((cx0 - r, cy0 - r, cx0 + r, cy0 + r), 335, 30, fill=a, width=8)
        text_outline(d, (W // 2, 880 if LAND else 1590), "TURN ON THE BELL!", fs, (255, 255, 255), ow=6)
    # cursor travels in and clicks
    if 1.2 <= t < 2.7:
        k = clamp((t - 1.2) / 0.75); k = 1 - (1 - k) ** 3
        sx, sy = (1500, 900) if LAND else (900, 1500)
        cx = sx + (bx + 150 - sx) * k; cy = sy + (by + 60 - sy) * k
        if t > 2.3: cy += (t - 2.3) * 500; cx += (t - 2.3) * 300
        cursor(im, cx, cy, 1.0 - 0.1 * press)
    im.convert("RGB").save(os.path.join(out, "%05d.jpg" % (n0 + i)), quality=94)
print("cta frames", total)
