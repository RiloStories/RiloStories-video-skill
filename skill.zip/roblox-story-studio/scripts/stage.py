"""stage.py : bundle the engine (assets/lua) + this project's lua/ (StoryNN.lua, overrides) into one .rbxmx that run.py
loads inside Studio with game:GetObjects("rbxasset://rilo/modules.rbxmx"). Project files override engine files of the same name.
Run it after every gen_story.py / Lua edit."""
import os, sys, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rss

R = rss.need_project()
files = {}
for f in sorted(glob.glob(str(rss.ASSETS / "lua" / "*.lua"))):
    n = os.path.splitext(os.path.basename(f))[0]
    if n != "director":
        files[n] = f
for f in sorted(glob.glob(str(R / "lua" / "*.lua"))):
    n = os.path.splitext(os.path.basename(f))[0]
    if n != "story_template":
        files[n] = f
items = []
for i, (name, f) in enumerate(sorted(files.items())):
    src = open(f, encoding="utf-8-sig").read()
    if "]]>" in src:
        sys.exit(f"{f} contains ']]>' which breaks the bundle; rewrite that string")
    items.append('<Item class="ModuleScript" referent="S%d"><Properties><string name="Name">%s</string><ProtectedString name="Source"><![CDATA[%s]]></ProtectedString></Properties></Item>' % (i, name, src))
xml = '<roblox version="4"><Item class="Folder" referent="F"><Properties><string name="Name">RiloModules</string></Properties>%s</Item></roblox>' % "".join(items)
vers = rss.roblox_versions()
if not vers:
    sys.exit("No Roblox Studio install found under %LOCALAPPDATA%\\Roblox\\Versions")
for v in vers:
    c = os.path.join(v, "content", "rilo")
    os.makedirs(c, exist_ok=True)
    open(os.path.join(c, "modules.rbxmx"), "w", encoding="utf-8").write(xml)
print("staged", len(items), "modules into", len(vers), "Studio version folder(s)")
