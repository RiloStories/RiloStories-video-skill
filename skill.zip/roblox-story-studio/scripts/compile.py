"""compile.py KEY [KEY ...] : long-form 16:9 compilation from finished 16:9 stories (out/NN_16x9.mp4, made by render.py --land).

Reads <project>/compilations.json:
  {"A": {"vids": ["50", "51", "53", "55"], "title": "...", "tags": "...", "names": {"50": "In This Town, Cars Are Banned", ...}}}
Layout: "STORY i OF n" card (2.2 s) + story (cut before its subscribe outro) x n -> one narrated outro with a bell.
No intro montage (viewers skip it). Every segment gets video and audio trimmed to the same length, so captions stay locked.
Writes out/comp_KEY.mp4, out/comp_KEY_meta.md (title, chapters, tags). Thumbnail: mkthumb_comp.py. Upload copy: small.py."""
import sys, os, json, subprocess, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rss
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

R = rss.need_project()
W = R / "work" / "comp"; W.mkdir(parents=True, exist_ok=True)
FONT = rss.font_file()
COMPS = json.loads((R / "compilations.json").read_text(encoding="utf-8"))
OUTRO = rss.cfg("compilation.outro_line", "Thank you for watching! If you enjoyed these stories, like this video, subscribe, and hit the bell so you never miss the next one!")
ENC = ["-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-r", str(rss.FPS), "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-ac", "2"]


def run(cmd, **kw):
    r = subprocess.run(cmd, capture_output=True, text=True, **kw)
    if r.returncode != 0:
        raise SystemExit("FAILED: " + " ".join(str(c) for c in cmd)[:200] + "\n" + r.stderr[-500:])
    return r


def dur(p): return float(run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)]).stdout.strip())


def synth_wav(samples, path):
    import numpy as np, wave
    x = (np.clip(np.asarray(samples, float), -1, 1) * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(44100); w.writeframes(x.tobytes())


def title_card(n, idx, total):
    src = R / "out" / f"{n}_P.png"
    if not src.exists():
        fr = sorted((R / f"frames_{n}_16x9").glob("*.jpg"))
        src = fr[len(fr) // 3] if fr else None
    im = Image.open(src).convert("RGB").resize((1920, 1080)) if src else Image.new("RGB", (1920, 1080), (20, 20, 40))
    im = Image.blend(im, Image.new("RGB", im.size, (0, 0, 0)), 0.12)
    d = ImageDraw.Draw(im); f = ImageFont.truetype(FONT, 64)
    t = f"STORY {idx} OF {total}"
    d.text((60, 50), t, font=f, fill=(255, 255, 255), stroke_width=6, stroke_fill=(0, 0, 0))
    p = W / f"card_{n}.png"; im.save(p)
    return p


def build(key):
    import sfx
    c = COMPS[key]; vids = c["vids"]; parts = []
    synth_wav(sfx.whoosh(0.6, 300, 3000), W / "whoosh.wav")
    synth_wav(sfx.bell(2.0, 1175), W / "bell.wav")
    music = rss.music_for("comp_" + key)
    chapters = []; t = 0.0
    for i, n in enumerate(vids, 1):
        card = title_card(n, i, len(vids))
        cv = W / f"{key}_c{n}.mp4"
        run(["ffmpeg", "-y", "-v", "error", "-loop", "1", "-t", "2.2", "-i", str(card), "-i", str(W / "whoosh.wav"),
             "-filter_complex", "[0:v]scale=1920:1080,fade=t=in:d=0.2,fade=t=out:st=2.0:d=0.2[v];[1:a]atrim=0:2.2,aresample=48000,volume=0.8,apad=whole_dur=2.2[a]",
             "-map", "[v]", "-map", "[a]", "-t", "2.2", *ENC, str(cv)])
        info = json.loads((R / "work" / f"story_{n}.json").read_text())
        seg = W / f"{key}_s{n}.mp4"
        cut = info["cta_start"] + 0.12
        run(["ffmpeg", "-y", "-v", "error", "-i", str(R / "out" / f"{n}_16x9.mp4"), "-t", f"{cut:.2f}",
             "-af", f"afade=t=out:st={cut - 0.15:.2f}:d=0.15,apad", "-vf", f"fade=t=out:st={cut - 0.15:.2f}:d=0.15", *ENC, str(seg)])
        parts += [cv, seg]
        chapters.append((c.get("names", {}).get(n, f"Story {i}"), t)); t += 2.2 + dur(seg)
    # outro: blurred last frame + subscribe/bell animation + narrated line
    fr = sorted((R / f"frames_{vids[-1]}_16x9").glob("*.jpg"))
    last = fr[min(100, len(fr) - 1)]
    od = W / f"{key}_outro_frames"; shutil.rmtree(od, ignore_errors=True)
    run([sys.executable, str(rss.S / "cta.py"), str(last), str(od), "Like, subscribe and hit the bell!", "8.0", "1"], env=dict(os.environ, RSS_LAND="1", RSS_BELL="1"))
    ovo = W / f"{key}_outro_vo.wav"
    run([sys.executable, str(rss.S / "tts.py"), "say", rss.cfg("voice.narrator", "N"), OUTRO, str(ovo)])
    outro = W / f"{key}_outro.mp4"
    run(["ffmpeg", "-y", "-v", "error", "-framerate", str(rss.FPS), "-i", str(od / "%05d.jpg"), "-i", str(ovo), "-stream_loop", "-1", "-i", music, "-i", str(W / "bell.wav"),
         "-filter_complex", "[1:a]adelay=300|300,aresample=48000,loudnorm=I=-15:TP=-1.5[v];[2:a]atrim=0:8,loudnorm=I=-22:TP=-6,afade=t=out:st=6.8:d=1.2[m];[3:a]adelay=2100|2100,aresample=48000,volume=0.5[b];[v][m][b]amix=inputs=3:duration=longest:normalize=0,atrim=0:8[a]",
         "-map", "0:v", "-map", "[a]", "-t", "8", *ENC, str(outro)])
    parts.append(outro)
    lst = W / f"{key}_all.txt"; lst.write_text("".join(f"file '{p.as_posix()}'\n" for p in parts))
    out = R / "out" / f"comp_{key}.mp4"
    run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", "-movflags", "+faststart", str(out)])
    total = dur(out)

    def ts(s): return f"{int(s // 60)}:{int(s % 60):02d}"
    desc = (c.get("description_top", "Every story, back to back!") + "\n\nCHAPTERS\n" + "\n".join(f"{ts(tt)} {nm}" for nm, tt in chapters)
            + "\n\nIf you liked it, like, subscribe and hit the bell for the next one!\n\n" + c.get("hashtags", "#roblox #robloxanimation #robloxstory #compilation"))
    (R / "out" / f"comp_{key}_meta.md").write_text(f"# Compilation {key}\n- File: {out} ({ts(total)})\n- Title: {c['title']}\n- Tags: {c.get('tags', '')}\n- Description:\n{desc}\n", encoding="utf-8")
    print(key, "built", ts(total), [(nm, ts(tt)) for nm, tt in chapters], flush=True)


for k in sys.argv[1:]:
    build(k)
