"""Drive Studio Play mode and grab portrait frames.
  run.py calib
  run.py preview <story> <t1,t2,...> <out.png> [full]     contact sheet of chosen times
  run.py auto <story> <fps> <outdir> [first] [last] [hold]  free-running render, frames decoded from an on-screen code
  run.py dbg <story> <t> "<lua>"                          run Lua in the client after loading the story
"""
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import rss
import sys, time, os, json, threading, queue
R = str(rss.need_project())
from bridge import Studio
from cap import Capture
from PIL import Image

CROPF = os.path.join(R, "work", "crop.json")
CROP = json.load(open(CROPF)) if os.path.exists(CROPF) else None
VX, VY = (CROP["viewport"][0], CROP["viewport"][1]) if CROP else (4, 184)

SYNC = '''local RS=game:GetService("ReplicatedStorage")
local f=game:GetObjects("rbxasset://rilo/modules.rbxmx")[1]
local R=RS:FindFirstChild("Rilo") or Instance.new("Folder",RS) R.Name="Rilo"
local n=0
for _,m in f:GetChildren() do
	local fn,err=loadstring(m.Source,"="..m.Name)
	if not fn then return "COMPILE ERROR in "..m.Name..": "..tostring(err) end
	local t=R:FindFirstChild(m.Name) if not t then t=Instance.new("ModuleScript") t.Name=m.Name t.Parent=R end
	t.Source=m.Source n+=1
end
local sps=game.StarterPlayer.StarterPlayerScripts
local d=sps:FindFirstChild("RiloDirector") if not d then d=Instance.new("LocalScript") d.Name="RiloDirector" d.Parent=sps end
d.Source=[=====[
%s
]=====]
return "synced "..n.." modules + director"'''


LAND = rss.LAND


def portrait(im):
    c = CROP["rect"]
    if LAND:
        return im.crop(c).resize((1920, 1080), Image.LANCZOS)
    im = im.crop(c).transpose(Image.Transpose.ROTATE_270)
    return im.resize((1080, 1920), Image.LANCZOS)


def decode(im):
    px = im.load(); n = 0
    if not (px[VX + 50, VY + 96 + 12 * 52 + 20][0] > 150 and px[VX + 50, VY + 96 + 12 * 52 + 20][1] < 90): return 0
    for i in range(12):
        r, g, b = px[VX + 50, VY + 96 + i * 52 + 20][:3]
        if (r + g + b) / 3 > 128: n |= 1 << i
    return n


_fid = [0]
def start(s, cap, story=None):
    director = open(rss.ASSETS / "lua" / "director.lua", encoding="utf-8").read()
    try: s.play(False)
    except Exception as e: print("pre-stop:", e)
    time.sleep(3)
    r = s.lua("Edit", SYNC % director); print(r)
    if "COMPILE ERROR" in r: raise SystemExit(r)
    try: s.play(False)
    except Exception as e: print("stop:", e)
    time.sleep(2)
    s.lua("Edit", "workspace:SetAttribute('RiloLandscape', %s) return 'ok'" % ("true" if LAND else "nil"))
    s.play(True)
    for i in range(40):
        time.sleep(1.0)
        try:
            if s.lua("Client", "return tostring(workspace:GetAttribute('RiloDirectorReady'))").strip() == "true": break
        except Exception: pass
    else: raise SystemExit("director never ready")
    cap.nudge()
    try: print('quality:', s.lua('Client', "local r=settings().Rendering pcall(function() r.FrameRateManager=Enum.FramerateManagerMode.Off end) pcall(function() r.QualityLevel=Enum.QualityLevel.Level21 end) return tostring(r.FrameRateManager)..' '..tostring(r.QualityLevel)"))
    except Exception as e: print('quality set failed', e)
    if story:
        r = s.lua("Client", """workspace:SetAttribute('RiloLoaded', nil) workspace:SetAttribute('RiloLoad', '%s')
local t0=os.clock() repeat task.wait(0.1) until workspace:GetAttribute('RiloLoaded') or os.clock()-t0>90
return tostring(workspace:GetAttribute('RiloLoaded'))""" % (story + ("|land" if LAND else "")), 120)
        print("loaded:", r)
        if r.startswith("ERR") or r == "nil": raise SystemExit("story load failed: " + r)
        return float(r)


AUDIT_LUA = r"""
local cam = workspace.CurrentCamera
local cp, look = cam.CFrame.Position, cam.CFrame.LookVector
local stage
for _, d in ipairs(workspace:GetChildren()) do if d:IsA("Folder") and d.Name:match("^Stage") then stage = d end end
if not stage then return "ERR no stage" end
local issues = {}
local function add(s) if #issues < 14 then table.insert(issues, s) end end
local chars, charParts = {}, {}
for _, m in ipairs(stage:GetDescendants()) do
	if m:IsA("Model") and m:FindFirstChildOfClass("Humanoid") then chars[m] = true; for _, p in ipairs(m:GetDescendants()) do if p:IsA("BasePart") then charParts[p] = m end end end
end
local function inside(p, pt, pad)
	local l = p.CFrame:PointToObjectSpace(pt); local h = p.Size / 2 - Vector3.new(pad, pad, pad)
	return math.abs(l.X) < h.X and math.abs(l.Y) < h.Y and math.abs(l.Z) < h.Z
end
local near = {}
for _, p in ipairs(stage:GetDescendants()) do
	if p:IsA("BasePart") and p.Transparency < 0.9 and p.Position.Y > -400 then
		p.CanQuery = true
		if (p.Position - cp).Magnitude < 90 + p.Size.Magnitude / 2 then table.insert(near, p) end
	end
end
-- 1 camera inside geometry
for _, p in ipairs(near) do if not charParts[p] and inside(p, cp, 0.05) then add("CAMERA_INSIDE " .. p:GetFullName():gsub("^Workspace%.", "")) end end
-- 2 characters clipping into set pieces (head / torso centres inside a solid set part)
for m in pairs(chars) do
	local h, t = m:FindFirstChild("Head"), m:FindFirstChild("UpperTorso") or m:FindFirstChild("Torso")
	if h and h.Position.Y > -400 then
		for _, p in ipairs(near) do
			if not charParts[p] and p.Size.Magnitude > 1 then
				if inside(p, h.Position, 0.15) then add("HEAD_IN " .. m.Name .. " -> " .. p.Name) end
				if t and inside(p, t.Position, 0.2) then add("BODY_IN " .. m.Name .. " -> " .. p.Name) end
			end
		end
	end
end
-- 3 z-fighting: two differently coloured axis-aligned faces in the same plane, overlapping, in front of the camera
local faces = {}
local axes = {Vector3.xAxis, Vector3.yAxis, Vector3.zAxis}
for _, p in ipairs(near) do
	if not charParts[p] and (p.Position - cp):Dot(look) > 0 and p.ClassName == "Part" and p.Shape == Enum.PartType.Block then
		local r = p.CFrame - p.Position
		for ai, ax in ipairs({r.RightVector, r.UpVector, r.LookVector}) do
			for _, w in ipairs(axes) do
				if math.abs(math.abs(ax:Dot(w)) - 1) < 1e-3 then
					local half = ({p.Size.X, p.Size.Y, p.Size.Z})[ai] / 2
					for _, sg in ipairs({1, -1}) do
						local c = p.Position + ax * half * sg
						local n = (ax * sg):Dot(w) > 0 and 1 or -1
						local coord = (w == Vector3.xAxis and c.X) or (w == Vector3.yAxis and c.Y) or c.Z
						local key = (w == Vector3.xAxis and "x" or w == Vector3.yAxis and "y" or "z") .. math.floor(coord * 100 + 0.5)
						local cf, sz = p.CFrame, p.Size
						local ex = (cf * CFrame.new(sz / 2)).Position; local ex2 = (cf * CFrame.new(-sz / 2)).Position
						faces[key] = faces[key] or {}
						table.insert(faces[key], {p = p, n = n, lo = Vector3.new(math.min(ex.X, ex2.X), math.min(ex.Y, ex2.Y), math.min(ex.Z, ex2.Z)), hi = Vector3.new(math.max(ex.X, ex2.X), math.max(ex.Y, ex2.Y), math.max(ex.Z, ex2.Z))})
					end
				end
			end
		end
	end
end
local zf = 0
for key, list in pairs(faces) do
	if #list > 1 and #list < 40 then
		local ax = key:sub(1, 1)
		for i = 1, #list do for j = i + 1, #list do
			local a, b = list[i], list[j]
			if a.p ~= b.p and a.n == b.n and (a.p.Color ~= b.p.Color or a.p.Material ~= b.p.Material) then
				local o1 = ax == "x" and {"Y", "Z"} or ax == "y" and {"X", "Z"} or {"X", "Y"}
				local ov = 1
				for _, k in ipairs(o1) do ov = ov * math.max(0, math.min(a.hi[k], b.hi[k]) - math.max(a.lo[k], b.lo[k])) end
				if ov > 0.02 then zf += 1; if zf <= 4 then add("ZFIGHT " .. a.p.Name .. " / " .. b.p.Name .. " (plane " .. key .. ")") end end
			end
		end end
	end
end
-- 4 void: rays through the view that hit nothing and are not looking up at the sky
local vp = cam.ViewportSize; local void, total = 0, 0
local rp = RaycastParams.new(); rp.FilterType = Enum.RaycastFilterType.Include; rp.FilterDescendantsInstances = {stage}
for gx = 1, 9 do for gy = 1, 16 do
	local ray = cam:ViewportPointToRay(vp.X * (gx - 0.5) / 9, vp.Y * (gy - 0.5) / 16)
	if ray.Direction.Y < 0.12 then
		total += 1
		if not workspace:Raycast(ray.Origin, ray.Direction * 1500, rp) then void += 1 end
	end
end end
-- 5 open roof: camera inside an imported set, any ray (also upward) that leaves the stage = sky/void where a ceiling should be
for _, m in ipairs(stage:GetChildren()) do
	if m:IsA("Model") and m:GetAttribute("RiloSet") then
		local cf, sz = m:GetBoundingBox()
		local l = cf:PointToObjectSpace(cp)
		if math.abs(l.X) < sz.X / 2 and math.abs(l.Z) < sz.Z / 2 and (l.Y > sz.Y / 2 or l.Y < -sz.Y / 2) then add("CAMERA_OUTSIDE_SET " .. m.Name .. " (above the roof or under the floor: is the set buried? Eng.set places by floor)") end
		if math.abs(l.X) < sz.X / 2 and math.abs(l.Z) < sz.Z / 2 and l.Y < sz.Y / 2 then
			local up, upTot = 0, 0
			local rp2 = RaycastParams.new(); rp2.FilterType = Enum.RaycastFilterType.Include; rp2.FilterDescendantsInstances = {m}
			for gx = 1, 9 do for gy = 1, 16 do
				local ray = cam:ViewportPointToRay(vp.X * (gx - 0.5) / 9, vp.Y * (gy - 0.5) / 16)
				if ray.Direction.Y > 0.12 then upTot += 1; if not workspace:Raycast(ray.Origin, ray.Direction * 200, rp2) then up += 1 end end
			end end
			if upTot > 0 and up / upTot > 0.03 then add(string.format("SKY_INDOORS %d%% of the upward view in %s sees sky (open roof: set_import adds one, or aim lower)", math.floor(up / upTot * 100), m.Name)) end
		end
	end
end
if total > 0 and void / total > 0.04 then add(string.format("VOID %d%% of the low view sees nothing (open window/edge: add Eng.windowView or a backdrop)", math.floor(void / total * 100))) end
return #issues == 0 and "OK" or table.concat(issues, " | ")
"""


def frame(s, t):
    _fid[0] += 1
    r = s.lua("Client", """local ws=workspace ws:SetAttribute('RiloAck', nil) ws:SetAttribute('RiloReq', '%d|%r')
local t0=os.clock() repeat task.wait() until ws:GetAttribute('RiloAck') or os.clock()-t0>30
return tostring(ws:GetAttribute('RiloAck'))""" % (_fid[0], t), 60)
    if not r.strip().isdigit(): raise RuntimeError("frame error: " + r)
    return r


def main():
    mode = sys.argv[1]
    cap = Capture(); s = Studio()
    try:
        if mode == "calib":
            start(s, cap)
            s.lua("Client", '''local g=Instance.new("ScreenGui") g.IgnoreGuiInset=true g.Name="Calib" g.Parent=game.Players.LocalPlayer.PlayerGui
local f=Instance.new("Frame") f.Size=UDim2.fromScale(1,1) f.BackgroundColor3=Color3.fromRGB(255,0,255) f.BorderSizePixel=0 f.Parent=g
task.wait(0.6) return "ok"''')
            time.sleep(1.0); im = cap.grab(); im.save(os.path.join(R, "work", "calib_full.png"))
            px = im.load(); W, H = im.size
            xs, ys = [], []
            for y in range(0, H, 4):
                for x in range(0, W, 4):
                    r, g, b = px[x, y][:3]
                    if r > 240 and g < 20 and b > 240: xs.append(x); ys.append(y)
            x0, x1, y0, y1 = min(xs), max(xs) + 4, min(ys), max(ys) + 4
            vw, vh = x1 - x0, y1 - y0
            cw = int(vh * 16 / 9); cx0 = x0 + (vw - cw) // 2
            json.dump({"rect": [cx0, y0, cx0 + cw, y0 + vh], "viewport": [x0, y0, x1, y1]}, open(CROPF, "w"))
            print("client", im.size, "viewport", x0, y0, x1, y1)
        elif mode == "raw":
            start(s, cap)
            print(s.lua("Client", sys.argv[2], 120))
        elif mode == "audit":
            story, times = sys.argv[2], [float(x) for x in sys.argv[3].split(",")]
            start(s, cap, story)
            bad = 0
            for t in times:
                frame(s, t)
                r = s.lua("Client", AUDIT_LUA, 120).strip()
                if r != "OK": bad += 1
                print("t=%6.2f  %s" % (t, r), flush=True)
            print("AUDIT", "PASS" if bad == 0 else "FAIL (%d of %d shots have issues)" % (bad, len(times)), flush=True)
        elif mode == "dbg":
            story, t, code = sys.argv[2], float(sys.argv[3]), sys.argv[4]
            start(s, cap, story); frame(s, t)
            print(s.lua("Client", code))
        elif mode == "preview":
            story, times, out = sys.argv[2], [float(x) for x in sys.argv[3].split(",")], sys.argv[4]
            start(s, cap, story)
            tiles = []
            from fastgrab import FastGrab
            cap.pin(); fg = FastGrab(cap.h)
            for t in times:
                frame(s, t); time.sleep(0.3)
                tiles.append((t, portrait(fg.grab().copy())))
            w, h = 324, 576; cols = min(len(tiles), 6); rows = (len(tiles) + cols - 1) // cols
            sheet = Image.new("RGB", (cols * w, rows * h))
            for i, (t, im) in enumerate(tiles): sheet.paste(im.resize((w, h), Image.LANCZOS), ((i % cols) * w, (i // cols) * h))
            sheet.save(out); print("saved", out)
            if len(sys.argv) > 5:
                for t, im in tiles: im.save(os.path.join(R, "work", "pv_%05.2f.jpg" % t), quality=92)
        elif mode == "fix":
            story, fps, outdir = sys.argv[2], int(sys.argv[3]), sys.argv[4]
            dur = start(s, cap, story)
            n = int(round(dur * fps))
            missing = [i for i in range(n) if not os.path.exists(os.path.join(outdir, "%05d.jpg" % i))]
            print("missing:", len(missing), missing[:50], flush=True)
            cap.pin()
            for i in missing:
                for attempt in range(4):
                    try:
                        frame(s, i / fps); time.sleep(0.25); portrait(cap.grab()).save(os.path.join(outdir, "%05d.jpg" % i), quality=95, subsampling=0); break
                    except Exception as e:
                        print("retry", i, e, flush=True); cap.nudge()
            print("fixed", len(missing), flush=True)
        elif mode == "auto":
            story, fps, outdir = sys.argv[2], int(sys.argv[3]), sys.argv[4]
            os.makedirs(outdir, exist_ok=True)
            hold = int(sys.argv[7]) if len(sys.argv) > 7 else 3
            dur = start(s, cap, story)
            n = int(round(dur * fps))
            first = int(sys.argv[5]) if len(sys.argv) > 5 else 0
            last = int(sys.argv[6]) if len(sys.argv) > 6 else n - 1
            want = [i for i in range(first, last + 1) if not os.path.exists(os.path.join(outdir, "%05d.jpg" % i))]
            print("frames wanted:", len(want), flush=True)
            if want:
                from fastgrab import FastGrab
                from convert import convert
                from concurrent.futures import ProcessPoolExecutor
                f0, f1 = min(want), max(want)
                wantset = set(want)
                fg = FastGrab(cap.h)
                cap.pin()
                rect = tuple(CROP["rect"])
                import ctypes
                saved = set(); last_ok = time.time(); last_wig = time.time(); wig = 1
                pool = ProcessPoolExecutor(max_workers=3)
                s.lua("Client", "workspace:SetAttribute('RiloAutoDone', nil) workspace:SetAttribute('RiloAuto', '%d|%d|%d|%d') return 'go'" % (f0, f1, fps, hold))
                t0 = time.time(); last_new = time.time(); done = False; last_poll = time.time()
                while True:
                    im = fg.grab()
                    c = decode(im)
                    if c > 0: last_ok = time.time()
                    if time.time() - last_wig > 1.5:
                        last_wig = time.time(); wig = -wig; ctypes.windll.user32.SetCursorPos(ctypes.windll.user32.GetSystemMetrics(0) - 80 + wig * 3, ctypes.windll.user32.GetSystemMetrics(1) - 45)
                    elif time.time() - last_ok > 5:
                        cap.pin(); fg = FastGrab(cap.h); last_ok = time.time(); print('re-created grabber', flush=True)
                    if c > 0 and (c - 1) in wantset and (c - 1) not in saved:
                        crop = im.crop(rect)
                        pool.submit(convert, os.path.join(outdir, "%05d.jpg" % (c - 1)), crop.tobytes(), crop.size)
                        saved.add(c - 1); last_new = time.time()
                        if len(saved) % 100 == 0: print(len(saved), "/", len(want), "%.0fs" % (time.time() - t0), flush=True)
                    if time.time() - last_new > 8 and int(time.time() - last_new) % 8 == 0:
                        cap.pin()
                    if time.time() - last_poll > 8:
                        last_poll = time.time()
                        try:
                            d = s.lua("Client", "return tostring(workspace:GetAttribute('RiloAutoDone'))").strip()
                            if d != "nil": done = True; print("director:", d, flush=True)
                        except Exception as e: print("poll err", e)
                    if done and time.time() - last_new > 4: break
                    if time.time() - last_new > 90: print("stalled"); break
                pool.shutdown(wait=True)
            missing = [i for i in want if not os.path.exists(os.path.join(outdir, "%05d.jpg" % i))]
            print("missing after pass:", len(missing), missing[:40], flush=True)
            for i in missing:
                for attempt in range(4):
                    try:
                        frame(s, i / fps); time.sleep(0.2); portrait(cap.grab()).save(os.path.join(outdir, "%05d.jpg" % i), quality=95, subsampling=0); break
                    except Exception as e:
                        print("retry", i, e, flush=True); cap.nudge()
            print("done", time.strftime("%H:%M:%S"), flush=True)
    finally:
        try: s.play(False)
        except Exception: pass
        s.close()

if __name__ == "__main__":
    main()
