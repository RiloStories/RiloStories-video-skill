import ctypes as c
from ctypes import wintypes as w
from PIL import Image

u = c.windll.user32; g = c.windll.gdi32
g.CreateCompatibleDC.restype = w.HDC; g.CreateCompatibleDC.argtypes = [w.HDC]
g.CreateCompatibleBitmap.restype = w.HBITMAP; g.CreateCompatibleBitmap.argtypes = [w.HDC, c.c_int, c.c_int]
g.SelectObject.restype = w.HANDLE; g.SelectObject.argtypes = [w.HDC, w.HANDLE]
g.BitBlt.argtypes = [w.HDC, c.c_int, c.c_int, c.c_int, c.c_int, w.HDC, c.c_int, c.c_int, w.DWORD]
u.GetDC.restype = w.HDC; u.GetDC.argtypes = [w.HWND]
g.GetDIBits.argtypes = [w.HDC, w.HBITMAP, w.UINT, w.UINT, c.c_void_p, c.c_void_p, w.UINT]


class BI(c.Structure):
    _fields_ = [('size', w.DWORD), ('width', w.LONG), ('height', w.LONG), ('planes', w.WORD), ('bitcount', w.WORD), ('compression', w.DWORD),
                ('sizeimage', w.DWORD), ('xppm', w.LONG), ('yppm', w.LONG), ('used', w.DWORD), ('important', w.DWORD)]


class FastGrab:
    """Copies the Studio window's client area straight from the screen (needs the window on top). ~70 ms for 2560x1440."""
    def __init__(self, hwnd):
        r = w.RECT(); u.GetClientRect(hwnd, c.byref(r)); self.W, self.H = r.right, r.bottom
        self.dc = u.GetDC(hwnd); self.mem = g.CreateCompatibleDC(self.dc)
        self.bmp = g.CreateCompatibleBitmap(self.dc, self.W, self.H); g.SelectObject(self.mem, self.bmp)
        self.buf = c.create_string_buffer(self.W * self.H * 4)

    def grab(self):
        g.BitBlt(self.mem, 0, 0, self.W, self.H, self.dc, 0, 0, 0x00CC0020 | 0x40000000)
        info = BI(c.sizeof(BI), self.W, -self.H, 1, 32, 0, 0, 0, 0, 0, 0)
        g.GetDIBits(self.mem, self.bmp, 0, self.H, self.buf, c.byref(info), 0)
        return Image.frombuffer('RGB', (self.W, self.H), self.buf, 'raw', 'BGRX', 0, 1)
