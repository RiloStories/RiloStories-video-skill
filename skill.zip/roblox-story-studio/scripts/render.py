"""render.py NN [--land] [--from STEP] [--only STEP] [--force]
One command, with quality gates, from spec to finished video. Steps, in order:
  gen      gen_story.py NN          spec + word timings -> lua/StoryNN.lua, work/cues_NN.py, work/story_NN.json
  stage    stage.py                 engine + stories -> Studio content folder
  audit    run.py audit             GATE: camera inside walls, characters in furniture, z-fighting, void views -> must PASS
  preview  run.py preview           contact sheet of every beat midpoint -> work/pv_NN.png (Claude must LOOK at it; QA rubric)
  render   run.py auto (+ fix)      fresh frames (old frames are deleted first; stale frames caused a broken 16:9 once)
  finish   finish.py                subscribe outro + captions + voice/music/SFX mix -> out/NN_final.mp4 (or NN_16x9.mp4)
  verify   sync_check.py            GATE: frame count, video length == audio length, caption-vs-voice spot checks
  qa       qa_sheet.py + flicker.py one tile per beat with the words spoken under it; flicker spikes list
  thumb    mkthumb_short.py         9:16 thumbnail (portrait only)
  pacing   pacing.py                 WARN: talk from second 0, wpm, shot length, camera motion, hook rule (references/16)
--test renders 3 seconds only (proves the capture/GPU work, ~1 minute) and exits. Previous finals are archived to out/versions/.
--force continues past a failed gate (don't, unless the user said so). --land renders the 16:9 version."""
import os, sys, json, subprocess, shutil, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rss

STEPS = ["gen", "stage", "pacing", "audit", "preview", "render", "finish", "verify", "qa", "thumb"]
a = sys.argv[1:]
num = a[0]; land = "--land" in a; force = "--force" in a
R = rss.need_project(); S = rss.S
env = dict(os.environ, RSS_PROJECT=str(R))
if land: env["RSS_LAND"] = "1"
steps = STEPS[STEPS.index(a[a.index("--from") + 1]):] if "--from" in a else STEPS
if "--only" in a: steps = [a[a.index("--only") + 1]]
if land: steps = [s for s in steps if s not in ("thumb",)]


def run(args, gate=False, capture=False):
    print(">>", " ".join(str(x) for x in args[1:3]), flush=True)
    r = subprocess.run([sys.executable] + [str(x) for x in args], cwd=str(R), env=env, capture_output=True, text=True)
    out = (r.stdout or "") + (r.stderr or "")
    tail = "\n".join(out.strip().splitlines()[-25:])
    print(tail, flush=True)
    if r.returncode != 0:
        sys.exit(f"step failed: {args[0]}")
    return out


def beat_times():
    st = json.loads((R / "work" / f"story_{num}.json").read_text())
    import importlib.util
    sys.path.insert(0, str(R / "specs"))
    sp = importlib.util.spec_from_file_location("s", R / "specs" / f"spec{num}.py"); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
    starts, cta = st["starts"], st["cta_start"]
    out = []
    for b in m.BEATS:
        x, z = b["lines"]
        t0 = starts[x]; t1 = starts[z + 1] if z + 1 < len(starts) else cta
        if "t" in b: t0, t1 = b["t"]
        elif "frac" in b: f0, f1 = b["frac"]; L = t1 - t0; t0, t1 = t0 + f0 * L, t0 + f1 * L
        out.append(round((t0 + t1) / 2, 2))
    return out


t_start = time.time()
if "--test" in a:
    run([S / "gen_story.py", num]); run([S / "stage.py"])
    td = R / "work" / "test_frames"
    if td.exists(): shutil.rmtree(td)
    td.mkdir(parents=True)
    out = run([S / "run.py", "auto", f"Story{num}", str(rss.FPS), td, "0", str(3 * rss.FPS - 1)])
    got = len(list(td.glob("*.jpg")))
    sys.exit(f"TEST {'PASS' if got >= 3 * rss.FPS - 2 else 'FAIL'}: {got} of {3 * rss.FPS} frames captured in {(time.time() - t_start):.0f}s. Look at work/test_frames/00000.jpg and 00089.jpg." + ("" if got >= 3 * rss.FPS - 2 else " Fix: Studio in Edit mode, window maximised, run.py calib, PC idle."))
for step in steps:
    if step == "gen":
        run([S / "gen_story.py", num])
    elif step == "stage":
        run([S / "stage.py"])
    elif step == "pacing":
        out = run([S / "pacing.py", num])
    elif step == "audit":
        out = run([S / "run.py", "audit", f"Story{num}", ",".join(str(t) for t in beat_times())])
        if "AUDIT PASS" not in out and not force:
            sys.exit("AUDIT FAILED: fix the listed shots in specs/spec%s.py (move camera/actors/props), then render.py %s --from gen" % (num, num))
    elif step == "preview":
        ts = beat_times()
        sheets = []
        for i in range(0, len(ts), 12):
            outp = R / "work" / (f"pv_{num}_{i // 12}{'_land' if land else ''}.png")
            run([S / "run.py", "preview", f"Story{num}", ",".join(str(t) for t in ts[i:i + 12]), outp])
            sheets.append(str(outp))
        print("PREVIEW SHEETS (look at every one before rendering):", *sheets, sep="\n  ")
        if "--from" not in a and "--only" not in a and not force:
            print("Stopping before the full render: review the sheets, then run  render.py %s --from render%s" % (num, " --land" if land else ""))
            break
    elif step == "render":
        fr = rss.frames_dir(num, land)
        if fr.exists(): shutil.rmtree(fr)
        fr.mkdir(parents=True)
        out = run([S / "run.py", "auto", f"Story{num}", str(rss.FPS), fr])
        if "missing after pass: 0" not in out:
            run([S / "run.py", "fix", f"Story{num}", str(rss.FPS), fr])
    elif step == "finish":
        if not list((R / "work").glob(f"music_{num}.*")) and not (rss.CFG.get("audio", {}).get("music")) and not list((R / "music").glob("*.*")):
            print("no music yet: composing one (quirky; change with music.py compose --mood ... and re-run finish)")
            run([S / "music.py", "compose", "--mood", "quirky", "--seconds", "60", "--out", R / "work" / f"music_{num}.wav"])
        final = R / "out" / (f"{num}_16x9.mp4" if land else f"{num}_final.mp4")
        if final.exists():                       # keep every version: a better old render is never lost
            vd = R / "out" / "versions"; vd.mkdir(exist_ok=True)
            k = len(list(vd.glob(f"{num}{'_16x9' if land else ''}_v*.mp4"))) + 1
            shutil.copy(final, vd / f"{num}{'_16x9' if land else ''}_v{k}.mp4"); print("archived previous render as", vd.name + "/" + f"{num}_v{k}")
        lines = [l.strip() for l in (R / "scripts" / f"{num}.txt").read_text(encoding="utf-8").splitlines() if l.strip()]
        run([S / "finish.py", num, lines[-1]])
    elif step == "verify":
        out = run([S / "sync_check.py", num] + (["--land"] if land else []))
        if "SYNC PASS" not in out and not force:
            sys.exit("VERIFY FAILED: see above (usually a missing/stale frame range: render.py %s --from render)" % num)
    elif step == "qa":
        if not land: run([S / "qa_sheet.py", num])
        vid = R / "out" / (f"{num}_16x9.mp4" if land else f"{num}_final.mp4")
        r = subprocess.run([sys.executable, str(S / "flicker.py"), str(vid), "--top", "5"], capture_output=True, text=True)
        print(chr(10).join(r.stdout.strip().splitlines()[-10:]))
        if r.returncode == 3: print("FLICKER: a repeating bad-frame pattern was found; look at the listed frames before publishing")
    elif step == "thumb":
        run([S / "mkthumb_short.py", num])
print(f"done in {(time.time() - t_start) / 60:.1f} min")
