import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import rss
import sys, json, subprocess, numpy as np
from faster_whisper import WhisperModel
num = sys.argv[1]
R = str(rss.need_project()).replace("\\", "/")
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", R + "/vo/" + num + "_vo.mp3", "-f", "f32le", "-ac", "1", "-ar", "16000", "-"], capture_output=True).stdout
audio = np.frombuffer(raw, np.float32)
m = WhisperModel(rss.cfg("voice.whisper_model", "small.en"), device="cpu", compute_type="int8")
segs, _ = m.transcribe(audio, word_timestamps=True, vad_filter=False, language=rss.cfg("voice.language", "en"))
words = []
for s in segs:
    for w in s.words: words.append({"w": w.word.strip(), "s": round(w.start, 2), "e": round(w.end, 2)})
json.dump(words, open(R + "/work/words_" + num + ".json", "w", encoding="utf-8"), ensure_ascii=False)
print(num, len(words), "words; last end", words[-1]["e"])
print(" ".join(w["w"] for w in words))
