import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import rss
import sys, json, subprocess, re, difflib, numpy as np
from faster_whisper import WhisperModel
num = sys.argv[1]
R = str(rss.need_project()).replace("\\", "/")
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", R + "/vo/" + num + "_vo.mp3", "-f", "f32le", "-ac", "1", "-ar", "16000", "-"], capture_output=True).stdout
audio = np.frombuffer(raw, np.float32)
m = WhisperModel(rss.cfg("voice.whisper_model", "small.en"), device="cpu", compute_type="int8")
segs, _ = m.transcribe(audio, word_timestamps=True, vad_filter=False, language=rss.cfg("voice.language", "en"))
words = []
for s in segs:
    for w in s.words: words.append({"w": w.word.strip(), "s": round(w.start, 2), "e": round(w.end, 2)})

def norm(t): return re.sub(r"[^a-z0-9']", "", t.lower())
def align_to_script(words, path):
    """Whisper hears 'profit' for 'prop' and 'cloud code' for 'Claude Code'. Keep Whisper's TIMES but use the script's
    SPELLING wherever the two texts line up (difflib), so names and tool names are right in the captions."""
    txt = re.sub(r"\[[^\]]*\]|##", " ", open(path, encoding="utf-8").read())
    toks = [t for t in txt.split() if norm(t)]
    a, b = [norm(w["w"]) for w in words], [norm(t) for t in toks]
    fixed = 0
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag == "equal" or (tag == "replace" and i2 - i1 == j2 - j1):
            for k in range(i2 - i1):
                if words[i1 + k]["w"] != toks[j1 + k]: fixed += 1
                words[i1 + k]["w"] = toks[j1 + k]
        elif tag == "replace" and i2 - i1 > 0 and j2 - j1 > 0 and (i2 - i1) / (j2 - j1) in (2, 3):
            # one script word heard as several ("Claude Code" -> "cloud code" is 1:1; "ElevenLabs" -> "11 labs" is 1:2): merge
            r = (i2 - i1) // (j2 - j1)
            for k in range(j2 - j1):
                grp = words[i1 + k * r: i1 + (k + 1) * r]
                grp[0]["w"], grp[0]["e"] = toks[j1 + k], grp[-1]["e"]
                for g in grp[1:]: g["w"] = ""
                fixed += 1
    words[:] = [w for w in words if w["w"]]
    return fixed, len(toks), len(b) and sum(1 for x in a if x in set(b))
sp = R + "/scripts/" + num + ".txt"
if rss.cfg("voice.align_to_script", True) and _os.path.exists(sp):
    fixed, ntok, _ = align_to_script(words, sp)
    print("script spelling applied to", fixed, "words (script has", ntok, "words, voice has", len(words), ")")
    if abs(ntok - len(words)) > max(3, ntok * 0.1): print("WARNING: voice and script differ a lot - the voice may have skipped or added words. Listen to it.")
json.dump(words, open(R + "/work/words_" + num + ".json", "w", encoding="utf-8"), ensure_ascii=False)
print(num, len(words), "words; last end", words[-1]["e"])
print(" ".join(w["w"] for w in words))
