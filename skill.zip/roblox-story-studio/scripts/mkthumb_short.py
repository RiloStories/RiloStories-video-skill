"""mkthumb_short.py NN ... -> out/NN_V.jpg (1080x1920, 9:16 Shorts thumbnail): one key frame full bleed + big 'IN THIS TOWN, <topic>' headline on top.
Frame choice: work/thumb_picks.json {"58": beat_index} overrides, else the most colourful prop beat."""
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import rss
import sys, json, importlib.util
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance, ImageStat
R = rss.need_project()
_sys.path.insert(0, str(R / "specs"))
FONT = rss.font_file()
PREFIX = rss.cfg("brand.thumb_prefix", "IN THIS TOWN,")
RED_WORDS = set(rss.cfg("brand.red_words", ["BANNED", "EVERYTHING", "FOREVER", "VANISHES"]))
tf = R / "work" / "thumb_text.json"
TEXT = json.loads(tf.read_text(encoding="utf-8")) if tf.exists() else {}
pf = R / "work" / "thumb_picks.json"
PICKS = json.loads(pf.read_text()) if pf.exists() else {}


def beats(num):
    lines = [l.strip() for l in (R / "scripts" / f"{num}.txt").read_text(encoding="utf-8").splitlines() if l.strip()]
    st = json.loads((R / "work" / f"story_{num}.json").read_text())
    starts, cta = st["starts"], st["cta_start"]
    sp = importlib.util.spec_from_file_location("s", R / "specs" / f"spec{num}.py")
    m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
    out = []
    for i, b in enumerate(m.BEATS):
        a, z = b["lines"]
        t0 = starts[a]; t1 = starts[z + 1] if z + 1 < len(starts) else cta
        if "t" in b:
            t0, t1 = b["t"]
        elif "frac" in b:
            f0, f1 = b["frac"]; L = t1 - t0; t0, t1 = t0 + f0 * L, t0 + f1 * L
        fx = b.get("fx", "")
        out.append(dict(i=i, line=a, t=(t0 + t1) / 2, prop=('P("' in fx), fr=R / f"frames_{num}" / f"{int(round((t0 + t1) / 2 * rss.FPS)):05d}.jpg"))
    return lines, out


def score(p):
    im = Image.open(p).convert("RGB").resize((108, 192))
    hsv = im.convert("HSV"); sat = ImageStat.Stat(hsv.split()[1]).mean[0]
    edges = ImageStat.Stat(im.convert("L").filter(ImageFilter.FIND_EDGES)).mean[0]
    return sat + 3 * edges


def fit(d, text, size, maxw):
    f = ImageFont.truetype(FONT, size)
    while d.textlength(text, font=f) > maxw and size > 40:
        size -= 4; f = ImageFont.truetype(FONT, size)
    return f, size


def pick_frame(num):
    lines, bs = beats(num)
    cands = [b for b in bs if 2 <= b["i"] < len(bs) - 1 and b["fr"].exists()]
    if str(num) in PICKS:
        pick = next(b for b in bs if b["i"] == PICKS[str(num)])
    else:
        pool = [b for b in cands if b["prop"]] or cands
        pick = max(pool, key=lambda b: score(b["fr"]))
    return lines, pick


def make(num):
    lines, pick = pick_frame(num)
    im = Image.open(pick["fr"]).convert("RGB").resize((1080, 1920), Image.LANCZOS)
    im = ImageEnhance.Contrast(im).enhance(1.12); im = ImageEnhance.Color(im).enhance(1.2)
    # darken the top for the headline
    ov = Image.new("L", (1080, 1920), 0); od = ImageDraw.Draw(ov)
    for y in range(620):
        od.line([(0, y), (1080, y)], fill=int(190 * (1 - y / 620)))
    im = Image.composite(Image.new("RGB", (1080, 1920), (8, 6, 30)), im, ov)
    d = ImageDraw.Draw(im)
    # headline: work/thumb_text.json {"58": "CLOCKS ARE BANNED!"} wins; else the hook line after its first comma
    if str(num) in TEXT:
        rest = TEXT[str(num)].upper()
    else:
        first = lines[0].rstrip("!. ")
        rest = (first.split(",", 1)[1] if "," in first else first).strip().upper() + "!"
    f1, s1 = fit(d, PREFIX, 128, 1000)
    w = d.textlength(PREFIX, font=f1); d.text(((1080 - w) / 2, 40), PREFIX, font=f1, fill=(255, 255, 255), stroke_width=11, stroke_fill=(0, 0, 0))
    words = rest.split(" "); kw = next((x.strip("!") for x in words if x.strip("!") in RED_WORDS), words[-1].strip("!"))
    # wrap to two lines, keyword (BANNED / etc) on the last line in red
    best = None
    for cut in range(1, len(words)):
        l1, l2 = " ".join(words[:cut]), " ".join(words[cut:])
        m = max(d.textlength(l1, font=ImageFont.truetype(FONT, 150)), d.textlength(l2, font=ImageFont.truetype(FONT, 150)))
        if best is None or m < best[0]: best = (m, l1, l2)
    if len(words) == 1: best = (0, rest, "")
    y = 40 + s1 + 20
    for ln in (best[1], best[2]):
        if not ln: continue
        f, s = fit(d, ln, 170, 1000)
        x = (1080 - d.textlength(ln, font=f)) / 2
        for wd in ln.split(" "):
            col = (255, 70, 70) if wd.strip("!") == kw else (255, 226, 60)
            d.text((x, y), wd, font=f, fill=col, stroke_width=12, stroke_fill=(0, 0, 0)); x += d.textlength(wd + " ", font=f)
        y += s + 6
    out = R / "out" / f"{num}_V.jpg"; im.save(out, quality=92)
    print(out.name, out.stat().st_size // 1024, "KB beat", pick["i"], "line", pick["line"])


if __name__ == '__main__':
    for a in sys.argv[1:]:
        make(a)  # keep the string: '01' must stay '01'
