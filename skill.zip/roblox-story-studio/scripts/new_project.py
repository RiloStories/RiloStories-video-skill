"""new_project.py <folder> [options] : create a channel project (folders + project.json) from the onboarding answers.

  --name "Channel name"            --channel-url https://youtube.com/@handle   (or --no-channel)
  --format town|general|stickman   town = "In this town, ..." Roblox stories; general = any Roblox story format;
                                   stickman = 3D cartoon engine (engines/inkbeat, no Roblox needed)
  --caption-position middle|safe|lower|bottom   (recommended middle)      --caption-color "#FFE533" (recommended yellow)
  --viral-characters yes|no        allow trending characters/memes (e.g. a horror mascot) as guest stars
  --trends yes|no                  check TikTok/YouTube trends when generating ideas
  --slots "07:00,16:00,20:00"      upload times (channel timezone)    --timezone Europe/London
  --no-library-save                do NOT keep scenes/props for reuse (default: save them; same as library.save=false)
  --library "<path>"               asset notes folder (e.g. inside an Obsidian vault); default <folder>/library
  --voices single|per-character   single = every character uses the narrator voice (default)
  --narrator-provider edge --narrator-voice en-GB-RyanNeural          (change any time with voices.py set)
Writes <folder>/project.json and the folder layout; downloads a free OFL caption font (Lilita One)."""
import os, sys, json, shutil, urllib.request
from pathlib import Path

a = sys.argv[1:]
if not a or a[0].startswith("--"):
    print(__doc__); sys.exit(1)
root = Path(a[0]).resolve()


def opt(k, d=None):
    return a[a.index(k) + 1] if k in a else d


fmt = opt("--format", "town")
root.mkdir(parents=True, exist_ok=True)
for d in ("scripts", "specs", "vo", "work/fonts", "work/auditions", "lua", "out", "upload", "music", "sfx", "publish", "library"):
    (root / d).mkdir(parents=True, exist_ok=True)
cfg = {
    "channel": {"name": opt("--name", root.name), "url": None if "--no-channel" in a else opt("--channel-url"), "profile": "CHANNEL.md"},
    "format": {"kind": fmt, "template": "town" if fmt in ("town", "general") else "none",
               "hook_prefix": "In this town," if fmt == "town" else ""},
    "brand": {"font_name": "Lilita One", "caption_position": opt("--caption-position", "middle"), "caption_color": opt("--caption-color", "#FFE533"),
              "thumb_prefix": "IN THIS TOWN," if fmt == "town" else "", "red_words": ["BANNED", "FOREVER", "VANISHES", "NEVER", "EVERYTHING"]},
    "ideas": {"viral_characters": opt("--viral-characters", "no") == "yes", "check_trends": opt("--trends", "yes") == "yes"},
    "publish": {"slots": opt("--slots", "07:00,16:00,20:00").split(","), "timezone": opt("--timezone", "Europe/London"),
                "made_for_kids": False, "shorts_per_day": 3},
    "render": {"fps": 30},
    "voice": {"narrator": "N", "single_voice": opt("--voices", "single") == "single", "language": "en", "whisper_model": "small.en", "fish_model": "s1"},
    "cast_voices": {"N": {"provider": opt("--narrator-provider", "edge"), "voice": opt("--narrator-voice", "en-GB-RyanNeural"), "speed": 1.0, "lufs": -14}},
    "audio": {"music": None, "sfx_dirs": []},
    "studio": {"place_name": "", "mcp_exe": None},
    "library_dir": opt("--library"),
    "library": {"save": "--no-library-save" not in sys.argv},
    "compilation": {"outro_line": "Thank you for watching! Like, subscribe and hit the bell so you never miss the next story!"},
}
pj = root / "project.json"
if pj.exists():
    old = json.loads(pj.read_text(encoding="utf-8"))
    old.update({k: v for k, v in cfg.items() if k not in old})
    cfg = old
pj.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
(root / "compilations.json").exists() or (root / "compilations.json").write_text("{}\n", encoding="utf-8")
prof = root / "CHANNEL.md"
if not prof.exists():
    prof.write_text(f"# {cfg['channel']['name']}\n\nChannel: {cfg['channel']['url'] or 'none yet'}\nFormat: {fmt}\n\n## World rule (the first line of every video)\n\n## Signature (identical in every video: the mute test)\n- Characters: one strong colour + one accessory each, a silhouette you'd recognise in black\n- Light/colour mood:\n- Voice:\n- Signature phrase:\n- Captions: {cfg['brand']['caption_position']}, {cfg['brand']['caption_color']}\n\n## Improve one thing per video (log)\n\n## Audience\n\n## What works (from analytics / research)\n\n## Running characters\n\n## Upload log\n", encoding="utf-8")
font = root / "work" / "fonts" / "LilitaOne-Regular.ttf"
if not font.exists():
    try:
        urllib.request.urlretrieve("https://github.com/google/fonts/raw/main/ofl/lilitaone/LilitaOne-Regular.ttf", font)
        print("font: Lilita One (SIL Open Font License) downloaded")
    except Exception as e:
        print("font download failed (captions fall back to Arial Bold):", e)
ign = root / ".gitignore"
ign.exists() or ign.write_text("frames_*/\nvo/*_parts/\nwork/comp/\nupload/\nout/*.mp4\n*.key\n", encoding="utf-8")
print("project ready:", root)
print("next: python", Path(__file__).parent / "check_setup.py", "--install   then bootstrap the Studio place (references/01-setup.md)")
