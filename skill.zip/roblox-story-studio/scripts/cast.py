"""cast.py - real-looking Roblox characters from the Roblox catalog, every one dressed differently.

  cast.py search shirt|pants|hair|hat|accessory "<words>" [--free] [--creator roblox|<userId>]   catalog search (cached in work/catalog_cache.json)
  cast.py add <key> --shirt ID --pants ID [--hair ID,ID] [--hats ID] [--back ID] [--neck ID] [--skin r,g,b] [--height 0.9]
              add/replace a character in <project>/cast.json
  cast.py auto <key> "<brief>"     pick a distinct shirt, pants and hair for a brief ("10 year old boy, red hoodie, messy brown hair")
  cast.py build                    build every cast.json entry as an avatar in ReplicatedStorage.CastAvatars (Studio Edit)
  cast.py check                    list duplicates (same shirt/pants/hair on two characters = fix before rendering)

Stories use them with  K.char("Leo", {avatar = "leo"}, stage)  (story template cast block).
Catalog items are used, not owned: HumanoidDescription shows any catalog item in your own place. Pick items whose
look fits the brief, with no brand logos, no real people's likeness, and nothing tagged for another game's IP."""
import os, sys, json, time, urllib.request, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rss

# catalog search: Category/Subcategory pairs that work on catalog.roblox.com/v1/search/items/details
KINDS = {"shirt": (3, 56), "pants": (3, 57), "tshirt": (3, 55), "hair": (11, 19), "hat": (11, 19), "accessory": (11, 19)}
API = "https://catalog.roblox.com/v1/search/items/details"


def _cache():
    p = rss.need_project() / "work" / "catalog_cache.json"
    return p, (json.loads(p.read_text(encoding="utf-8")) if p.exists() else {})


def search(kind, words, free=False, limit=30, creator=None):
    cat, sub = KINDS[kind]
    q = {"Category": cat, "Subcategory": sub, "Keyword": words if kind not in ("hair",) or "hair" in words else words + " hair", "Limit": limit}
    if free: q["MaxPrice"] = 0
    if creator:                                  # "roblox" = official Roblox items (clean, classic look); or a numeric user id
        q["CreatorTargetId"] = 1 if creator.lower() == "roblox" else int(creator); q["CreatorType"] = "User"
    url = API + "?" + urllib.parse.urlencode(q)
    p, cache = _cache()
    if url in cache:
        return cache[url]
    for attempt in range(6):                      # the catalog API rate-limits hard: back off and retry
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "roblox-story-studio"}), timeout=30) as r:
                d = json.loads(r.read())
            if "data" in d:
                rows = [{"id": x["id"], "name": x["name"], "type": x.get("assetType"), "fav": x.get("favoriteCount", 0), "price": x.get("price")} for x in d["data"]]
                cache[url] = rows; p.write_text(json.dumps(cache), encoding="utf-8")
                return rows
        except Exception:
            pass
        time.sleep(4 * (attempt + 1))
    return []


def load():
    p = rss.need_project() / "cast.json"
    return p, (json.loads(p.read_text(encoding="utf-8")) if p.exists() else [])


def save(p, cast):
    p.write_text(json.dumps(cast, indent=1), encoding="utf-8")


def used(cast, skip=None):
    u = set()
    for c in cast:
        if c["key"] == skip: continue
        for k in ("shirt", "pants"):
            if c.get(k): u.add(c[k])
        for k in ("hair", "hats"):
            u.update(c.get(k, []))
    return u


def add(key, opts, cast):
    c = {"key": key}
    if "--shirt" in opts: c["shirt"] = int(opts["--shirt"])
    if "--pants" in opts: c["pants"] = int(opts["--pants"])
    for k in ("hair", "hats", "back", "neck", "waist", "faceacc"):
        if f"--{k}" in opts: c[k] = [int(x) for x in opts[f"--{k}"].split(",") if x]
    if "--skin" in opts: c["skin"] = [int(x) for x in opts["--skin"].split(",")]
    if "--height" in opts: c["height"] = float(opts["--height"])
    cast = [x for x in cast if x["key"] != key] + [c]
    return cast


def auto(key, brief, cast):
    taken = used(cast, key)
    words = brief.lower()
    def pick(kind, kw):
        for row in sorted(search(kind, kw), key=lambda r: -r["fav"]):
            if row["id"] not in taken:
                taken.add(row["id"]); return row
        return None
    shirt_kw = next((w for w in ("hoodie", "jacket", "suit", "uniform", "dress", "sweater", "t-shirt", "shirt") if w in words), "shirt")
    colour = next((w for w in ("red", "blue", "green", "yellow", "black", "white", "pink", "purple", "orange", "grey", "brown") if w in words), "")
    s = pick("shirt", f"{colour} {shirt_kw}".strip()); time.sleep(1.5)
    pn = pick("pants", "jeans" if "jeans" in words else ("skirt" if "skirt" in words else "pants")); time.sleep(1.5)
    hair_kw = " ".join(w for w in ("long", "short", "messy", "curly", "ponytail", "bun", "spiky", "brown", "black", "blonde", "ginger", "grey", "white") if w in words) or "hair"
    h = pick("hair", hair_kw + " hair")
    c = {"key": key, "brief": brief}
    if s: c["shirt"] = s["id"]
    if pn: c["pants"] = pn["id"]
    if h: c["hair"] = [h["id"]]
    for row, nm in ((s, "shirt"), (pn, "pants"), (h, "hair")):
        print(f"  {nm}: {row['id']} {row['name'][:40]}" if row else f"  {nm}: none found - try cast.py search")
    return [x for x in cast if x["key"] != key] + [c]


def build(cast):
    from bridge import Studio
    lua = (rss.ASSETS / "studio" / "cast_build.lua").read_text(encoding="utf-8").replace("@CAST_JSON@", json.dumps(cast))
    s = Studio()
    try:
        print(s.lua("Edit", lua, 300))
    finally:
        s.close()
    print("Remember: save the place (Ctrl+S or MCP save_place) so the avatars persist.")


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit()
    if a[0] == "search":
        cr = a[a.index("--creator") + 1] if "--creator" in a else None
        for r in sorted(search(a[1], a[2], "--free" in a, creator=cr), key=lambda r: -r["fav"]):
            print(r["id"], "|", r["name"][:50], "| favs", r["fav"], "| price", r["price"])
        sys.exit()
    p, cast = load()
    if a[0] == "add":
        opts = {a[i]: a[i + 1] for i in range(2, len(a) - 1, 2)}
        cast = add(a[1], opts, cast); save(p, cast); print("saved", a[1])
    elif a[0] == "auto":
        cast = auto(a[1], a[2], cast); save(p, cast)
    elif a[0] == "build":
        build(cast)
    elif a[0] == "check":
        seen = {}
        for c in cast:
            for k in ("shirt", "pants"):
                if c.get(k): seen.setdefault((k, c[k]), []).append(c["key"])
            for h in c.get("hair", []): seen.setdefault(("hair", h), []).append(c["key"])
        dup = {k: v for k, v in seen.items() if len(v) > 1}
        print("duplicates:", dup if dup else "none - every character is dressed differently")
