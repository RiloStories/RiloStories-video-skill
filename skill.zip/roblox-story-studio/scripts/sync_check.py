"""sync_check.py NN [--land]       verify a finished video before anyone sees it
sync_check.py comp KEY           verify a compilation: every story's audio lines up with its video

Checks (all caught real bugs once):
  * frames on disk == frames expected, no gaps in the numbering
  * video stream length vs audio stream length (a 16:9 file once had 47 s of picture and 76 s of voice)
  * caption words vs voice: 4 spot checks that the word on screen at time t is the word spoken at t (needs Pillow only:
    it compares against work/words_NN.json and reports the times so you can eyeball the frames it saves)
Prints SYNC PASS or SYNC FAIL."""
import os, sys, json, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rss

R = rss.need_project()


def streams(p):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,duration", "-of", "csv=p=0", str(p)], capture_output=True, text=True).stdout
    d = {}
    for line in r.strip().splitlines():
        k, v = line.split(",")[:2]
        d[k] = float(v)
    return d


def pcm(f, ss, t):
    import numpy as np
    r = subprocess.run(["ffmpeg", "-v", "error", "-ss", str(ss), "-t", str(t), "-i", str(f), "-ac", "1", "-ar", "8000", "-f", "s16le", "-"], capture_output=True)
    return np.frombuffer(r.stdout, np.int16).astype(float)


a = sys.argv[1:]
fails = []
if a[0] == "comp":
    import numpy as np
    key = a[1]; W = R / "work" / "comp"; comp = R / "out" / f"comp_{key}.mp4"
    vids = json.loads((R / "compilations.json").read_text(encoding="utf-8"))[key]["vids"]
    t = 0.0
    for n in vids:
        for part in (W / f"{key}_c{n}.mp4", W / f"{key}_s{n}.mp4"):
            d = streams(part)
            if part.name.startswith(f"{key}_s"):
                ref = pcm(part, 10, 6); got = pcm(comp, t + 9, 8)
                off = np.correlate(got, ref, "valid").argmax() / 8000 - 1
                print(f"{part.name}: starts {t:.2f}s, audio offset {off:+.3f}s")
                if abs(off) > 0.08: fails.append(f"{part.name} audio offset {off:+.3f}s")
            if abs(d.get("video", 0) - d.get("audio", 0)) > 0.1: fails.append(f"{part.name} video {d.get('video')} vs audio {d.get('audio')}")
            t += d.get("video", 0)
else:
    num = a[0]; land = "--land" in a
    st = json.loads((R / "work" / f"story_{num}.json").read_text())
    fr = rss.frames_dir(num, land)
    files = sorted(fr.glob("*.jpg"))
    idx = sorted(int(p.stem) for p in files)
    need = int(round(st["cta_start"] * rss.FPS))
    gaps = [i for i in range(idx[0] if idx else 0, need) if i not in set(idx)] if idx else list(range(need))
    print(f"frames: {len(files)} on disk, {need} story frames needed, gaps: {len(gaps)} {gaps[:10]}")
    if gaps: fails.append(f"{len(gaps)} missing frames")
    out = R / "out" / (f"{num}_16x9.mp4" if land else f"{num}_final.mp4")
    d = streams(out)
    print(f"{out.name}: video {d.get('video', 0):.2f}s audio {d.get('audio', 0):.2f}s")
    if d.get("video", 0) < d.get("audio", 0) - 0.25: fails.append("video track shorter than audio (frames missing or stopped early)")
    words = json.loads((R / "work" / f"words_{num}.json").read_text(encoding="utf-8"))
    if words:
        picks = [words[int(len(words) * f)] for f in (0.15, 0.4, 0.65, 0.9)]
        chk = R / "work" / f"sync_{num}"; chk.mkdir(exist_ok=True)
        for w in picks:
            tm = (w["s"] + w["e"]) / 2
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{tm:.2f}", "-i", str(out), "-frames:v", "1", "-vf", "scale=360:-1", str(chk / f"{tm:06.2f}_{w['w'].strip('.,!?')}.jpg")])
        print(f"caption spot checks saved to {chk} (file name = time_expectedword; the caption on each frame must show that word)")
print("SYNC PASS" if not fails else "SYNC FAIL: " + "; ".join(fails))
