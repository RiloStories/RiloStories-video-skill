import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import rss
import ctypes as c
from ctypes import wintypes as w
from PIL import Image
import json
from pathlib import Path

u=c.windll.user32;g=c.windll.gdi32
try:c.windll.shcore.SetProcessDpiAwareness(2)
except Exception:u.SetProcessDPIAware()
u.FindWindowW.restype=w.HWND
u.GetDC.restype=w.HDC;u.GetDC.argtypes=[w.HWND]
g.CreateCompatibleDC.restype=w.HDC;g.CreateCompatibleDC.argtypes=[w.HDC]
g.CreateCompatibleBitmap.restype=w.HBITMAP;g.CreateCompatibleBitmap.argtypes=[w.HDC,c.c_int,c.c_int]
g.SelectObject.restype=w.HANDLE;g.SelectObject.argtypes=[w.HDC,w.HANDLE]
g.GetDIBits.argtypes=[w.HDC,w.HBITMAP,w.UINT,w.UINT,c.c_void_p,c.c_void_p,w.UINT]
g.DeleteObject.argtypes=[w.HANDLE];g.DeleteDC.argtypes=[w.HDC]
u.ReleaseDC.argtypes=[w.HWND,w.HDC]
u.PrintWindow.argtypes=[w.HWND,w.HDC,w.UINT]
u.SetWindowPos.argtypes=[w.HWND,w.HWND,c.c_int,c.c_int,c.c_int,c.c_int,w.UINT]

class Capture:
 def __init__(self):
  self.h=None
  if True:
   found=[]
   CB=c.WINFUNCTYPE(c.c_bool,w.HWND,w.LPARAM)
   def cb(hw,lp):
    n=u.GetWindowTextLengthW(hw)
    if n and u.IsWindowVisible(hw):
     b=c.create_unicode_buffer(n+1);u.GetWindowTextW(hw,b,n+1)
     if b.value.endswith('- Roblox Studio'):found.append(hw)
    return True
   u.EnumWindows(CB(cb),0)
   if found:self.h=found[0]
  if not self.h:raise RuntimeError('Studio window not found')
 def save_geometry(self,path):
  r=w.RECT();u.GetWindowRect(self.h,c.byref(r))
  Path(path).write_text(json.dumps({'rect':[r.left,r.top,r.right-r.left,r.bottom-r.top],'maximized':bool(u.IsZoomed(self.h))}))
 def resize(self,width,height):
  u.ShowWindow(self.h,9)
  if not u.SetWindowPos(self.h,None,0,0,width,height,0x0014):raise c.WinError()
 def restore(self,path):
  d=json.loads(Path(path).read_text());u.SetWindowPos(self.h,None,*d['rect'],0x0014)
  if d['maximized']:u.ShowWindow(self.h,3)
 def jiggle(self):
  import time
  for i in range(8):
   u.SetCursorPos(u.GetSystemMetrics(0)-80+(i%2)*6,u.GetSystemMetrics(1)-45);time.sleep(0.06)
 def nudge(self):
  import time
  u.ShowWindow(self.h,9);time.sleep(0.8);u.ShowWindow(self.h,3);time.sleep(0.8);u.keybd_event(0x12,0,0,0);u.keybd_event(0x12,0,2,0);u.SetWindowPos(self.h,-1,0,0,0,0,0x0003);u.SetWindowPos(self.h,-2,0,0,0,0,0x0003);u.BringWindowToTop(self.h);u.SetForegroundWindow(self.h);time.sleep(0.5);self.jiggle();u.SetCursorPos(u.GetSystemMetrics(0)-80,u.GetSystemMetrics(1)-45);time.sleep(1.0)
 def pin(self):
  u.SetWindowPos(self.h,-1,0,0,0,0,0x0003);u.ShowWindow(self.h,3)
 def grab(self):
  r=w.RECT();u.GetClientRect(self.h,c.byref(r));width,height=r.right,r.bottom
  dc=u.GetDC(self.h);mem=g.CreateCompatibleDC(dc);bmp=g.CreateCompatibleBitmap(dc,width,height);old=g.SelectObject(mem,bmp)
  try:
   if not u.PrintWindow(self.h,mem,3):raise RuntimeError('PrintWindow failed')
   class BI(c.Structure):
    _fields_=[('size',w.DWORD),('width',w.LONG),('height',w.LONG),('planes',w.WORD),('bitcount',w.WORD),('compression',w.DWORD),('sizeimage',w.DWORD),('xppm',w.LONG),('yppm',w.LONG),('used',w.DWORD),('important',w.DWORD)]
   info=BI(c.sizeof(BI),width,-height,1,32,0,0,0,0,0,0);buffer=c.create_string_buffer(width*height*4)
   g.GetDIBits(mem,bmp,0,height,buffer,c.byref(info),0)
   return Image.frombuffer('RGB',(width,height),buffer,'raw','BGRX',0,1).copy()
  finally:g.SelectObject(mem,old);g.DeleteObject(bmp);g.DeleteDC(mem);u.ReleaseDC(self.h,dc)

if __name__=='__main__':
 import time
 v=Capture();v.save_geometry('window_geometry.json');v.resize(2560,1600);time.sleep(2)
 im=v.grab();im.save('highres_test.png');print(im.size)






