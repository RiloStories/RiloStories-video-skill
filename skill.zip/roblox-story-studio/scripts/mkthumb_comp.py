"""mkthumb_comp.py A|B|C|D -> out/comp_X_thumb.jpg : 1920x1080, 'IN THIS TOWN, ...' headline + four vertical key frames, one from each of the four videos."""
import sys
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
import mkthumb_short as S
R = S.R
W, H = 1920, 1080
import json
_C = json.loads((R / "compilations.json").read_text(encoding="utf-8"))
HEAD = {k: v.get("thumb_head", "EVERYTHING GETS BANNED!") for k, v in _C.items()}
VIDS = {k: v["vids"] for k, v in _C.items()}
PREFIX = S.PREFIX


def rounded(im, r):
    m = Image.new("L", im.size, 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, im.size[0] - 1, im.size[1] - 1], r, fill=255)
    im = im.convert("RGBA"); im.putalpha(m); return im


def make(c):
    frames = [S.pick_frame(int(n))[1]["fr"] for n in VIDS[c]]
    bg = Image.open(frames[1]).convert("RGB").resize((W, int(W * 16 / 9))).crop((0, 300, W, 300 + H)).filter(ImageFilter.GaussianBlur(28))
    bg = ImageEnhance.Brightness(bg).enhance(0.45)
    grad = Image.new("RGB", (W, H)); gd = ImageDraw.Draw(grad)
    for y in range(H):
        k = y / H; gd.line([(0, y), (W, y)], fill=(int(40 + 40 * k), int(20 + 10 * k), int(90 - 30 * k)))
    bg = Image.blend(bg, grad, 0.45); d = ImageDraw.Draw(bg)
    f1, s1 = S.fit(d, PREFIX, 118, 1800)
    w1 = d.textlength(PREFIX, font=f1); d.text(((W - w1) / 2, 14), PREFIX, font=f1, fill=(255, 255, 255), stroke_width=10, stroke_fill=(0, 0, 0))
    rest = HEAD[c]; f2, s2 = S.fit(d, rest, 150, 1800); words = rest.split(" ")
    x = (W - d.textlength(rest, font=f2)) / 2; y = 14 + s1 + 4
    for w in words:
        col = (255, 70, 70) if w.strip("!") in S.RED_WORDS else (255, 226, 60)
        d.text((x, y), w + " ", font=f2, fill=col, stroke_width=12, stroke_fill=(0, 0, 0)); x += d.textlength(w + " ", font=f2)
    fh = 700; fw = int(fh * 9 / 16); gap = 36; x0 = (W - (4 * fw + 3 * gap)) // 2; top = H - fh - 40
    cv = bg.convert("RGBA")
    for i, p in enumerate(frames):
        im = Image.open(p).convert("RGB").resize((fw, fh), Image.LANCZOS)
        im = ImageEnhance.Color(ImageEnhance.Contrast(im).enhance(1.1)).enhance(1.15)
        tile = rounded(Image.new("RGBA", (fw + 16, fh + 16), (255, 255, 255, 255)), 34); tile.alpha_composite(rounded(im, 28), (8, 8))
        sh = Image.new("RGBA", cv.size, (0, 0, 0, 0))
        ImageDraw.Draw(sh).rounded_rectangle([x0 + i * (fw + gap) + 10, top + 14, x0 + i * (fw + gap) + fw + 26, top + fh + 30], 34, fill=(0, 0, 0, 150))
        cv = Image.alpha_composite(cv, sh.filter(ImageFilter.GaussianBlur(10))); cv.alpha_composite(tile, (x0 + i * (fw + gap) - 8, top - 8))
    out = R / "out" / f"comp_{c}_thumb.jpg"; cv.convert("RGB").save(out, quality=92); print(out.name, out.stat().st_size // 1024, "KB")


for a in sys.argv[1:]:
    make(a)
