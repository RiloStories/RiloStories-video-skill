import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import rss
import subprocess, json, threading, queue, time
EXE = rss.studio_mcp_exe()

class Studio:
    def __init__(self, name=None):
        name = name or rss.cfg("studio.place_name", "")
        self.p = subprocess.Popen([EXE, '--stdio'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, encoding='utf-8')
        self.q = queue.Queue(); self.i = 0
        threading.Thread(target=self.read, daemon=True).start()
        self.request('initialize', {'protocolVersion': '2024-11-05', 'capabilities': {}, 'clientInfo': {'name': 'roblox-story-studio', 'version': '1.0'}})
        self.p.stdin.write('{"jsonrpc":"2.0","method":"notifications/initialized"}\n'); self.p.stdin.flush()
        self.sid = None
        for _ in range(15):
            time.sleep(4)
            d = self.call('list_roblox_studios', {})
            studios = json.loads(d['content'][0]['text'])['studios']
            m = [s['id'] for s in studios if name and s.get('name') and name in s['name']]
            if not m: m = [s['id'] for s in studios]
            if m: self.sid = m[0]; break
        if not self.sid: raise RuntimeError('Studio place not found via MCP')

    def read(self):
        for line in self.p.stdout:
            try: self.q.put(json.loads(line))
            except ValueError: pass

    def request(self, method, params, timeout=90):
        self.i += 1; my = self.i
        self.p.stdin.write(json.dumps({'jsonrpc': '2.0', 'id': my, 'method': method, 'params': params}) + '\n'); self.p.stdin.flush()
        end = time.time() + timeout
        while time.time() < end:
            try: d = self.q.get(timeout=1)
            except queue.Empty: continue
            if d.get('id') == my:
                if 'error' in d: raise RuntimeError(d['error'])
                return d['result']
        raise TimeoutError(method)

    def call(self, name, args, timeout=90): return self.request('tools/call', {'name': name, 'arguments': args}, timeout)

    def lua(self, dm, code, timeout=90):
        d = self.call('execute_luau', {'studio_id': self.sid, 'datamodel_type': dm, 'code': code}, timeout)
        txt = '\n'.join(c.get('text', '') for c in d.get('content', []))
        if d.get('isError'): raise RuntimeError(txt)
        return txt

    def play(self, on): return self.call('start_stop_play', {'studio_id': self.sid, 'is_start': on})
    def close(self): self.p.terminate()
