"""Sample SFX from the user's own sound folders (project sfx/ + audio.sfx_dirs in project.json).
smp('funny fall') -> mono samples at 44.1 kHz. If no file matches, a synthesized stand-in is returned so a render never fails."""
import os, sys, subprocess, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rss
_idx = None
MISSING = set()


def _index():
    global _idx
    if _idx is None:
        _idx = {}
        for rt in rss.sfx_dirs():
            for d, _, fs in os.walk(rt):
                for f in fs:
                    if f.lower().endswith((".mp3", ".wav", ".ogg")):
                        _idx.setdefault(f.lower(), os.path.join(d, f))
    return _idx


def find(name):
    n = name.lower()
    for k, v in _index().items():
        if n in k:
            return v
    words = [w for w in n.split() if len(w) > 2]
    for k, v in _index().items():
        if words and all(w in k for w in words):
            return v
    return None


def _fallback(name, dur):
    import sfx
    n = name.lower(); d = dur or 0.6
    if any(w in n for w in ("whoosh", "swoosh", "swish")): return sfx.whoosh(d)
    if any(w in n for w in ("hit", "thud", "punch", "boom", "fall")): return sfx.thud(min(d, 0.6))
    if any(w in n for w in ("bell", "ding", "chime", "sparkle", "magic")): return sfx.chime(max(d, 0.8))
    if any(w in n for w in ("door", "slam")): return sfx.slam()
    if any(w in n for w in ("step", "walk", "run")): return sfx.footsteps(max(d, 1.0))
    if any(w in n for w in ("click", "pop", "tap")): return sfx.click()
    if any(w in n for w in ("gasp", "shock")): return sfx.gasp()
    return sfx.whoosh(d)


def smp(name, dur=None, start=0.0, peak=0.9, path=None):
    p = path or find(name)
    if not p:
        if name not in MISSING:
            MISSING.add(name); print("libsfx: no file for '%s', using a synth stand-in" % name, file=sys.stderr)
        x = np.asarray(_fallback(name, dur), float)
    else:
        cmd = ["ffmpeg", "-v", "error", "-ss", str(start)] + (["-t", str(dur)] if dur else []) + ["-i", p, "-f", "f32le", "-ac", "1", "-ar", "44100", "-"]
        x = np.frombuffer(subprocess.run(cmd, capture_output=True).stdout, np.float32).astype(float)
    m = np.max(np.abs(x)) if len(x) else 1
    x = x / (m or 1) * peak
    n = int(0.01 * 44100)
    if len(x) > 2 * n: x[-n:] *= np.linspace(1, 0, n)
    return x
