"""research.py - study a niche, a channel or a video with yt-dlp + ffmpeg (no API keys).

  research.py niche "<search words>" [--n 30]          top videos for a search: views, channel, length -> work/research/niche_*.md
  research.py channel <channel url> [--n 40]           a channel's recent Shorts and long-form with views, best and worst titles
  research.py frames <video url> [--n 16]              scene-change frames + shot-change rate + words/min (auto subs)
  research.py mine                                     your own channel (project.json channel.url): what worked, what didn't
  research.py trends ["<topic>"]                       trend scan: rising Roblox/TikTok-style topics on YouTube Shorts this month

Frames from other people's videos are for private study only (lighting, set density, pacing): never put them in a
video, a thumbnail or a product. Output goes to <project>/work/research/ (or ./research if no project)."""
import os, sys, json, re, subprocess, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rss
from pathlib import Path

OUT = (rss.R / "work" / "research") if rss.R else Path("research")
OUT.mkdir(parents=True, exist_ok=True)


def ytdlp(*args):
    r = subprocess.run(["yt-dlp", *args], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0 and not r.stdout:
        sys.exit("yt-dlp failed (pip install -U yt-dlp): " + r.stderr[-300:])
    return r.stdout


def rows(text):
    out = []
    for line in text.strip().splitlines():
        p = line.split("|")
        if len(p) >= 5:
            try: views = int(p[3]) if p[3] not in ("NA", "None", "") else 0
            except ValueError: views = 0
            out.append({"id": p[0], "title": p[1], "channel": p[2], "views": views, "dur": p[4], "url": f"https://youtube.com/watch?v={p[0]}"})
    return out


FMT = "%(id)s|%(title)s|%(channel)s|%(view_count)s|%(duration)s"


def niche(q, n):
    vids = rows(ytdlp(f"ytsearch{n}:{q}", "--flat-playlist", "--print", FMT))
    vids.sort(key=lambda v: -v["views"])
    by = {}
    for v in vids: by.setdefault(v["channel"], []).append(v["views"])
    md = [f"# Niche: {q} ({datetime.date.today()})", "", "| views | channel | title | secs |", "|---:|---|---|---:|"]
    md += [f"| {v['views']:,} | {v['channel']} | [{v['title'][:70]}]({v['url']}) | {v['dur']} |" for v in vids]
    md += ["", "## Channels in this niche", ""] + [f"- {c}: {len(vs)} results, best {max(vs):,} views" for c, vs in sorted(by.items(), key=lambda kv: -max(kv[1]))]
    md += ["", "## Title patterns (most common opening words)", ""]
    starts = {}
    for v in vids:
        k = " ".join(v["title"].split()[:3]).lower(); starts[k] = starts.get(k, 0) + 1
    md += [f"- \"{k}\" x{c}" for k, c in sorted(starts.items(), key=lambda kv: -kv[1])[:10]]
    p = OUT / f"niche_{re.sub(r'[^a-z0-9]+', '_', q.lower())[:40]}.md"; p.write_text("\n".join(md), encoding="utf-8"); print(p)


def channel(url, n):
    url = url.rstrip("/")
    md = [f"# Channel {url} ({datetime.date.today()})", ""]
    for tab in ("shorts", "videos"):
        vids = rows(ytdlp(f"{url}/{tab}", "--flat-playlist", "--playlist-end", str(n), "--print", FMT))
        if not vids: continue
        vs = sorted(v["views"] for v in vids); med = vs[len(vs) // 2]
        md += [f"## {tab}: {len(vids)} recent, median {med:,} views", "", "Best:"] + [f"- {v['views']:,}  {v['title']}" for v in sorted(vids, key=lambda v: -v["views"])[:8]]
        md += ["", "Worst:"] + [f"- {v['views']:,}  {v['title']}" for v in sorted(vids, key=lambda v: v["views"])[:5]] + [""]
        md += ["Outliers (>= 3x median): " + ", ".join(f"\"{v['title'][:50]}\"" for v in vids if med and v["views"] >= 3 * med), ""]
    p = OUT / f"channel_{re.sub(r'[^a-z0-9]+', '_', url.lower())[-40:]}.md"; p.write_text("\n".join(md), encoding="utf-8"); print(p)


def frames(url, n):
    d = OUT / "frames"; d.mkdir(exist_ok=True)
    vid = ytdlp(url, "--print", "id", "--skip-download").strip().splitlines()[-1]
    f = d / f"{vid}.mp4"
    subprocess.run(["yt-dlp", "-f", "bv*[height<=720]+ba/b[height<=720]", "--merge-output-format", "mp4", "-o", str(f), url, "--write-auto-subs", "--sub-langs", "en", "--sub-format", "vtt"], capture_output=True)
    dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(f)], capture_output=True, text=True).stdout or 1)
    cuts = subprocess.run(["ffmpeg", "-i", str(f), "-vf", "select='gt(scene,0.3)',showinfo", "-f", "null", "-"], capture_output=True, text=True).stderr.count("showinfo")
    subprocess.run(["ffmpeg", "-v", "error", "-i", str(f), "-vf", "select='gt(scene,0.3)',scale=540:-1", "-vsync", "vfr", "-frames:v", str(n), str(d / f"{vid}_%03d.jpg")])
    wpm = None
    vtt = next(iter(d.glob(f"{vid}*.vtt")), None)
    if vtt:
        txt = re.sub(r"<[^>]+>|\d\d:\d\d[^\n]*|WEBVTT.*", " ", vtt.read_text(encoding="utf-8", errors="ignore"))
        words = len(dict.fromkeys(txt.split())); wpm = round(words / dur * 60)
    f.unlink(missing_ok=True)
    print(f"{vid}: {dur:.0f}s, {cuts / dur * 60:.0f} shot changes/min, ~{wpm} words/min; frames in {d} ({vid}_*.jpg)")


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit()
    n = int(a[a.index("--n") + 1]) if "--n" in a else 30
    if a[0] == "niche": niche(a[1], n)
    elif a[0] == "channel": channel(a[1], n)
    elif a[0] == "frames": frames(a[1], n if "--n" in a else 16)
    elif a[0] == "mine":
        u = rss.cfg("channel.url") or sys.exit("no channel.url in project.json")
        channel(u, 60)
    elif a[0] == "trends":
        topic = a[1] if len(a) > 1 else "roblox"
        for q in (f"{topic} shorts trend", f"{topic} tiktok trend", f"{topic} viral", f"{topic} meme"):
            niche(q + " " + datetime.date.today().strftime("%B %Y"), 25)
        print("Read the files; trends = topics/characters/sounds that appear in several of them with high views from small channels.")
