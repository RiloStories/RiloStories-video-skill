"""qa_sheet.py NN [NN ...] : one contact sheet per video, one tile per beat (frame at the beat midpoint) with the narration line printed under it.
Output work/qa_NN.jpg. Lets a reviewer check that what is on screen matches what the narrator says."""
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import rss
import sys, json, importlib.util, textwrap
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
R = rss.need_project()
_sys.path.insert(0, str(R / "specs"))
F = ImageFont.truetype(rss.font_file(), 15)
for num in sys.argv[1:]:
    lines = [l.strip() for l in (R / "scripts" / f"{num}.txt").read_text(encoding="utf-8").splitlines() if l.strip()]
    st = json.loads((R / "work" / f"story_{num}.json").read_text())
    starts, cta = st["starts"], st["cta_start"]
    sp = importlib.util.spec_from_file_location("s", R / "specs" / f"spec{num}.py"); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
    tiles = []
    for b in m.BEATS:
        a, z = b["lines"]
        t0 = starts[a]; t1 = starts[z + 1] if z + 1 < len(starts) else cta
        if "t" in b:
            t0, t1 = b["t"]
        elif "frac" in b:
            f0, f1 = b["frac"]; L = t1 - t0; t0, t1 = t0 + f0 * L, t0 + f1 * L
        t = (t0 + t1) / 2
        fr = R / f"frames_{num}" / f"{int(round(t * rss.FPS)):05d}.jpg"
        if not fr.exists(): continue
        wf = R / "work" / f"words_{num}_full.json"
        ws = json.loads(wf.read_text(encoding="utf-8")) if wf.exists() else []
        said = " ".join(w["w"] for w in ws if t0 - 0.05 <= w["s"] < t1 - 0.05) or lines[a]
        tiles.append((a, t, Image.open(fr).convert("RGB").resize((252, 448)), said))
    cols = 8; rows = (len(tiles) + cols - 1) // cols; W, H = 252, 448 + 92
    sheet = Image.new("RGB", (cols * W, rows * H), (20, 20, 24)); d = ImageDraw.Draw(sheet)
    for i, (a, t, im, txt) in enumerate(tiles):
        x, y = (i % cols) * W, (i // cols) * H
        sheet.paste(im, (x, y))
        cap = f"L{a} {t:.0f}s: " + txt
        for k, ln in enumerate(textwrap.wrap(cap, 30)[:5]): d.text((x + 4, y + 450 + k * 17), ln, fill=(255, 235, 120), font=F)
    out = R / "work" / f"qa_{num}.jpg"; sheet.save(out, quality=80); print(out, len(tiles), "tiles")
