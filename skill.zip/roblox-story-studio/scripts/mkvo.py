"""mkvo.py NN : multi-voice voiceover from scripts/NN_spk.txt -> vo/NN_vo.mp3 (+ scripts/NN.txt if missing).

scripts/NN_spk.txt, one script line per row:   SPEAKER|text
  several voices inside one line:               N|And then Leo said ## LEO|Wait for me! ## N|but nobody waited.
SPEAKER names map to project.json "cast_voices" (set them with voices.py set). Lines are joined with 0.3 s gaps,
segments inside a line with 0.08 s. After this: words.py NN (word timings), then gen_story.py NN."""
import os, sys, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rss, tts

R = rss.need_project(); num = sys.argv[1]
d = R / "vo" / f"{num}_parts"; d.mkdir(parents=True, exist_ok=True)
spk = R / "scripts" / f"{num}_spk.txt"
rows = [l.split("|", 1) for l in spk.read_text(encoding="utf-8").splitlines() if l.strip()]
plain = R / "scripts" / f"{num}.txt"
if not plain.exists():
    import re
    plain.write_text("\n".join(re.sub(r"\s*##\s*[A-Z0-9_]+\|", " ", t).strip() for _, t in rows) + "\n", encoding="utf-8")


def sil(name, secs):
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=mono", "-t", str(secs), "-c:a", "pcm_s16le", str(d / name)], check=True)


sil("sil.wav", 0.3); sil("sil_s.wav", 0.08)
lst = []
for i, (sp, text) in enumerate(rows):
    segs = [(sp, text)]
    if " ## " in text:
        segs = [(sp, text.split(" ## ")[0])] + [tuple(x.split("|", 1)) for x in text.split(" ## ")[1:]]
    parts = []
    for j, (s_, t_) in enumerate(segs):
        out = d / f"l{i:02d}_{j}.wav"
        if not out.exists():                       # re-runs only re-voice deleted lines
            tts.speak(tts.speaker_cfg(s_.strip()), t_.strip(), str(out))
        parts.append(out)
    if len(parts) == 1:
        line = parts[0]
    else:
        line = d / f"l{i:02d}.wav"
        (d / f"m{i}.txt").write_text("".join(f"file '{p.name}'\nfile 'sil_s.wav'\n" for p in parts[:-1]) + f"file '{parts[-1].name}'\n", encoding="utf-8")
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(d / f"m{i}.txt"), "-ar", "44100", "-ac", "1", str(line)], check=True)
    lst += [line, d / "sil.wav"]
    print(i, sp, round(tts.dur(line), 1), "s", flush=True)
(d / "list.txt").write_text("".join(f"file '{p.name}'\n" for p in lst[:-1]), encoding="utf-8")
out = R / "vo" / f"{num}_vo.mp3"
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(d / "list.txt"), "-ac", "1", "-ar", "44100", "-c:a", "libmp3lame", "-b:a", "192k", str(out)], check=True)
total = tts.dur(out); words = sum(len(t.split()) for _, t in rows)
print(f"{out.name}: {total:.1f} s, {words} words, {words / total * 60:.0f} wpm (target 150-185 for Shorts)")
if total > 0.65 * words + 6:
    print("WARNING: voiceover is much longer than the word count suggests - listen for a hallucinated take before continuing")
