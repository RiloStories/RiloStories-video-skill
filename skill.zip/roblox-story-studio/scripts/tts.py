"""tts.py - one text-to-speech front end for every provider. Used by mkvo.py, compile.py and voices.py.

Providers (pick per speaker in project.json "cast_voices"):
  fish        Fish Audio API (key FISH_API_KEY). Huge public voice library + cloning. voice = model id.
  elevenlabs  ElevenLabs API (key ELEVENLABS_API_KEY). voice = voice_id. Library + cloning.
  openai      OpenAI TTS (key OPENAI_API_KEY). voice = alloy|ash|ballad|coral|echo|fable|nova|onyx|sage|shimmer|verse.
  edge        Microsoft Edge online voices via the free `edge-tts` package. No key. voice = e.g. en-GB-RyanNeural.
  kokoro      Local, offline, free (`pip install kokoro soundfile`). voice = af_heart, am_michael, bf_emma, bm_george ...

CLI:
  tts.py say <SPEAKER> "<text>" <out.wav>            speak with a cast voice from project.json
  tts.py raw <provider> <voice> "<text>" <out.wav> [speed]
Every output is mono 44.1 kHz WAV, cleaned and loudness-normalised (per-speaker LUFS)."""
import os, sys, json, subprocess, tempfile, urllib.request, urllib.error
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rss

CLEAN = "highpass=f=90,afftdn=nr=18:nf=-40,lowpass=f=9000,"


def _post(url, headers, body, out_path, timeout=180):
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = r.read()
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"{url} -> HTTP {e.code}: {e.read()[:300]!r}")
    open(out_path, "wb").write(data)
    return out_path


def _need(name):
    k = rss.secret(name)
    if not k:
        sys.exit(f"No API key for {name}. Set the env var or save it to ~/.rss-keys/{name}.key (see references/04-voice.md).")
    return k


def synth_raw(provider, voice, text, out_audio, speed=1.0, extra=None):
    """Writes the provider's native audio (wav/mp3) to out_audio. Returns the path."""
    extra = extra or {}
    if provider == "fish":
        body = {"text": text, "reference_id": voice, "format": "wav", "normalize": True, "latency": "normal",
                "prosody": {"speed": speed, "volume": 0}}
        model = extra.get("model") or rss.cfg("voice.fish_model", "s1")
        return _post("https://api.fish.audio/v1/tts", {"Authorization": "Bearer " + _need("fish"), "Content-Type": "application/json", "model": model},
                     json.dumps(body).encode(), out_audio)
    if provider == "elevenlabs":
        body = {"text": text, "model_id": extra.get("model") or rss.cfg("voice.elevenlabs_model", "eleven_multilingual_v2"),
                "voice_settings": {"stability": extra.get("stability", 0.45), "similarity_boost": 0.8, "style": extra.get("style", 0.3), "speed": speed}}
        return _post(f"https://api.elevenlabs.io/v1/text-to-speech/{voice}?output_format=mp3_44100_128",
                     {"xi-api-key": _need("elevenlabs"), "Content-Type": "application/json"}, json.dumps(body).encode(), out_audio)
    if provider == "openai":
        body = {"model": extra.get("model", "gpt-4o-mini-tts"), "voice": voice, "input": text, "response_format": "wav", "speed": speed}
        if extra.get("instructions"):
            body["instructions"] = extra["instructions"]
        return _post("https://api.openai.com/v1/audio/speech", {"Authorization": "Bearer " + _need("openai"), "Content-Type": "application/json"},
                     json.dumps(body).encode(), out_audio)
    if provider == "edge":
        rate = f"{int(round((speed - 1) * 100)):+d}%"
        mp3 = os.path.splitext(out_audio)[0] + ".mp3"
        r = subprocess.run([sys.executable, "-m", "edge_tts", "--voice", voice, "--rate", rate, "--text", text, "--write-media", mp3], capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("edge-tts failed (pip install edge-tts): " + r.stderr[-300:])
        return mp3
    if provider == "kokoro":
        try:
            from kokoro import KPipeline
            import soundfile as sf, numpy as np
        except ImportError:
            sys.exit("Kokoro not installed: pip install kokoro soundfile  (first run downloads ~330 MB of model files)")
        lang = voice[0]  # a=US, b=UK, ...
        pipe = KPipeline(lang_code=lang)
        chunks = [a for _, _, a in pipe(text, voice=voice, speed=speed)]
        sf.write(out_audio, np.concatenate(chunks), 24000)
        return out_audio
    sys.exit(f"unknown provider {provider}")


def dur(p):
    return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)], capture_output=True, text=True).stdout.strip() or 0)


def speak(spk_cfg, text, out_wav, _try=0):
    """spk_cfg = {"provider","voice","speed","lufs","clean","style","model",...}. Retries takes that run far too long
    (some models occasionally hallucinate extra speech: that once put 25 s of another story inside a voiceover)."""
    prov, voice = spk_cfg["provider"], spk_cfg["voice"]
    say = text
    if spk_cfg.get("style") and prov == "fish" and not text.startswith("["):
        say = spk_cfg["style"] + " " + text            # e.g. "[excited]" - Fish reads bracket tags as delivery hints
    tmp = tempfile.mkdtemp(prefix="rss_tts_")
    raw = synth_raw(prov, voice, say, os.path.join(tmp, "raw.wav"), spk_cfg.get("speed", 1.0), spk_cfg)
    flt = (CLEAN if spk_cfg.get("clean") else "") + f"loudnorm=I={spk_cfg.get('lufs', -14)}:TP=-1.5:LRA=9"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", raw, "-af", flt, "-ar", "44100", "-ac", "1", str(out_wav)], check=True)
    d = dur(out_wav)
    if d > 0.65 * len(text.split()) + 2.0 and _try < 4:
        print(f"  retry: {d:.1f}s take for {len(text.split())} words looks hallucinated", flush=True)
        return speak(spk_cfg, text, out_wav, _try + 1)
    return out_wav


def speaker_cfg(name):
    cast = rss.cfg("cast_voices", {})
    # voice.single_voice (default true): every character speaks in the narrator's voice, the style that works for these Shorts.
    # Set it to false in project.json to give each speaker their own voice (voices.py set <SPEAKER> ...).
    if rss.cfg("voice.single_voice", True):
        return cast[rss.cfg("voice.narrator", "N")]
    if name not in cast:
        sys.exit(f"speaker {name} not in project.json cast_voices ({', '.join(cast) or 'none set'}); add it with voices.py set")
    return cast[name]


if __name__ == "__main__":
    a = sys.argv[1:]
    if a and a[0] == "say":
        print(speak(speaker_cfg(a[1]), a[2], a[3]), round(dur(a[3]), 2), "s")
    elif a and a[0] == "raw":
        sp = float(a[5]) if len(a) > 5 else 1.0
        print(speak({"provider": a[1], "voice": a[2], "speed": sp}, a[3], a[4]), round(dur(a[4]), 2), "s")
    else:
        print(__doc__)
