"""rss.py - shared config for every Roblox Story Studio script.

The project folder is found from (1) env RSS_PROJECT, (2) the current folder or any parent that holds project.json.
Every path a script needs comes from here, so nothing is hard-coded to one machine.
"""
import os, sys, json, glob
from pathlib import Path

for _st in (sys.stdout, sys.stderr):          # emoji in titles/catalog names must not crash a Windows console
    try: _st.reconfigure(encoding="utf-8", errors="replace")
    except Exception: pass

S = Path(__file__).resolve().parent            # skill scripts folder
SKILL = S.parent                                # skill root (assets/, references/)
ASSETS = SKILL / "assets"


def _find_project():
    env = os.environ.get("RSS_PROJECT")
    if env and (Path(env) / "project.json").exists():
        return Path(env).resolve()
    p = Path.cwd().resolve()
    for q in [p, *p.parents]:
        if (q / "project.json").exists():
            return q
    return None


R = _find_project()
CFG = json.loads((R / "project.json").read_text(encoding="utf-8")) if R else {}


def need_project():
    if R is None:
        sys.exit("No project.json found. Run scripts/new_project.py first, or set RSS_PROJECT to the project folder.")
    return R


def cfg(key, default=None):
    cur = CFG
    for k in key.split("."):
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur


LAND = os.environ.get("RSS_LAND") == "1" or os.environ.get("RILO_LAND") == "1"
FPS = int(cfg("render.fps", 30))


def work(): return need_project() / "work"
def out(): return need_project() / "out"


def frames_dir(num, land=None):
    land = LAND if land is None else land
    return need_project() / (f"frames_{num}_16x9" if land else f"frames_{num}")


def font_file():
    """Caption / thumbnail font file (TTF). project fonts/ first, then the configured path."""
    f = cfg("brand.font_file")
    if f and Path(f).exists():
        return str(f)
    if R:
        for c in sorted((R / "work" / "fonts").glob("*.ttf")):
            return str(c)
    win = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "arialbd.ttf"
    return str(win)


def font_name():
    return cfg("brand.font_name", "Lilita One")


def symbol_font():
    win = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
    for n in ("seguisym.ttf", "seguiemj.ttf", "arial.ttf"):
        if (win / n).exists():
            return str(win / n)
    return font_file()


def roblox_versions():
    base = Path(os.environ.get("LOCALAPPDATA", "")) / "Roblox" / "Versions"
    return sorted(glob.glob(str(base / "version-*")), key=os.path.getmtime)


def studio_mcp_exe():
    exe = cfg("studio.mcp_exe")
    if exe and Path(exe).exists():
        return exe
    found = [str(Path(v) / "StudioMCP.exe") for v in roblox_versions() if (Path(v) / "StudioMCP.exe").exists()]
    if not found:
        sys.exit("StudioMCP.exe not found. Install Roblox Studio and turn on the Studio MCP server (see references/01-setup.md).")
    return found[-1]


def music_for(num):
    """Per-video track (work/music_NN.mp3/.wav from music.py) beats the project default."""
    if R:
        for ext in ("mp3", "wav"):
            p = R / "work" / f"music_{num}.{ext}"
            if p.exists():
                return str(p)
    m = cfg("audio.music")
    if m and Path(m).exists():
        return str(m)
    if R:
        cands = sorted((R / "music").glob("*.mp3")) + sorted((R / "music").glob("*.wav"))
        if cands:
            return str(cands[0])
    sys.exit("No music found. Run scripts/music.py to make a track, or put a royalty-free track in <project>/music/.")


def sfx_dirs():
    dirs = list(cfg("audio.sfx_dirs", []) or [])
    if R:
        dirs.append(str(R / "sfx"))
    return [d for d in dirs if Path(d).exists()]


def secret(name):
    """API keys: env var first (FISH_API_KEY, ELEVENLABS_API_KEY, OPENAI_API_KEY), then ~/.rss-keys/<name>.key.
    Keys are never written into project.json or printed."""
    env = {"fish": "FISH_API_KEY", "elevenlabs": "ELEVENLABS_API_KEY", "openai": "OPENAI_API_KEY"}.get(name, name.upper() + "_API_KEY")
    if os.environ.get(env):
        return os.environ[env].strip()
    p = Path.home() / ".rss-keys" / f"{name}.key"
    if p.exists():
        return p.read_text().strip()
    return None
