"""music.py - background music for a video. Every option here is free to use on YouTube (no Content ID claims) because the
track is generated for you, except `library` tracks, whose licence you must check.

  music.py compose --mood happy [--bpm 118] [--seconds 90] [--seed 7] [--key C] [--out work/music_NN.wav]
        built-in composer, offline, no key. Moods: happy, quirky, wholesome, mystery, spooky, epic, chill, sad.
        Structure: intro -> A -> B -> A' -> outro, chords + bass + pluck arp + melody + drums, mixed and mastered.
  music.py elevenlabs "<prompt>" [--seconds 90] [--out ...]     ElevenLabs Music API (paid key, instrumental prompt)
  music.py musicgen "<prompt>" [--seconds 30] [--out ...]       local MusicGen (pip install transformers torch; slow on CPU)
  music.py assign NN <file>                                     use a file as video NN's track (work/music_NN.<ext>)

post2.py picks work/music_NN.* first, then project.json audio.music, then the first file in <project>/music/.
Match mood to the story's act: quirky/happy for silly bans, mystery/spooky for "horror-lite", wholesome for the payoff."""
import os, sys, json, shutil, subprocess, wave, urllib.request
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rss

SR = 44100
NOTE = {"C": 0, "C#": 1, "D": 2, "D#": 3, "E": 4, "F": 5, "F#": 6, "G": 7, "G#": 8, "A": 9, "A#": 10, "B": 11}
MAJOR, MINOR = [0, 2, 4, 5, 7, 9, 11], [0, 2, 3, 5, 7, 8, 10]
# progressions as scale degrees (0-based); chords are stacked thirds in the scale
MOODS = {
    "happy":     dict(scale=MAJOR, bpm=118, prog=[0, 4, 5, 3], drums="pop", lead="pluck", swing=0.0, sev=False),
    "quirky":    dict(scale=MAJOR, bpm=128, prog=[0, 5, 1, 4], drums="bounce", lead="pizz", swing=0.18, sev=False),
    "wholesome": dict(scale=MAJOR, bpm=100, prog=[0, 3, 5, 4], drums="soft", lead="bell", swing=0.0, sev=True),
    "mystery":   dict(scale=MINOR, bpm=96, prog=[0, 5, 2, 6], drums="tick", lead="pluck", swing=0.0, sev=False),
    "spooky":    dict(scale=MINOR, bpm=84, prog=[0, 3, 0, 4], drums="none", lead="bell", swing=0.0, sev=False),
    "epic":      dict(scale=MINOR, bpm=112, prog=[0, 5, 2, 6], drums="big", lead="pluck", swing=0.0, sev=False),
    "chill":     dict(scale=MAJOR, bpm=90, prog=[0, 5, 1, 4], drums="soft", lead="pluck", swing=0.12, sev=True),
    "sad":       dict(scale=MINOR, bpm=76, prog=[0, 5, 3, 4], drums="none", lead="bell", swing=0.0, sev=True),
}


def hz(midi): return 440.0 * 2 ** ((midi - 69) / 12)


def env(n, a, d_rate):
    t = np.arange(n) / SR
    e = np.exp(-t * d_rate)
    na = max(1, int(a * SR)); e[:na] *= np.linspace(0, 1, na)
    return e


def pluck(f, dur, bright=1.0):
    n = int(dur * SR); t = np.arange(n) / SR; x = np.zeros(n)
    for k in range(1, 9):
        if f * k > 9000: break
        x += np.sin(2 * np.pi * f * k * t) * np.exp(-t * (3 + 2.2 * k / bright)) / k
    na = int(0.004 * SR); x[:na] *= np.linspace(0, 1, na)
    return x


def pizz(f, dur): return pluck(f, dur, 0.6) * env(int(dur * SR), 0.002, 9)


def bell(f, dur):
    n = int(dur * SR); t = np.arange(n) / SR
    x = sum(a * np.sin(2 * np.pi * f * r * t) * np.exp(-t * dr) for r, a, dr in ((1, 1, 2.2), (2.76, 0.45, 4), (5.4, 0.25, 7), (8.9, 0.1, 11)))
    na = int(0.002 * SR); x[:na] *= np.linspace(0, 1, na)
    return x


def pad(freqs, dur):
    n = int(dur * SR); t = np.arange(n) / SR; x = np.zeros(n)
    for f in freqs:
        for det in (-0.12, 0.12):
            ff = f * 2 ** (det / 12)
            for k in range(1, 6):
                x += np.sin(2 * np.pi * ff * k * t + k) / (k * 1.6)
    a, r = min(0.35, dur / 3), min(0.4, dur / 3)
    e = np.ones(n); na, nr = int(a * SR), int(r * SR)
    e[:na] = np.linspace(0, 1, na); e[-nr:] *= np.linspace(1, 0, nr)
    # one-pole lowpass for warmth
    y = np.empty_like(x); acc = 0.0; k = 0.08
    for i in range(0, n, 64):
        seg = x[i:i + 64]
        for j in range(len(seg)):
            acc += k * (seg[j] - acc); y[i + j] = acc
    return y * e / max(1, len(freqs))


def bass(f, dur):
    n = int(dur * SR); t = np.arange(n) / SR
    x = np.sin(2 * np.pi * f * t) + 0.35 * np.sin(2 * np.pi * 2 * f * t) + 0.12 * np.sin(2 * np.pi * 3 * f * t)
    return x * env(n, 0.005, 3.5)


def kick():
    n = int(0.32 * SR); t = np.arange(n) / SR
    f = 45 + 80 * np.exp(-t * 30)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 9)


def snare(rng):
    n = int(0.2 * SR); t = np.arange(n) / SR
    noise = rng.standard_normal(n); noise = np.diff(noise, prepend=0)
    return (0.6 * noise * np.exp(-t * 22) + 0.5 * np.sin(2 * np.pi * 185 * t) * np.exp(-t * 30)) * 0.6


def hat(rng):
    n = int(0.05 * SR); t = np.arange(n) / SR
    x = np.diff(np.diff(rng.standard_normal(n), prepend=0), prepend=0)
    return x * np.exp(-t * 70) * 0.12


def tick(rng):
    n = int(0.03 * SR); t = np.arange(n) / SR
    return np.sin(2 * np.pi * 2400 * t) * np.exp(-t * 160) * 0.25


def add(buf, x, at, gain=1.0, pan=0.0):
    i = int(at * SR)
    if i >= buf.shape[0]: return
    x = x[: buf.shape[0] - i] * gain
    buf[i:i + len(x), 0] += x * (1 - max(0, pan)); buf[i:i + len(x), 1] += x * (1 + min(0, pan))


def chord_notes(root_midi, scale, deg, seventh=False):
    idx = [deg, deg + 2, deg + 4] + ([deg + 6] if seventh else [])
    return [root_midi + scale[i % 7] + 12 * (i // 7) for i in idx]


def compose(mood="happy", seconds=90, bpm=None, seed=7, key="C"):
    m = MOODS[mood]; rng = np.random.default_rng(seed)
    bpm = bpm or m["bpm"]; beat = 60 / bpm; bar = 4 * beat
    root = 48 + NOTE[key]  # C3
    scale, prog = m["scale"], m["prog"]
    n_bars = max(8, int(np.ceil(seconds / bar)) + 1)
    buf = np.zeros((int((n_bars * bar + 3) * SR), 2))
    # a 2-bar motif in scale steps, re-used with variation (catchy beats random)
    motif = rng.choice([0, 2, 4, 2, 4, 5, 4, 2, 0, -1, 0, 2, 4, 4, 2, 0], size=8, replace=True)
    rhythm = rng.choice([[1, 0, 1, 1, 0, 1, 1, 0], [1, 1, 0, 1, 1, 0, 1, 0], [1, 0, 1, 0, 1, 1, 1, 0]])
    lead_fn = {"pluck": lambda f, d: pluck(f, d) * 0.5, "pizz": lambda f, d: pizz(f, d) * 0.6, "bell": lambda f, d: bell(f, d) * 0.35}[m["lead"]]
    for b in range(n_bars):
        t0 = b * bar
        section = "intro" if b < 2 else ("outro" if b >= n_bars - 2 else ("B" if ((b - 2) // 8) % 2 == 1 else "A"))
        deg = prog[b % len(prog)]
        ch = chord_notes(root, scale, deg, m["sev"])
        # pad (whole bar)
        add(buf, pad([hz(n + 12) for n in ch], bar + 0.2), t0, 0.16 if section != "outro" else 0.12, 0.0)
        # arp 8ths
        if section != "outro" or b == n_bars - 2:
            for s in range(8):
                note = ch[[0, 1, 2, 1, 0, 2, 1, 2][s] % len(ch)] + 24
                sw = (m["swing"] * beat / 2) if s % 2 else 0
                add(buf, pluck(hz(note), beat * 0.9, 1.4) * 0.22, t0 + s * beat / 2 + sw, 1.0, -0.35 if s % 2 else 0.35)
        if section in ("A", "B"):
            # bass on 1 and 3 (+ pickup)
            for s, off in ((0, 0), (2, 0), (3.5, 7)):
                add(buf, bass(hz(ch[0] - 12 + (off if off else 0)), beat * 1.6) * 0.42, t0 + s * beat)
            # melody (lead): motif over the chord, B section an octave up with inverted steps
            for s in range(8):
                if not rhythm[s]: continue
                step = motif[(s + (b % 2) * 3) % 8] * (-1 if section == "B" and s % 3 == 0 else 1)
                sd = deg + step
                note = root + 24 + scale[sd % 7] + 12 * (sd // 7) + (12 if section == "B" else 0)
                sw = (m["swing"] * beat / 2) if s % 2 else 0
                add(buf, lead_fn(hz(note), beat * 0.95), t0 + s * beat / 2 + sw, 0.9, 0.1)
            # drums
            dk = m["drums"]
            for s in range(8):
                tt = t0 + s * beat / 2 + ((m["swing"] * beat / 2) if s % 2 else 0)
                if dk in ("pop", "big", "bounce") and s in ((0, 4) if dk != "bounce" else (0, 3, 4)): add(buf, kick(), tt, 0.8 if dk != "big" else 1.0)
                if dk in ("pop", "big", "bounce") and s in (2, 6): add(buf, snare(rng), tt, 0.55 if dk != "big" else 0.75)
                if dk in ("pop", "bounce", "soft") and s % 2 == 1: add(buf, hat(rng), tt, 0.9, 0.4)
                if dk == "soft" and s in (0, 4): add(buf, kick(), tt, 0.45)
                if dk == "tick" and s % 2 == 0: add(buf, tick(rng), tt, 0.8, -0.3)
    # trim, fade, master: gentle saturation + normalise to -1 dBFS
    n = int(min(seconds, n_bars * bar) * SR)
    buf = buf[:n]
    fo = int(2.5 * SR); buf[-fo:] *= np.linspace(1, 0, fo)[:, None]
    fi = int(0.05 * SR); buf[:fi] *= np.linspace(0, 1, fi)[:, None]
    buf = np.tanh(buf * 1.4)
    buf /= np.max(np.abs(buf)) / 0.89
    return buf


def write_wav(buf, path):
    x = (np.clip(buf, -1, 1) * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(x.tobytes())
    return path


def opt(a, k, d=None):
    return a[a.index(k) + 1] if k in a else d


def default_out(a):
    o = opt(a, "--out")
    if o: return o
    d = (rss.R / "music") if rss.R else rss.Path(".")
    d.mkdir(exist_ok=True)
    return str(d / f"{a[0]}_{opt(a, '--mood', 'track')}_{opt(a, '--seed', '7')}.wav")


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit()
    if a[0] == "compose":
        out = default_out(a)
        buf = compose(opt(a, "--mood", "happy"), float(opt(a, "--seconds", 90)), int(opt(a, "--bpm")) if opt(a, "--bpm") else None,
                      int(opt(a, "--seed", 7)), opt(a, "--key", "C"))
        write_wav(buf, out); print("wrote", out, round(len(buf) / SR, 1), "s")
    elif a[0] == "elevenlabs":
        k = rss.secret("elevenlabs") or sys.exit("no ElevenLabs key")
        out = opt(a, "--out") or default_out(["elevenlabs"]).replace(".wav", ".mp3")
        body = json.dumps({"prompt": a[1] + ", instrumental, no vocals", "music_length_ms": int(float(opt(a, "--seconds", 90)) * 1000)}).encode()
        req = urllib.request.Request("https://api.elevenlabs.io/v1/music", data=body, headers={"xi-api-key": k, "Content-Type": "application/json"}, method="POST")
        open(out, "wb").write(urllib.request.urlopen(req, timeout=600).read()); print("wrote", out)
    elif a[0] == "musicgen":
        from transformers import AutoProcessor, MusicgenForConditionalGeneration
        proc = AutoProcessor.from_pretrained("facebook/musicgen-small"); model = MusicgenForConditionalGeneration.from_pretrained("facebook/musicgen-small")
        secs = float(opt(a, "--seconds", 30)); inp = proc(text=[a[1]], padding=True, return_tensors="pt")
        audio = model.generate(**inp, max_new_tokens=int(secs * 50))[0, 0].numpy()
        sr = model.config.audio_encoder.sampling_rate
        out = opt(a, "--out") or default_out(["musicgen"])
        import scipy.io.wavfile as wf; wf.write(out, sr, audio); print("wrote", out)
    elif a[0] == "assign":
        R = rss.need_project(); src = a[2]; ext = os.path.splitext(src)[1]
        for old in (R / "work").glob(f"music_{a[1]}.*"): old.unlink()
        shutil.copy(src, R / "work" / f"music_{a[1]}{ext}"); print("video", a[1], "->", src)
