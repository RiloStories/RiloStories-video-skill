"""small.py <in.mp4> [out.mp4] [--mb 46] : re-encode for browser uploaders that cap files at 50 MB
(long-form compilations: libx265 two-pass-quality VBR at the bitrate that fits). Shorts use make_upload.py instead."""
import os, sys, subprocess

a = sys.argv[1:]
src = a[0]
dst = a[1] if len(a) > 1 and not a[1].startswith("--") else os.path.splitext(src)[0] + "_small.mp4"
mb = float(a[a.index("--mb") + 1]) if "--mb" in a else 46
dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", src], capture_output=True, text=True).stdout)
vb = int(mb * 8 * 1024 * 1024 / dur - 160000)
subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", src, "-c:v", "libx265", "-preset", "medium", "-b:v", str(vb), "-maxrate", str(int(vb * 1.3)), "-bufsize", str(vb * 2),
                "-tag:v", "hvc1", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", dst], check=True)
print(dst, round(os.path.getsize(dst) / 1048576, 1), "MB")
