"""voices.py - find, audition, clone and assign voices.

  voices.py search <provider> "<words>"          list candidate voices (fish | elevenlabs | edge | kokoro | openai)
  voices.py audition <provider> <id,id,...> ["<line>"]   render the same line in every voice -> work/auditions/index.html
                                                  (open it and listen; the user picks, Claude can't hear)
  voices.py clone <provider> "<name>" <sample1> [sample2 ...] --i-own-this-voice
                                                  make a private cloned voice (fish | elevenlabs). Only with the voice
                                                  owner's permission: the flag is required on purpose.
  voices.py set <SPEAKER> <provider> <voice> [--speed 1.1] [--lufs -14] [--style "[excited]"] [--clean]
                                                  save a cast voice into project.json
  voices.py list                                  show the cast voices in project.json

Casting tips (references/04-voice.md): narrator 1.0x, kids 1.12-1.2x and a little quieter (-12 LUFS), grown-ups 1.0-1.15x.
Audition 4-6 voices per role with a line that has a joke, a question and a shout in it."""
import os, sys, json, asyncio, html, urllib.request, urllib.parse, urllib.error
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rss, tts

KOKORO = ["af_heart", "af_bella", "af_nicole", "af_sarah", "af_sky", "am_adam", "am_michael", "am_eric", "am_puck", "bf_emma", "bf_isabella", "bm_george", "bm_lewis", "bm_fable"]
OPENAI = ["alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx", "sage", "shimmer", "verse"]
DEFAULT_LINE = "In this town, nobody is allowed to laugh. So why is the mayor giggling? Hey! Get back here!"


def _get(url, headers):
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())


def search(provider, q):
    rows = []
    if provider == "fish":
        d = _get("https://api.fish.audio/model?" + urllib.parse.urlencode({"title": q, "page_size": 20, "sort_by": "score"}),
                 {"Authorization": "Bearer " + (rss.secret("fish") or "")})
        for m in d.get("items", []):
            rows.append((m["_id"], m.get("title", ""), ",".join(m.get("languages", [])), m.get("like_count", 0), ",".join(m.get("tags", [])[:4])))
    elif provider == "elevenlabs":
        k = rss.secret("elevenlabs")
        if not k: sys.exit("no ElevenLabs key")
        d = _get("https://api.elevenlabs.io/v1/shared-voices?" + urllib.parse.urlencode({"search": q, "page_size": 20}), {"xi-api-key": k})
        for v in d.get("voices", []):
            rows.append((v["voice_id"], v.get("name", ""), v.get("accent", ""), v.get("gender", ""), v.get("use_case", "")))
        mine = _get("https://api.elevenlabs.io/v1/voices", {"xi-api-key": k})
        for v in mine.get("voices", []):
            if q.lower() in (v.get("name", "") + json.dumps(v.get("labels", {}))).lower():
                rows.append((v["voice_id"], v.get("name", "") + " (yours)", "", "", v.get("category", "")))
    elif provider == "edge":
        import edge_tts
        vs = asyncio.run(edge_tts.list_voices())
        for v in vs:
            toks = set((v["ShortName"].replace("-", " ") + " " + v.get("Gender", "") + " " + v.get("Locale", "")).lower().split())
            toks.add(v.get("Locale", "").lower())
            if all(w in toks or (len(w) > 3 and any(w in t for t in toks if t != "female")) for w in q.lower().split()):
                rows.append((v["ShortName"], v.get("Gender", ""), v.get("Locale", ""), "", ""))
    elif provider == "kokoro":
        rows = [(v, "", "", "", "") for v in KOKORO if q.lower() in v or not q]
    elif provider == "openai":
        rows = [(v, "", "", "", "") for v in OPENAI]
    for r in rows:
        print(" | ".join(str(x) for x in r))
    if not rows:
        print("no matches; try broader words (e.g. 'narrator', 'kid', 'old man', 'british', 'energetic')")


def audition(provider, ids, line):
    d = rss.need_project() / "work" / "auditions"; d.mkdir(parents=True, exist_ok=True)
    cards = []
    for v in ids:
        safe = "".join(c if c.isalnum() else "_" for c in v)[:40]
        out = d / f"{provider}_{safe}.wav"
        try:
            tts.speak({"provider": provider, "voice": v, "speed": 1.0}, line, str(out))
            cards.append(f"<div><b>{html.escape(provider)}:{html.escape(v)}</b><br><audio controls src='{out.name}'></audio></div>")
            print("ok", v)
        except Exception as e:
            print("failed", v, e)
    page = d / "index.html"
    page.write_text("<html><body style='font-family:sans-serif'><h2>Voice audition</h2><p>" + html.escape(line) + "</p>" + "".join(cards) + "</body></html>", encoding="utf-8")
    print("open", page)


def clone(provider, name, files):
    import mimetypes, uuid
    boundary = uuid.uuid4().hex
    parts = []
    def field(k, v): parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode())
    def filef(k, p):
        parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"; filename=\"{os.path.basename(p)}\"\r\nContent-Type: {mimetypes.guess_type(p)[0] or 'audio/mpeg'}\r\n\r\n".encode() + open(p, "rb").read() + b"\r\n")
    if provider == "fish":
        field("type", "tts"); field("train_mode", "fast"); field("title", name); field("visibility", "private")
        for f in files: filef("voices", f)
        url, hdr = "https://api.fish.audio/model", {"Authorization": "Bearer " + tts._need("fish")}
    elif provider == "elevenlabs":
        field("name", name)
        for f in files: filef("files", f)
        url, hdr = "https://api.elevenlabs.io/v1/voices/add", {"xi-api-key": tts._need("elevenlabs")}
    else:
        sys.exit("cloning works with fish or elevenlabs (local cloning: see references/04-voice.md)")
    body = b"".join(parts) + f"--{boundary}--\r\n".encode()
    hdr["Content-Type"] = f"multipart/form-data; boundary={boundary}"
    req = urllib.request.Request(url, data=body, headers=hdr, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            d = json.loads(r.read())
    except urllib.error.HTTPError as e:
        sys.exit(f"clone failed: HTTP {e.code} {e.read()[:300]!r}")
    vid = d.get("_id") or d.get("voice_id")
    print("cloned voice id:", vid, "- now: voices.py set <SPEAKER>", provider, vid)


def set_voice(spk, provider, voice, opts):
    R = rss.need_project(); pj = R / "project.json"
    cfgd = json.loads(pj.read_text(encoding="utf-8"))
    v = {"provider": provider, "voice": voice, "speed": float(opts.get("--speed", 1.0)), "lufs": float(opts.get("--lufs", -14))}
    if "--style" in opts: v["style"] = opts["--style"]
    if "--clean" in opts: v["clean"] = True
    cfgd.setdefault("cast_voices", {})[spk] = v
    pj.write_text(json.dumps(cfgd, indent=2, ensure_ascii=False), encoding="utf-8")
    print("set", spk, v)


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit()
    if a[0] == "search": search(a[1], a[2] if len(a) > 2 else "")
    elif a[0] == "audition": audition(a[1], a[2].split(","), a[3] if len(a) > 3 else DEFAULT_LINE)
    elif a[0] == "clone":
        if "--i-own-this-voice" not in a: sys.exit("Cloning needs the voice owner's permission. Re-run with --i-own-this-voice once that is true.")
        files = [x for x in a[3:] if not x.startswith("--")]
        clone(a[1], a[2], files)
    elif a[0] == "set":
        opts = {}; rest = a[4:]; i = 0
        while i < len(rest):
            if rest[i] == "--clean": opts["--clean"] = True; i += 1
            else: opts[rest[i]] = rest[i + 1]; i += 2
        set_voice(a[1], a[2], a[3], opts)
    elif a[0] == "list":
        print(json.dumps(rss.cfg("cast_voices", {}), indent=2))
