"""Captions (ASS), SFX + music + voiceover mix and final export for one story video.
usage: post2.py <num> <frames_dir> <out_mp4>          (video + audio)
       post2.py <num> --audio-only <out_wav_or_m4a>   (just the mix, for level checks)
"""
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import rss
import sys, json, subprocess, os, importlib.util
from pathlib import Path

R = rss.need_project()
WORK = R / "work"
import sfx


def ass_time(t):
    h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"


LAND = rss.LAND
# caption position (portrait): "middle" = centre of the frame (recommended: never covered by the YouTube UI or faces in
# close-ups when shots keep faces in the upper third), "lower" = lower third, "bottom" = just above the Shorts UI.
CAP_MARGIN = {"middle": 860, "safe": 730, "lower": 520, "bottom": 330}.get(rss.cfg("brand.caption_position", "middle"), 860)


def ass_colour(hexrgb):
    h = hexrgb.lstrip("#")
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H00{b}{g}{r}".upper()


def make_ass(num, headline, red_words, path, duration):
    words = json.load(open(WORK / f"words_{num}.json", encoding="utf-8"))
    hdr = """[Script Info]
ScriptType: v4.00+
PlayResX: @W@
PlayResY: @H@
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Word,@FONT@,@WS@,@WC@,@WC@,&H00000000,&H96000000,-1,0,0,0,100,100,0,0,1,@WO@,4,2,70,70,@WM@,1
Style: Head,@FONT@,@HS@,&H00FFFFFF,&H00FFFFFF,&H00000000,&H96000000,-1,0,0,0,100,100,0,0,1,8,3,8,60,60,@HM@,1
Style: HeadRed,@FONT@,@HS@,&H002D2DFF,&H002D2DFF,&H00000000,&H96000000,-1,0,0,0,100,100,0,0,1,8,3,8,60,60,@HM@,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    hdr = (hdr.replace("@W@", "1920" if LAND else "1080").replace("@H@", "1080" if LAND else "1920").replace("@WS@", "96" if LAND else "118")
           .replace("@WO@", "8" if LAND else "9").replace("@WM@", "90" if LAND else str(CAP_MARGIN)).replace("@HS@", "84" if LAND else "92").replace("@HM@", "60" if LAND else "200").replace("@FONT@", rss.font_name()).replace("@WC@", ass_colour(rss.cfg("brand.caption_color", "#FFE533"))))
    ev = []
    parts = []
    for w in headline.split(" "):
        parts.append(("{\\c&H002D2DFF&}" + w + "{\\c&H00FFFFFF&}") if w.strip(".,!?").upper() in red_words else w)
    if len(headline) > 17:
        half = len(parts) // 2
        txt_head = " ".join(parts[:half]) + "\\N" + " ".join(parts[half:]); hs = 84
    else:
        txt_head = " ".join(parts); hs = 92
    ev.append(f"Dialogue: 1,{ass_time(0.1)},{ass_time(3.6)},Head,,0,0,0,,{{\\fs{hs}\\fad(120,300)\\fscx112\\fscy112\\t(0,160,\\fscx100\\fscy100)}}{txt_head}")
    for i, w in enumerate(words):
        s = w["s"]
        nxt = words[i + 1]["s"] if i + 1 < len(words) else duration
        e = min(max(w["e"] + 0.12, s + 0.18), nxt - 0.01 if nxt - 0.01 > s + 0.12 else s + 0.14)
        txt = w["w"].strip()
        size = 118 if len(txt) <= 9 else (100 if len(txt) <= 12 else 84)
        if LAND: size = int(size * 0.82)
        pop = "{\\fscx130\\fscy130\\t(0,110,\\fscx100\\fscy100)\\fs%d}" % size
        ev.append(f"Dialogue: 0,{ass_time(s)},{ass_time(e)},Word,,0,0,0,,{pop}{txt.upper()}")
    Path(path).write_text(hdr + "\n".join(ev) + "\n", encoding="utf-8")


def load_cues(num):
    spec = importlib.util.spec_from_file_location(f"cues_{num}", WORK / f"cues_{num}.py")
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m


def run(cmd, log):
    with open(log, "w") as f:
        r = subprocess.run(cmd, stdout=f, stderr=f)
    if r.returncode != 0:
        raise SystemExit(f"ffmpeg failed, see {log}")


# voiceover chain for the Fish voice: clean, present, normalised (no pitch shift); music +6 dB / sfx +3 dB vs the first 33-37 mix
def audio_filter(dur):
    VOL = os.environ.get("VO_LUFS", "-14")
    return (f"[1:a]atrim=0:{dur},asetpts=PTS-STARTPTS,apad=whole_dur={dur},aresample=48000,highpass=f=85,equalizer=f=250:t=q:w=1:g=-1.5,equalizer=f=3500:t=q:w=1:g=3,equalizer=f=9000:t=h:w=0.7:g=1.5,acompressor=threshold=-21dB:ratio=3:attack=5:release=90:makeup=3,loudnorm=I={VOL}:TP=-1.5:LRA=6,aformat=channel_layouts=stereo,asplit=2[vo][vo2];"
            f"[2:a]atrim=0:{dur},asetpts=PTS-STARTPTS,loudnorm=I=-20:TP=-4:LRA=7,aresample=48000,aformat=channel_layouts=stereo,afade=t=in:d=0.6,afade=t=out:st={dur-1.2:.2f}:d=1.2[mraw];"
            f"[mraw][vo2]sidechaincompress=threshold=0.04:ratio=8:attack=20:release=450,volume=2.9[m];"
            f"[3:a]volume=1.06,aresample=48000,aformat=channel_layouts=stereo[s];"
            f"[vo][m][s]amix=inputs=3:duration=first:normalize=0,alimiter=limit=0.89:level=0[a]")


def main():
    num = sys.argv[1]
    cues = load_cues(num)
    dur = cues.DURATION
    wav = WORK / f"sfx_{num}.wav"
    sfx.render(dur, cues.CUES(), str(wav), cues.AMBIENCE)
    vo = R / "vo" / f"{num}_vo.mp3"
    music = rss.music_for(num)
    if sys.argv[2] == "--audio-only":
        out = Path(sys.argv[3])
        run(["ffmpeg", "-y", "-hide_banner", "-f", "lavfi", "-i", f"anullsrc=r=48000:cl=stereo:d={dur}", "-i", str(vo), "-stream_loop", "-1", "-i", str(music), "-i", str(wav),
             "-filter_complex", audio_filter(dur), "-map", "[a]", "-t", f"{dur}", "-c:a", "aac", "-b:a", "256k", str(out)], WORK / f"mixtest_{num}.log")
        print("audio", out); return
    frames, out = Path(sys.argv[2]), Path(sys.argv[3])
    ass = WORK / f"captions_{num}.ass"
    make_ass(num, cues.HEADLINE, cues.RED, ass, dur)
    silent = WORK / f"silent_{num}.mp4"
    nfr = int(round(dur * 30))
    vf = (f"scale={'1920:1080' if LAND else '1080:1920'}:flags=lanczos:in_range=full:out_range=limited,setsar=1,subtitles={ass.name}:fontsdir=fonts,"
          f"fade=t=out:st={dur-0.25:.2f}:d=0.25,format=yuv420p")
    run(["ffmpeg", "-y", "-hide_banner", "-framerate", "30", "-i", str(frames / "%05d.jpg"), "-vf", vf, "-frames:v", str(nfr),
         "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-maxrate", "7500k", "-bufsize", "15M", "-pix_fmt", "yuv420p", "-color_range", "tv", "-movflags", "+faststart", str(silent)], WORK / f"enc_{num}.log")
    run(["ffmpeg", "-y", "-hide_banner", "-i", str(silent), "-i", str(vo), "-stream_loop", "-1", "-i", str(music), "-i", str(wav),
         "-filter_complex", audio_filter(dur), "-map", "0:v:0", "-map", "[a]", "-t", f"{dur}", "-c:v", "copy", "-c:a", "aac", "-b:a", "256k", "-movflags", "+faststart", str(out)], WORK / f"mix_{num}.log")
    print("done", out)


if __name__ == "__main__":
    os.chdir(WORK)  # subtitles filter resolves the captions file relative to cwd
    main()
