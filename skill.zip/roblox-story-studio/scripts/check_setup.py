"""check_setup.py [--install] : checks everything the pipeline needs, installs what it safely can, and prints the
manual steps for the rest. Run it first on any new machine, and again whenever something fails mysteriously.

--install : pip-installs missing Python packages and (on Windows) installs ffmpeg with winget if missing.
Exit code 0 = ready for Roblox renders; 1 = something required is missing (see MANUAL lines)."""
import os, sys, shutil, subprocess, importlib, platform, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pathlib import Path

REQ = [("numpy", "numpy"), ("PIL", "pillow"), ("faster_whisper", "faster-whisper"), ("edge_tts", "edge-tts")]
OPT = [("kokoro", "kokoro soundfile", "free offline voices"), ("scipy", "scipy", "local MusicGen output"), ("transformers", "transformers torch", "local MusicGen (large download)")]
install = "--install" in sys.argv
ok_all = True
rows = []


def line(status, what, detail=""):
    rows.append(f"[{status:6}] {what}" + (f"  - {detail}" if detail else ""))


# python
v = sys.version_info
line("OK" if v >= (3, 10) else "MANUAL", f"Python {v.major}.{v.minor}", "" if v >= (3, 10) else "install Python 3.10+ from python.org (tick 'Add to PATH')")
ok_all &= v >= (3, 10)
# packages
for mod, pip in REQ:
    try:
        importlib.import_module(mod); line("OK", f"python package {pip}")
    except ImportError:
        if install:
            r = subprocess.run([sys.executable, "-m", "pip", "install", "--user", *pip.split()], capture_output=True, text=True)
            line("FIXED" if r.returncode == 0 else "MANUAL", f"python package {pip}", "" if r.returncode == 0 else f"pip install {pip}")
            ok_all &= r.returncode == 0
        else:
            line("MISSING", f"python package {pip}", "run with --install"); ok_all = False
for mod, pip, why in OPT:
    try:
        importlib.import_module(mod); line("OK", f"optional {pip}", why)
    except ImportError:
        line("opt", f"optional {pip}", f"{why}: pip install {pip}")
# ffmpeg
if shutil.which("ffmpeg") and shutil.which("ffprobe"):
    line("OK", "ffmpeg + ffprobe")
else:
    if install and platform.system() == "Windows" and shutil.which("winget"):
        r = subprocess.run(["winget", "install", "-e", "--id", "Gyan.FFmpeg", "--accept-source-agreements", "--accept-package-agreements"], capture_output=True, text=True)
        line("FIXED" if r.returncode == 0 else "MANUAL", "ffmpeg", "restart the terminal so PATH updates" if r.returncode == 0 else "install ffmpeg (winget install Gyan.FFmpeg) and add it to PATH")
    else:
        line("MANUAL", "ffmpeg", "Windows: winget install Gyan.FFmpeg | macOS: brew install ffmpeg"); ok_all = False
# Roblox Studio + MCP
if platform.system() != "Windows":
    line("MANUAL", "Windows", "the Roblox renderer (window capture) is Windows-only; the 3D cartoon engine (engines/inkbeat) runs anywhere")
    ok_all = False
else:
    base = Path(os.environ.get("LOCALAPPDATA", "")) / "Roblox" / "Versions"
    studio = list(base.glob("version-*/RobloxStudioBeta.exe")) if base.exists() else []
    mcp = list(base.glob("version-*/StudioMCP.exe")) if base.exists() else []
    line("OK" if studio else "MANUAL", "Roblox Studio", "" if studio else "install from create.roblox.com and sign in")
    line("OK" if mcp else "MANUAL", "Studio MCP server (StudioMCP.exe)", "" if mcp else "Studio > Assistant > MCP: enable the built-in MCP server (references/01-setup.md)")
    ok_all &= bool(studio and mcp)
# Claude-side MCP registration (best effort)
claude = shutil.which("claude")
if claude:
    r = subprocess.run([claude, "mcp", "list"], capture_output=True, text=True)
    has = "roblox" in r.stdout.lower()
    line("OK" if has else "MANUAL", "Roblox Studio MCP registered in Claude Code", "" if has else "see references/01-setup.md step 3")
    hasb = "blender" in r.stdout.lower()
    line("OK" if hasb else "opt", "Blender MCP (optional, for the 3D cartoon engine and Blender props)", "" if hasb else "uvx mcp-for-blender install-addon (references/07-sets-and-assets.md)")
# node for the 3D cartoon engine
line("OK" if shutil.which("node") else "opt", "Node.js (only for engines/inkbeat 3D cartoon videos)", "" if shutil.which("node") else "install Node 20+ LTS")
# keys (never printed)
import rss
for name, why in (("fish", "Fish Audio voices + cloning"), ("elevenlabs", "ElevenLabs voices, cloning, music"), ("openai", "OpenAI voices")):
    line("OK" if rss.secret(name) else "opt", f"{name} API key", why if rss.secret(name) else f"{why}; free alternatives: edge, kokoro")
print("\n".join(rows))
print("\nREADY for Roblox renders" if ok_all else "\nNOT READY: fix the MANUAL/MISSING lines above (re-run with --install for the automatic ones)")
sys.exit(0 if ok_all else 1)
