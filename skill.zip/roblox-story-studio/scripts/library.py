"""library.py - keep a browsable record of every model, set and cast avatar you make, so nothing is built twice.

The models themselves live in the Studio place (ReplicatedStorage.RiloAssets / RiloSets / CastAvatars; save the place).
This writes one Markdown note per item + a thumbnail into a library folder. Point it at an Obsidian vault folder and you
get a searchable, linked asset catalogue (tags, source, size, where it was used).

  library.py note <kind> <Name> "<what it is>" [--source kitbash|ai_mesh|creator_store|blender] [--asset-id N] [--tags a,b]
                 [--capture X,Y,Z:LX,LY,LZ]      also saves a Studio screen capture from that camera as the thumbnail
  library.py index                               rebuild INDEX.md (all items, grouped by kind)
  library.py used <Name> <video>                 append "used in" (so you can see what is overused)
Library folder: project.json "library_dir" (e.g. an Obsidian vault subfolder), default <project>/library.
Toggle: project.json "library": {"save": false} turns saving OFF (default ON). When off, note/index/used do nothing and the
scene/prop is not recorded for reuse; set it back to true (or run `new_project.py --no-library-save` / edit project.json) to resume."""
import os, sys, json, base64, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rss
from pathlib import Path


def saving():
    v = rss.cfg("library.save", True)
    return v not in (False, "false", "False", 0, "0", "off", "no")


def libdir():
    d = Path(rss.cfg("library_dir") or (rss.need_project() / "library"))
    for k in ("props", "sets", "cast", "img"):
        (d / k).mkdir(parents=True, exist_ok=True)
    return d


def capture(spec, out_png):
    from bridge import Studio
    cam, look = spec.split(":")
    s = Studio()
    try:
        d = s.call("screen_capture", {"studio_id": s.sid, "capture_id": "lib_" + out_png.stem,
                                      "camera_position": [float(x) for x in cam.split(",")], "look_at_position": [float(x) for x in look.split(",")]}, 120)
    finally:
        s.close()
    for c in d.get("content", []):
        if c.get("type") == "image":
            out_png.write_bytes(base64.b64decode(c["data"]))
            return out_png
    return None


def note(kind, name, what, opts):
    d = libdir(); sub = {"prop": "props", "set": "sets", "cast": "cast"}.get(kind, kind + "s")
    img = None
    if "--capture" in opts:
        img = capture(opts["--capture"], d / "img" / f"{name}.png")
    tags = [t for t in opts.get("--tags", "").split(",") if t]
    md = ["---", f"name: {name}", f"kind: {kind}", f"source: {opts.get('--source', 'kitbash')}", f"tags: [{', '.join(tags)}]",
          f"created: {datetime.date.today()}", f"asset_id: {opts.get('--asset-id', '')}", f"roblox_path: ReplicatedStorage.{ {'prop': 'RiloAssets', 'set': 'RiloSets', 'cast': 'CastAvatars'}.get(kind, '?') }.{name}", "---",
          f"# {name}", "", what, ""]
    if img: md += [f"![[{img.name}]]", ""]
    md += ["## Used in", ""]
    p = d / sub / f"{name}.md"
    if p.exists():                                  # keep the usage history
        old = p.read_text(encoding="utf-8")
        md = md[:-2] + old[old.index("## Used in"):].splitlines() if "## Used in" in old else md
    p.write_text("\n".join(md) + "\n", encoding="utf-8")
    print("noted", p)


def index():
    d = libdir(); out = ["# Asset library", ""]
    for sub in ("sets", "props", "cast"):
        items = sorted((d / sub).glob("*.md"))
        out += [f"## {sub} ({len(items)})", ""] + [f"- [[{p.stem}]]" for p in items] + [""]
    (d / "INDEX.md").write_text("\n".join(out), encoding="utf-8"); print("index", d / "INDEX.md")


def used(name, video):
    d = libdir()
    for sub in ("sets", "props", "cast"):
        p = d / sub / f"{name}.md"
        if p.exists():
            p.write_text(p.read_text(encoding="utf-8").rstrip() + f"\n- video {video}\n", encoding="utf-8"); print("ok"); return
    print("no note for", name)


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit()
    if a[0] in ("note", "index", "used") and not saving():
        print("library saving is OFF (project.json library.save=false): nothing recorded"); sys.exit()
    if a[0] == "note":
        opts = {a[i]: a[i + 1] for i in range(4, len(a) - 1, 2)}
        note(a[1], a[2], a[3], opts)
    elif a[0] == "index": index()
    elif a[0] == "used": used(a[1], a[2])
