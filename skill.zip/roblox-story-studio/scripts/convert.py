import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import rss
import os
from PIL import Image

def convert(path, raw, size):
    im = Image.frombytes("RGB", size, raw)
    if rss.LAND:          # 16:9 pass: no rotation
        im = im.resize((1920, 1080), Image.LANCZOS)
    else:
        im = im.transpose(Image.Transpose.ROTATE_270).resize((1080, 1920), Image.LANCZOS)
    im.save(path, quality=95, subsampling=0)
    return path
