"""finish.py NN "<subscribe line>"  : CTA outro frames -> captions/SFX/music mix -> out/NN_final.mp4 -> upload copy -> phone folder.
Run after run.py auto has filled frames_NN. Reads work/story_NN.json (from gen_story.py)."""
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import rss
import sys, json, subprocess, shutil
from pathlib import Path
R = rss.need_project(); SK = rss.S
num, line = sys.argv[1], sys.argv[2]
info = json.loads((R / "work" / f"story_{num}.json").read_text())
import os
LAND = rss.LAND
fr = R / (f"frames_{num}_16x9" if LAND else f"frames_{num}")
n_render = len([p for p in fr.glob("*.jpg")])
start = int(round(info["cta_start"] * rss.FPS))
base = fr / ("%05d.jpg" % (start - 1))
if not base.exists():
    sys.exit(f"missing base frame {base.name}; have {n_render} frames, need {start}")
print(subprocess.run([sys.executable, str(SK / "cta.py"), str(base), str(fr), line, "4.2", str(start)], capture_output=True, text=True).stdout.strip())
out = R / "out" / (f"{num}_16x9.mp4" if LAND else f"{num}_final.mp4")
r = subprocess.run([sys.executable, str(SK / "post2.py"), num, str(fr), str(out)], cwd=str(R / "work"), env=dict(os.environ, RSS_PROJECT=str(R)), capture_output=True, text=True)
print(r.stdout.strip()[-200:], r.stderr.strip()[-300:])
d = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(out)], capture_output=True, text=True).stdout.strip()
l = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(out), "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
lufs = [x for x in l.splitlines() if x.strip().startswith(("I:", "Peak:"))][-2:]
print("duration", d, [x.strip() for x in lufs])
if not LAND: print(subprocess.run([sys.executable, str(SK / "make_upload.py"), num], capture_output=True, text=True).stdout.strip()[-120:])
