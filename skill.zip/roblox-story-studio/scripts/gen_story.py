"""gen_story.py NN  -> lua/StoryNN.lua, cues_NN.py, work/words_NN.json (CTA words removed), work/story_NN.json
Reads scripts/NN.txt, work/words_NN_full.json (or words_NN.json) and specs/specNN.py:
  BANNER, BANNERCOL, PROPS (list of lua lines), POPS ({key: (text, (r,g,b))}), AMB ([(line_from, line_to, kind, db)]),
  BEATS = [dict(lines=(a, b), frac=(f0, f1)?, light="morning", cam="{...}", acts="{...}", fx="lua body"?, sfx=[(rel, 'name', dur_or_None, db)])]
Every script line must be covered by a beat (the generator checks). The last script line is the subscribe line: the CTA frames from cta.py take over there."""
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import rss
CUE_TEMPLATE = '''import sys
sys.path.insert(0, "@SK@")
import sfx
from sfx import *
import libsfx
L = libsfx.smp

DURATION = @D@
HEADLINE = "@H@"
RED = {@R@}


def CUES():
    c = []
    A = c.append
@B@
    return c


AMBIENCE = @AMB@
'''
import sys, json, re, importlib.util, difflib
from pathlib import Path
R = rss.need_project()
_sys.path.insert(0, str(R / "specs"))
num = sys.argv[1]
lines = [l.strip() for l in (R / "scripts" / f"{num}.txt").read_text(encoding="utf-8").splitlines() if l.strip()]
wf = R / "work" / f"words_{num}_full.json"
if not wf.exists():
    wf = R / "work" / f"words_{num}.json"
words = json.loads(wf.read_text(encoding="utf-8"))
json.dump(words, open(R / "work" / f"words_{num}_full.json", "w", encoding="utf-8"), ensure_ascii=False)
norm = lambda s: re.sub(r"[^a-z0-9]", "", s.lower())
stoks = []; sline = []
for i, l in enumerate(lines):
    for w in l.split():
        n = norm(w)
        if n: stoks.append(n); sline.append(i)
wtoks = [norm(w["w"]) for w in words]
sm = difflib.SequenceMatcher(None, stoks, wtoks, autojunk=False)
mp = {}
for a, b, n in sm.get_matching_blocks():
    for k in range(n): mp[a + k] = b + k
# line start time = word time of the first matched token of the line (interpolate when missing)
starts = []
for i in range(len(lines)):
    idx = [k for k, ln in enumerate(sline) if ln == i]
    t = None
    for k in idx:
        if k in mp: t = words[mp[k]]["s"]; break
    if t is None and starts: t = starts[-1] + 2.0
    starts.append(t if t is not None else 0.0)
for i in range(1, len(starts)):
    if starts[i] <= starts[i - 1]: starts[i] = starts[i - 1] + 0.5
cta_start = starts[-1]
vo_end = words[-1]["e"]
spec_path = R / "specs" / f"spec{num}.py"
sp = importlib.util.spec_from_file_location("spec", spec_path); spec = importlib.util.module_from_spec(sp); sp.loader.exec_module(spec)

def span(a, b):
    t0 = starts[a]; t1 = starts[b + 1] if b + 1 < len(starts) else cta_start
    return t0, t1
covered = set(); beats_lua = []; cues = []
for bt in spec.BEATS:
    a, b = bt["lines"]
    t0, t1 = span(a, b)
    if "t" in bt:
        # clause-level beat: absolute seconds in the voiceover (t0, t1); lines still marks coverage
        t0, t1 = bt["t"]
        covered.update(range(a, b + 1))
    elif "frac" in bt:
        f0, f1 = bt["frac"]; L = t1 - t0; t0, t1 = t0 + f0 * L, t0 + f1 * L
    else:
        covered.update(range(a, b + 1))
    if bt.get("frac") and bt["frac"][0] == 0: covered.update(range(a, b + 1))
    t0 = round(t0, 2); t1 = round(t1, 2)
    fx = bt.get("fx")
    fxs = ""
    if fx: fxs = ",\n\t\tfunction(t, u, E, rel)\n\t\t\t" + fx.replace("\n", "\n\t\t\t") + "\n\t\tend"
    beats_lua.append(f'\tsc({t0}, {t1}, "{bt.get("light", "morning")}", {bt["cam"]},\n\t\t{bt["acts"]}{fxs})')
    for s in bt.get("sfx", []):
        rel, name, dur, db = s
        cues.append((round(t0 + rel, 2), name, dur, db))
missing = [i for i in range(len(lines) - 1) if i not in covered]
if missing:
    print("WARNING lines not covered by any beat:", missing, [lines[i][:40] for i in missing])

props = "\n".join("\t" + p for p in spec.PROPS)
pops = "\n".join(f'\tE.pop["{k}"] = bubble(stage, "{v[0]}", rgb({v[1][0]}, {v[1][1]}, {v[1][2]}))' for k, v in spec.POPS.items())
tplf = R / "lua" / "story_template.lua"
if not tplf.exists(): tplf = rss.ASSETS / "templates" / ("story_template_%s.lua" % rss.cfg("format.template", "town"))
tpl = tplf.read_text(encoding="utf-8")
out = (tpl.replace("@NUM@", num).replace("@DUR@", f"{cta_start + 0.05:.2f}").replace("@BANNERCOL@", spec.BANNERCOL)
       .replace("@BANNER@", spec.BANNER).replace("@SHADOWS@", "{" + ", ".join('"%s"' % x for x in getattr(spec, "SHADOWS", [])) + "}").replace("@PROPS@", props).replace("@POPS@", pops).replace("@BEATS@", "\n".join(beats_lua)))
(R / "lua").mkdir(exist_ok=True)
(R / "lua" / f"Story{num}.lua").write_text(out, encoding="utf-8")

# cues file
tot = round(cta_start + 4.2, 2)
body = []
for t, name, dur, db in cues:
    if name.startswith("syn:"):
        body.append(f"    A(({t}, {name[4:]}, {db}))")
    else:
        d = f", {dur}" if dur else ""
        body.append(f'    A(({t}, L("{name}"{d}), {db}))')
body.append(f"    A(({cta_start + 0.55:.2f}, whoosh(0.4, 500, 3000), -18)); A(({cta_start + 2.0:.2f}, click(0.12), -12))")
body.append(f"    A(({cta_start + 2.1:.2f}, chime(1.6, (1319, 1568, 2093)), -14)); A(({cta_start + 2.15:.2f}, bell(1.6, 1175), -17))")
amb = []
for (la, lb, kind, db) in getattr(spec, "AMB", [(0, len(lines) - 1, "street", -26)]):
    a = starts[la]; b = starts[lb + 1] if lb + 1 < len(starts) else tot
    amb.append((round(a, 2), round(b if lb + 1 < len(starts) else tot, 2), kind, db))
tpl2 = CUE_TEMPLATE.replace("@SK@", str(rss.S).replace("\\", "/"))
headline = getattr(spec, "HEADLINE", spec.BANNER)
red = getattr(spec, "RED", '"BANNED"')
cuefile = (tpl2.replace("@D@", str(tot)).replace("@H@", headline).replace("@R@", red).replace("@B@", "\n".join(body)).replace("@AMB@", repr(amb)))
(R / "work" / f"cues_{num}.py").write_text(cuefile, encoding="utf-8")
# words for captions: remove the CTA line
json.dump([w for w in words if w["s"] < cta_start - 0.1], open(R / "work" / f"words_{num}.json", "w", encoding="utf-8"), ensure_ascii=False)
json.dump({"num": num, "cta_start": cta_start, "total": tot, "frames_to_render": round(cta_start * rss.FPS), "starts": starts, "vo_end": vo_end},
          open(R / "work" / f"story_{num}.json", "w"))
print(f"story {num}: {len(spec.BEATS)} beats, render {cta_start:.2f}s, final {tot}s, lines {len(lines)}, cues {len(cues)}")
