import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import rss
import subprocess, sys, os, json
R = str(rss.need_project())
n = sys.argv[1]
src = os.path.join(R, "out", f"{n}_final.mp4")
dst = os.path.join(R, "upload", f"{n}_upload.mp4")
os.makedirs(os.path.join(R, "upload"), exist_ok=True)
dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", src], capture_output=True, text=True).stdout)
vb = int((46 * 8 * 1024 * 1024 / dur) - 140000)
subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", src, "-c:v", "libx264", "-preset", "veryfast", "-threads", "3", "-b:v", str(vb), "-maxrate", str(int(vb * 1.25)), "-bufsize", str(vb * 2),
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", dst], check=True)
print(n, os.path.getsize(dst) // 1024 // 1024, "MB")
