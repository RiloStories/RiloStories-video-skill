"""Original synthesized SFX + ambience for the story videos (no external samples)."""
import numpy as np, wave

SR = 44100
rng = np.random.default_rng(7)


def t_arr(d):
    return np.arange(int(d * SR)) / SR


def env(n, a=0.005, d=0.2, curve=2.0):
    x = np.arange(n) / SR
    e = np.minimum(1, x / max(a, 1e-4)) * np.exp(-x / max(d, 1e-4) * curve)
    return e


def noise(d):
    return rng.standard_normal(int(d * SR))


def bandpass(x, lo, hi):
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    m = ((f >= lo) & (f <= hi)).astype(float)
    # soften edges
    k = max(3, int(len(f) * 0.002))
    m = np.convolve(m, np.ones(k) / k, mode="same")
    return np.fft.irfft(X * m, len(x))


def lowpass(x, fc):
    return bandpass(x, 0, fc)


def norm(x, peak=0.9):
    m = np.max(np.abs(x)) or 1
    return x / m * peak


def whoosh(d=0.6, lo=300, hi=3500):
    n = noise(d)
    x = bandpass(n, lo, hi)
    t = np.linspace(0, 1, len(x))
    e = np.sin(np.pi * t) ** 2
    return norm(x * e, 0.7)


def thud(d=0.35, f0=95):
    t = t_arr(d)
    x = np.sin(2 * np.pi * (f0 + 60 * np.exp(-t * 25)) * t) * env(len(t), 0.002, 0.09, 1.0)
    x += lowpass(noise(d), 600) * env(len(t), 0.001, 0.04) * 0.5
    return norm(x, 0.95)


def slam(d=0.5):
    t = t_arr(d)
    x = thud(d, 70) * 0.9 + bandpass(noise(d), 800, 5000) * env(len(t), 0.001, 0.05) * 0.5
    return norm(x, 0.95)


def click(d=0.12):
    t = t_arr(d)
    return norm(bandpass(noise(d), 1500, 6000) * env(len(t), 0.0005, 0.012), 0.8)


def clunk(d=0.45):
    t = t_arr(d)
    x = np.sin(2 * np.pi * 140 * t) * env(len(t), 0.001, 0.12) + 0.5 * np.sin(2 * np.pi * 410 * t) * env(len(t), 0.001, 0.06)
    x += bandpass(noise(d), 600, 3000) * env(len(t), 0.0005, 0.03) * 0.6
    return norm(x, 0.9)


def step(d=0.12, pitch=1.0):
    t = t_arr(d)
    x = lowpass(noise(d), 900 * pitch) * env(len(t), 0.001, 0.035, 1.0)
    x += np.sin(2 * np.pi * 70 * pitch * t) * env(len(t), 0.001, 0.05) * 0.6
    return norm(x, 0.7)


def footsteps(d, rate=2.2, jitter=0.07, pitch=1.0):
    out = np.zeros(int(d * SR))
    tt = 0.0
    k = 0
    while tt < d - 0.1:
        s = step(0.12, pitch * (1 + 0.1 * rng.standard_normal() * 0.5)) * (0.8 + 0.2 * (k % 2))
        i = int(tt * SR)
        out[i:i + len(s)] += s[:len(out) - i]
        tt += 1 / rate + rng.standard_normal() * jitter
        k += 1
    return out


def siren(d, hi=860, lo=620, rate=3.2):
    t = t_arr(d)
    f = np.where(np.sin(2 * np.pi * rate * t) > 0, hi, lo).astype(float)
    # smooth switch
    f = np.convolve(f, np.ones(600) / 600, mode="same")
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sign(np.sin(ph)) * 0.35 + np.sin(ph) * 0.5
    return lowpass(x, 3000) * 0.5


def engine(d, f0=55, rev=1.0):
    t = t_arr(d)
    r = np.linspace(1, 1 + rev, len(t))
    ph = 2 * np.pi * np.cumsum(f0 * r) / SR
    x = np.sin(ph) + 0.6 * np.sin(2 * ph) + 0.35 * np.sin(3 * ph) + lowpass(noise(d), 300) * 0.4
    e = np.minimum(1, t / 0.3) * np.minimum(1, (d - t) / 0.4)
    return norm(x * e, 0.8)


def hum(d, f=60, wob=0.0):
    t = t_arr(d)
    x = np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * 2 * f * t) + 0.2 * np.sin(2 * np.pi * 3 * f * t)
    x *= (1 + wob * np.sin(2 * np.pi * 0.7 * t))
    return x * 0.5


def zap(d=0.5):
    t = t_arr(d)
    x = bandpass(noise(d), 2000, 9000) * (0.6 + 0.4 * np.sign(np.sin(2 * np.pi * 90 * t)))
    return norm(x * env(len(t), 0.002, 0.2, 1.0), 0.8)


def sweep(d, f0, f1, wave="sine", pulse=0.0):
    t = t_arr(d)
    f = np.linspace(f0, f1, len(t))
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) if wave == "sine" else np.sign(np.sin(ph)) * 0.4 + np.sin(ph) * 0.6
    if pulse:
        x *= 0.65 + 0.35 * np.sin(2 * np.pi * pulse * t)
    e = np.minimum(1, t / 0.15) * np.minimum(1, (d - t) / 0.25)
    return x * e * 0.7


def suck(d, f0=180, f1=1400):
    return norm(sweep(d, f0, f1, "saw", 8) * 0.6 + bandpass(noise(d), 400, 3000) * np.linspace(0.1, 0.6, int(d * SR)) * 0.5, 0.75)


def chime(d=1.2, notes=(880, 1108.7, 1318.5)):
    t = t_arr(d)
    x = np.zeros(len(t))
    for i, f in enumerate(notes):
        s = int(i * 0.12 * SR)
        tt = t[: len(t) - s]
        x[s:] += np.sin(2 * np.pi * f * tt) * np.exp(-tt * 2.8) * 0.5
    return norm(x, 0.7)


def gasp(d=0.6):
    t = t_arr(d)
    x = bandpass(noise(d), 500, 2600) * np.sin(np.pi * np.linspace(0, 1, len(t))) ** 1.5
    x += bandpass(noise(d), 1100, 1700) * 0.5 * np.sin(np.pi * np.linspace(0, 1, len(t)))
    return norm(x, 0.55)


def splat(d=0.35):
    t = t_arr(d)
    x = lowpass(noise(d), 1400) * env(len(t), 0.002, 0.08) + bandpass(noise(d), 300, 900) * env(len(t), 0.01, 0.12) * 0.7
    return norm(x, 0.8)


def glassring(d=0.9):
    t = t_arr(d)
    x = (np.sin(2 * np.pi * 2900 * t) + 0.6 * np.sin(2 * np.pi * 4310 * t)) * np.exp(-t * 6)
    s = np.pad(slam(0.5), (0, max(0, len(t) - int(0.5 * SR))))[: len(t)]
    return norm(s * 0.7 + x * 0.35, 0.9)


def creak(d=0.9):
    t = t_arr(d)
    f = 180 + 70 * np.sin(2 * np.pi * 3.2 * t) + 40 * np.sin(2 * np.pi * 7.1 * t)
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sign(np.sin(ph)) * 0.3 + bandpass(noise(d), 500, 1800) * 0.3
    e = np.sin(np.pi * t / d)
    return norm(x * e, 0.5)


def ambience(kind, d):
    n = noise(d)
    t = t_arr(d)
    if kind == "street":
        x = lowpass(n, 500) * 0.9 + bandpass(noise(d), 1500, 3500) * 0.05 * (1 + np.sin(2 * np.pi * 0.2 * t))
    elif kind == "room":
        x = lowpass(n, 260) * 0.8 + hum(d, 50) * 0.12
    elif kind == "night":
        x = lowpass(n, 380) * 0.6
        chirps = np.zeros(len(t))
        for k in range(int(d * 5)):
            s = rng.uniform(0, d - 0.3)
            i = int(s * SR)
            c = np.sin(2 * np.pi * 4200 * t_arr(0.07)) * env(int(0.07 * SR), 0.003, 0.02)
            chirps[i:i + len(c)] += c[:len(chirps) - i] * 0.15
        x += chirps
    elif kind == "control":
        x = hum(d, 55, 0.2) * 0.7 + lowpass(n, 700) * 0.35 + bandpass(noise(d), 2500, 6000) * 0.02
    elif kind == "crowd":
        x = bandpass(n, 200, 1800) * (0.5 + 0.3 * np.sin(2 * np.pi * 0.35 * t))
    elif kind == "school":
        x = lowpass(n, 700) * 0.6 + bandpass(noise(d), 800, 3000) * 0.18 * (0.6 + 0.4 * np.sin(2 * np.pi * 0.5 * t))
    else:
        x = lowpass(n, 400) * 0.5
    return norm(x, 0.5)


def render(duration, cues, path, ambience_segments=()):
    """cues: list of (time_s, samples, gain_db). ambience_segments: (t0, t1, kind, gain_db)."""
    out = np.zeros(int(duration * SR) + SR * 3)
    for t0, t1, kind, g in ambience_segments:
        a = ambience(kind, t1 - t0 + 0.8)
        fade = int(0.4 * SR)
        a[:fade] *= np.linspace(0, 1, fade)
        a[-fade:] *= np.linspace(1, 0, fade)
        i = int(t0 * SR)
        out[i:i + len(a)] += a[:len(out) - i] * 10 ** (g / 20)
    for t0, x, g in cues:
        i = int(t0 * SR)
        if i < 0 or i >= len(out):
            continue
        x = np.asarray(x, dtype=float)
        out[i:i + len(x)] += x[:len(out) - i] * 10 ** (g / 20)
    out = out[: int(duration * SR)]
    out = np.tanh(out * 0.9) * 0.9
    pcm = (out * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    return path


def rumble(d, f=38):
    t = t_arr(d)
    x = lowpass(noise(d), 120) * (0.7 + 0.3 * np.sin(2 * np.pi * 7 * t)) + np.sin(2 * np.pi * f * t) * 0.5
    e = np.minimum(1, t / 0.4) * np.minimum(1, (d - t) / 0.6)
    return norm(x * e, 0.85)


def growl(d=1.4, f=70):
    t = t_arr(d)
    f_t = f * (1 + 0.25 * np.sin(2 * np.pi * 2.2 * t))
    ph = 2 * np.pi * np.cumsum(f_t) / SR
    x = np.sign(np.sin(ph)) * 0.4 + np.sin(ph) * 0.5 + lowpass(noise(d), 500) * 0.3
    x *= (0.6 + 0.4 * np.sin(2 * np.pi * 25 * t))
    e = np.minimum(1, t / 0.2) * np.minimum(1, (d - t) / 0.4)
    return norm(lowpass(x, 900) * e, 0.8)


def squeak(d=0.35, f0=1400, f1=2600):
    t = t_arr(d)
    ph = 2 * np.pi * np.cumsum(np.linspace(f0, f1, len(t))) / SR
    return norm(np.sin(ph) * np.sin(np.pi * t / d) ** 0.7, 0.6)


def bell(d=2.2, f=196):
    t = t_arr(d)
    x = (np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * f * 2.76 * t) + 0.3 * np.sin(2 * np.pi * f * 5.4 * t)) * np.exp(-t * 1.6)
    return norm(x, 0.8)


def crackle(d=1.0):
    t = t_arr(d)
    x = bandpass(noise(d), 1500, 8000) * (rng.random(len(t)) > 0.985) * 4
    x = np.convolve(x, np.ones(6) / 6, mode="same")
    return norm(x * np.minimum(1, (d - t) / 0.3), 0.8) if np.max(np.abs(x)) > 0 else x


def fire(d=1.4):
    t = t_arr(d)
    x = bandpass(noise(d), 200, 2500) * (0.5 + 0.5 * np.sin(2 * np.pi * 14 * t) ** 2)
    e = np.minimum(1, t / 0.1) * np.minimum(1, (d - t) / 0.3)
    return norm(x * e, 0.8)


def screech(d=0.9):
    t = t_arr(d)
    x = bandpass(noise(d), 2500, 7000) * (0.6 + 0.4 * np.sin(2 * np.pi * 40 * t))
    x += sweep(d, 2200, 900, "saw") * 0.4
    e = np.minimum(1, t / 0.05) * np.minimum(1, (d - t) / 0.3)
    return norm(x * e, 0.7)


def gurgle(d=1.0):
    t = t_arr(d)
    x = lowpass(noise(d), 180) * (0.5 + 0.5 * np.sin(2 * np.pi * 9 * t + 3 * np.sin(2 * np.pi * 2 * t)) ** 2)
    x += np.sin(2 * np.pi * (60 + 25 * np.sin(2 * np.pi * 3 * t)) * t) * 0.5
    e = np.minimum(1, t / 0.15) * np.minimum(1, (d - t) / 0.3)
    return norm(x * e, 0.8)
