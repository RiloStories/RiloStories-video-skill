"""pacing.py NN : measure a video's pacing from its spec + voiceover timings, BEFORE rendering (instant).

Reports and flags (warnings, not gates; the thresholds come from measured viral Shorts, see references/16-viral-patterns.md
and research/SHORTS_REPORT.md; tune them in project.json "pacing" once you have your own channel's data):
  * speech starts at second 0 (first word within 0.4 s) and the hook line opens with the format's rule
  * words per minute (default band 170-260: viral Shorts talk fast, normal speech is ~150)
  * average shot length and longest shot (default: avg <= 2.2 s, no shot > 4 s)
  * share of shots where the camera moves (push-in/dolly/fov change) (default >= 60%)
  * first shot has the key object/character in frame at t=0 (you confirm in the preview)
  * the ending: twist/payoff exists (last story line is not the subscribe line only) and story length 45-110 s"""
import os, sys, re, json, importlib.util
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rss

R = rss.need_project(); num = sys.argv[1]
sys.path.insert(0, str(R / "specs"))
P = rss.cfg("pacing", {}) or {}
wpm_lo, wpm_hi = P.get("wpm", [170, 260])
avg_max, long_max, move_min = P.get("avg_shot_max", 2.2), P.get("longest_shot_max", 4.0), P.get("moving_share_min", 0.6)

st = json.loads((R / "work" / f"story_{num}.json").read_text())
words = json.loads((R / "work" / f"words_{num}.json").read_text(encoding="utf-8"))
lines = [l.strip() for l in (R / "scripts" / f"{num}.txt").read_text(encoding="utf-8").splitlines() if l.strip()]
sp = importlib.util.spec_from_file_location("s", R / "specs" / f"spec{num}.py"); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
starts, cta = st["starts"], st["cta_start"]

spans, moving = [], 0
for b in m.BEATS:
    a, z = b["lines"]
    t0 = starts[a]; t1 = starts[z + 1] if z + 1 < len(starts) else cta
    if "t" in b: t0, t1 = b["t"]
    elif "frac" in b: f0, f1 = b["frac"]; L = t1 - t0; t0, t1 = t0 + f0 * L, t0 + f1 * L
    spans.append((t0, t1))
    cam = b.get("cam", "")
    mv = False
    d = re.search(r"d\s*=\s*\{\s*([\d.]+)\s*,\s*([\d.]+)\s*\}", cam)
    if d and abs(float(d.group(1)) - float(d.group(2))) > 0.05: mv = True
    f = re.search(r"fov\s*=\s*\{\s*([\d.]+)\s*,\s*([\d.]+)\s*\}", cam)
    if f and abs(float(f.group(1)) - float(f.group(2))) > 0.5: mv = True
    if "p0" in cam and "p1" in cam:
        p0 = re.search(r"p0\s*=\s*(V3\([^)]*\))", cam); p1 = re.search(r"p1\s*=\s*(V3\([^)]*\))", cam)
        if p0 and p1 and p0.group(1) != p1.group(1): mv = True
    if "follow" in cam or "shake" in cam: mv = True
    moving += mv
lens = [t1 - t0 for t0, t1 in spans]
dur = cta
n_words = len([w for w in words])
wpm = n_words / max(words[-1]["e"] - words[0]["s"], 1) * 60 if words else 0
warn = []
if words and words[0]["s"] > 0.4: warn.append(f"first word starts at {words[0]['s']:.2f}s (cut leading silence: viral Shorts talk from second 0)")
hook = lines[0].lower()
pref = (rss.cfg("format.hook_prefix") or "").lower().rstrip(",")
if pref and not hook.startswith(pref): warn.append(f'hook line does not start with "{pref}"')
if not (wpm_lo <= wpm <= wpm_hi): warn.append(f"{wpm:.0f} wpm outside {wpm_lo}-{wpm_hi} (speed up/tighten, or set pacing.wpm for your channel)")
if lens and sum(lens) / len(lens) > avg_max: warn.append(f"average shot {sum(lens) / len(lens):.1f}s > {avg_max}s: split beats on clauses")
if lens and max(lens) > long_max: warn.append(f"longest shot {max(lens):.1f}s > {long_max}s at t={spans[lens.index(max(lens))][0]:.1f}s")
if spans and moving / len(spans) < move_min: warn.append(f"only {moving / len(spans) * 100:.0f}% of shots have camera motion (< {move_min * 100:.0f}%): add pushes (d={{5,3.4}}) or fov drifts")
if len(lines) < 4: warn.append("fewer than 4 script lines: add a consequence and a twist before the subscribe line")
if not 45 <= dur <= 110: warn.append(f"story length {dur:.0f}s outside 45-110s")
print(f"video {num}: {dur:.0f}s story, {len(spans)} shots, {len(spans) / dur * 60:.0f} shots/min, avg shot {sum(lens) / len(lens):.2f}s, longest {max(lens):.1f}s")
print(f"speech {wpm:.0f} wpm, starts at {words[0]['s']:.2f}s, camera moves in {moving / len(spans) * 100:.0f}% of shots")
print("PACING OK" if not warn else "PACING WARNINGS:\n  - " + "\n  - ".join(warn))
