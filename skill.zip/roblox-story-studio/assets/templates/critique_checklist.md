# Self-critique hunt list (run on the preview sheets AND the finished video; write the findings down, then fix them)

Don't ask "is it good?". Look for these, one by one, and list every instance with its time. Fix all, then re-check.

## Geometry and physics
- [ ] camera inside a prop, wall, character or set piece (the audit catches most; confirm in previews)
- [ ] characters or props passing through each other (hands in desks, bodies in walls/chairs)
- [ ] floating props or characters; feet not on the floor; seated characters hovering
- [ ] props at the wrong scale (book bigger than a head, door too small)
- [ ] held items not in the hand; held items facing the wrong way
- [ ] things cut off by the frame edge (a price tag, a sign, half a face, a hand mid-gesture)
- [ ] void or sky visible indoors; set edges visible; missing outside view through windows
## Story and picture
- [ ] each clause has a picture that shows it (compare the QA tile to the words under it)
- [ ] first frame (t=0) already shows the subject of the rule; speech starts at second 0
- [ ] a shot held longer than ~4 s, or two shots in a row with the same framing
- [ ] camera static in a shot that should push in
- [ ] faces: expression matches the line; faces in the upper half; speaker visible when speaking
- [ ] the location matches the words (inside = real interior, not a building seen from outside)
## Look
- [ ] muddy, dark or blown-out frames; flat white highlights; washed-out indoor close-ups
- [ ] every character dressed differently; no default-looking placeholder figures; signature items consistent
- [ ] z-fighting shimmer on floors/walls; texture stretching; mesh glitches
## Text and sound
- [ ] captions: right position and colour, words match the voice, nothing covering faces
- [ ] voice: no clipped words, no extra hallucinated speech, loudness about -14 LUFS, music audible under it
- [ ] SFX land on the right word; no abrupt cuts in music; ending fade
- [ ] title/thumbnail promise matches what the video shows
