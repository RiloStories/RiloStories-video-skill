-- Rilo kit: characters (R6 + face pack), poses, camera shots, lighting, frame-synced rendering.
-- Loaded with loadstring inside Studio (Edit mode); exposes _G.K.
local RS = game:GetService("ReplicatedStorage")
local Lighting = game:GetService("Lighting")
local rad, sin, cos, abs, floor = math.rad, math.sin, math.cos, math.abs, math.floor
local V3, CF = Vector3.new, CFrame.new
local K = {}
local Lib = require(RS:WaitForChild("Rilo"):WaitForChild("Lib"))
K.Lib = Lib
K.EXPO = 0
K.LAND = workspace:GetAttribute("RiloLandscape") == true -- 16:9 render pass (set by run.py before Play)
K.PORTRAIT = K.LAND and 0 or -90 -- camera roll that turns the landscape viewport into a portrait frame

------------------------------------------------------------ maths
function K.clamp(x, a, b) return math.max(a, math.min(b, x)) end
function K.lerp(a, b, t) return a + (b - a) * t end
function K.smooth(t) t = K.clamp(t, 0, 1) return t * t * (3 - 2 * t) end
function K.easeOut(t) t = K.clamp(t, 0, 1) return 1 - (1 - t) ^ 3 end
function K.easeIn(t) t = K.clamp(t, 0, 1) return t ^ 3 end
function K.easeInOut(t) t = K.clamp(t, 0, 1) return t < 0.5 and 4 * t ^ 3 or 1 - (-2 * t + 2) ^ 3 / 2 end
function K.lin(t) return K.clamp(t, 0, 1) end
function K.noise(t, seed) return math.noise(t, seed * 1.37, 0.5) end
function K.yawTo(a, b) return math.deg(math.atan2(-(b.X - a.X), -(b.Z - a.Z))) end
local lerp, smooth, clamp = K.lerp, K.smooth, K.clamp

------------------------------------------------------------ parts
function K.part(parent, name, size, cf, color, mat, shape)
	local p = Instance.new("Part")
	p.Name = name; p.Size = size; p.CFrame = cf; p.Color = color or Color3.fromRGB(200, 200, 200)
	p.Material = mat or Enum.Material.SmoothPlastic
	p.Anchored = true; p.CanCollide = false; p.CanQuery = false; p.CanTouch = false
	p.TopSurface = Enum.SurfaceType.Smooth; p.BottomSurface = Enum.SurfaceType.Smooth
	if shape then p.Shape = shape end
	p.Parent = parent
	return p
end
function K.ball(parent, name, d, cf, color, mat) return K.part(parent, name, V3(d, d, d), cf, color, mat, Enum.PartType.Ball) end
function K.cyl(parent, name, len, dia, cf, color, mat) -- axis along the part's local X by default
	return K.part(parent, name, V3(len, dia, dia), cf, color, mat, Enum.PartType.Cylinder)
end
function K.rgb(r, g, b) return Color3.fromRGB(r, g, b) end
function K.light(parent, color, range, brightness, kind)
	local l = Instance.new(kind or "PointLight")
	l.Color = color; l.Range = range; l.Brightness = brightness; l.Shadows = false; l.Parent = parent
	return l
end
-- text on a part face
function K.label(p, text, color, bg, face, font)
	local sg = Instance.new("SurfaceGui"); sg.Face = face or Enum.NormalId.Front; sg.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	sg.PixelsPerStud = 60; sg.LightInfluence = 0; sg.Parent = p
	local f = Instance.new("Frame"); f.Size = UDim2.fromScale(1, 1); f.BackgroundColor3 = bg or Color3.fromRGB(30, 30, 40); f.BackgroundTransparency = bg and 0 or 1; f.BorderSizePixel = 0; f.Parent = sg
	local t = Instance.new("TextLabel"); t.Size = UDim2.fromScale(0.94, 0.9); t.Position = UDim2.fromScale(0.03, 0.05); t.BackgroundTransparency = 1
	t.Text = text; t.TextColor3 = color or Color3.new(1, 1, 1); t.Font = font or Enum.Font.FredokaOne; t.TextScaled = true; t.Parent = f
	return t
end

------------------------------------------------------------ faces (AltiWyre's face pack, full faces)
K.FACE = {
	neutral = 7802852507, smile = 6375861873, bigsmile = 6443708937, grin = 6443708593, joy = 6443709596, happy = 7802852757,
	calm = 7802851861, relief = 6375861659, sleepy = 6511108957, tired = 6511105730, heavy = 6443709454, droop = 10685556781,
	sleep = 6443717181, sad = 6375865873, tearful = 6443758038, cry = 6443732008, worried = 10685556584, confused = 7802853058,
	scared = 6375862389, scream = 6443708737, shock = 6375862182, gasp = 6553092811, wide = 10151062442, determined = 6557885985,
	angry = 6443708470, suspicious = 6553092869, smirk = 6375864169, wince = 6443709778, dizzy = 6375867177, blank = 7802852346,
}

------------------------------------------------------------ characters
K.P = {
	stand = {RS = {0, 0, 5}, LS = {0, 0, -5}, RH = {0, 0, 2}, LH = {0, 0, -2}, N = {0, 0, 0}},
}
local ZERO = {0, 0, 0}
function K.pose(over, base)
	local p = {}
	for k, v in pairs(base or K.P.stand) do p[k] = v end
	for k, v in pairs(over or {}) do p[k] = v end
	return p
end

local Cc = {}; Cc.__index = Cc
K.R15 = true   -- stories from 49 on use the R15 rig (elbows, knees, waist); set false for the old R6 stories
function K.char(name, cfg, parent)
	K.preloadFaces()
	if K.R15 then return K.char15(name, cfg, parent) end
	return K.char6(name, cfg, parent)
end
function K.char6(name, cfg, parent)
	cfg = cfg or {}
	local m = Lib.make(name, {skin = cfg.skin, shirt = cfg.shirt, sleeves = cfg.sleeves, pants = cfg.pants}, nil)
	local hum = m.Humanoid
	-- accessories come from ReplicatedStorage (the copies in workspace.Wardrobe do not survive into Play mode)
	local function addAcc(srcName, tint)
		local wr = RS:FindFirstChild("WardrobeRS")
		local src = (srcName == "mia") and RS:FindFirstChild("PreviewMiaHair") or (wr and wr:FindFirstChild(srcName))
		if not src then warn("missing accessory " .. tostring(srcName)); return end
		local a = src:Clone()
		if tint then
			for _, p in ipairs(a:GetDescendants()) do
				if p:IsA("BasePart") then p.Color = tint end
				pcall(function() if p:IsA("SpecialMesh") then p.TextureId = "" end end)
				pcall(function() if p:IsA("MeshPart") then p.TextureID = "" end end)
			end
		end
		hum:AddAccessory(a)
	end
	if cfg.hair then addAcc(cfg.hair, cfg.hairColor) end
	if cfg.hat then addAcc(cfg.hat) end
	local skin = cfg.skin or Color3.fromRGB(255, 204, 153)
	m.FH.Color = skin; m.Head.Color = skin
	if cfg.scale then m:ScaleTo(cfg.scale) end
	-- weld every accessory to the head ourselves (AddAccessory's weld does not follow the rig reliably in Play mode)
	for _, acc in ipairs(m:GetChildren()) do
		if acc:IsA("Accessory") or acc:IsA("Hat") then
			local handle = acc:FindFirstChild("Handle")
			if handle then
				for _, w in ipairs(handle:GetChildren()) do if w:IsA("Weld") or w:IsA("WeldConstraint") then w:Destroy() end end
				local w = Instance.new("Weld"); w.Name = "AccessoryWeld"; w.Part0 = m.Head; w.Part1 = handle
				local att = handle:FindFirstChildOfClass("Attachment")
				local hatt = att and m.Head:FindFirstChild(att.Name)
				if att and hatt then w.C0 = hatt.CFrame; w.C1 = att.CFrame
				elseif acc:IsA("Hat") then w.C0 = CF(0, m.Head.Size.Y / 2, 0); w.C1 = acc.AttachmentPoint
				else w.C0 = CF(0, m.Head.Size.Y / 2, 0) end
				w.Parent = handle
			end
		end
	end
	for _, d in ipairs(m:GetDescendants()) do
		if d:IsA("BasePart") then d.Anchored = false; d.CanCollide = false; d.CanQuery = false; d.CanTouch = false; d.CastShadow = true end
		if d:IsA("TouchTransmitter") then d:Destroy() end
	end
	m.HumanoidRootPart.Anchored = true; m.HumanoidRootPart.Transparency = 1
	for _, n in ipairs({"RFootPoint", "LFootPoint"}) do local fp = m:FindFirstChild(n); if fp then fp.Transparency = 1 end end
	hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
	hum:Destroy()
	local c = setmetatable({m = m, hrp = m.HumanoidRootPart, FH = m.FH, scale = cfg.scale or 1, name = name, rest = {}, face = nil}, Cc)
	for _, j in ipairs({"Right Shoulder", "Left Shoulder", "Right Hip", "Left Hip", "Neck"}) do
		local mo = m.Torso[j]
		c.rest[j] = {m = mo, p = mo.C0.Position, rot = mo.C0.Rotation}
	end
	for _, n in ipairs({"Mouth", "RightEye", "LeftEye", "RightBrow", "LeftBrow", "MiscFX"}) do m.FH[n].Texture = "" end
	m.Parent = parent or workspace
	c:setFace("neutral")
	return c
end
-- every face texture is loaded once up front: a face that swaps in mid-shot used to draw as a half-loaded black blob
local facesLoaded = false
function K.preloadFaces()
	if facesLoaded then return end
	facesLoaded = true
	local list = {}
	for _, id in pairs(K.FACE) do local d = Instance.new("Decal"); d.Texture = "rbxassetid://" .. id; list[#list + 1] = d end
	pcall(function() game:GetService("ContentProvider"):PreloadAsync(list) end)
	for _, d in ipairs(list) do d:Destroy() end
end
function Cc:setFace(n)
	if self.faceName == n then return end
	self.faceName = n
	self.FH.Mouth.Texture = "rbxassetid://" .. (K.FACE[n] or K.FACE.neutral)
end
local function J(c, name, v)
	v = v or ZERO
	local r = c.rest[name]
	r.m.C0 = CF(r.p) * CFrame.Angles(rad(v[1]), rad(v[2]), rad(v[3])) * r.rot
end
function Cc:applyPose(p)
	J(self, "Right Shoulder", p.RS); J(self, "Left Shoulder", p.LS)
	J(self, "Right Hip", p.RH); J(self, "Left Hip", p.LH); J(self, "Neck", p.N)
end
-- pos is the ground point under the feet (or the seat point when p.sit)
function Cc:put(pos, yaw, p)
	p = p or K.P.stand
	local s = self.scale
	local h = (p.sit and 1.55 or 3) * s + (p.y or 0)
	self.hrp.CFrame = CF(pos + V3(0, h, 0)) * CFrame.Angles(0, rad(yaw or 0), 0) * CFrame.Angles(rad(p.pitch or 0), 0, rad(p.roll or 0))
	self:applyPose(p)
end
function Cc:hide() self.hrp.CFrame = CF(0, -800, 0); self.hidden = true end

------------------------------------------------------------ R15 characters (Motor6D rig from ReplicatedStorage.R15Template)
-- the existing R6 pose tables still work: they are mapped onto the R15 joints, and the elbows, knees, waist and breathing
-- are added on top.  A pose can also carry clip = {name, time} to play a sampled KeyframeSequence (see K.clip).
local Cc15 = {}; Cc15.__index = Cc15
local J15 = {"Root", "Waist", "Neck", "RightShoulder", "RightElbow", "RightWrist", "LeftShoulder", "LeftElbow", "LeftWrist",
	"RightHip", "RightKnee", "RightAnkle", "LeftHip", "LeftKnee", "LeftAnkle"}
function K.char15(name, cfg, parent)
	cfg = cfg or {}
	-- real avatar (catalog clothes + accessories), pre-built in Edit by cast_build.lua into ReplicatedStorage.CastAvatars
	local av = cfg.avatar and RS:FindFirstChild("CastAvatars") and RS.CastAvatars:FindFirstChild(cfg.avatar)
	if av then return K.charAvatar(name, av, cfg, parent) end
	local m = RS:WaitForChild("R15Template"):Clone(); m.Name = name
	local skin = cfg.skin or Color3.fromRGB(255, 204, 153)
	local shirt = cfg.shirt or Color3.fromRGB(90, 140, 220)
	local pants = cfg.pants or Color3.fromRGB(50, 56, 84)
	local shoes = cfg.shoes or Color3.new(pants.R * 0.45, pants.G * 0.45, pants.B * 0.45)
	local sleeve = (cfg.sleeves == false) and skin or shirt
	local col = {Head = skin, LeftHand = skin, RightHand = skin, UpperTorso = shirt, LowerTorso = pants,
		LeftUpperArm = sleeve, RightUpperArm = sleeve, LeftLowerArm = sleeve, RightLowerArm = sleeve,
		LeftUpperLeg = pants, RightUpperLeg = pants, LeftLowerLeg = pants, RightLowerLeg = pants, LeftFoot = shoes, RightFoot = shoes}
	for n, c in pairs(col) do local p = m[n]; p.Color = c; p.Material = Enum.Material.SmoothPlastic; p.TextureID = "" end
	local bc = m:FindFirstChildOfClass("BodyColors"); if bc then bc:Destroy() end
	local head = m.Head
	local function addAcc(srcName, tint)
		local wr = RS:FindFirstChild("WardrobeRS")
		local src = (srcName == "mia") and RS:FindFirstChild("PreviewMiaHair") or (wr and wr:FindFirstChild(srcName))
		if not src then warn("missing accessory " .. tostring(srcName)); return end
		local a = src:Clone()
		if tint then
			for _, p in ipairs(a:GetDescendants()) do
				if p:IsA("BasePart") then p.Color = tint end
				pcall(function() if p:IsA("SpecialMesh") then p.TextureId = "" end end)
				pcall(function() if p:IsA("MeshPart") then p.TextureID = "" end end)
			end
		end
		local handle = a:FindFirstChild("Handle")
		a.Parent = m
		if handle then
			for _, w in ipairs(handle:GetChildren()) do if w:IsA("Weld") or w:IsA("WeldConstraint") then w:Destroy() end end
			local w = Instance.new("Weld"); w.Name = "AccessoryWeld"; w.Part0 = head; w.Part1 = handle
			local att = handle:FindFirstChildOfClass("Attachment")
			local hatt = att and head:FindFirstChild(att.Name)
			if att and hatt then w.C0 = hatt.CFrame; w.C1 = att.CFrame
			elseif a:IsA("Hat") then w.C0 = CF(0, head.Size.Y / 2, 0); w.C1 = a.AttachmentPoint
			else w.C0 = CF(0, head.Size.Y / 2, 0) end
			w.Parent = handle
		end
	end
	if cfg.hair then addAcc(cfg.hair, cfg.hairColor) end
	if cfg.hat then addAcc(cfg.hat) end
	-- clothing artwork: cfg.decals = {{part = "UpperTorso", face = "Front", id = 123456}, ...}
	for _, dc in ipairs(cfg.decals or {}) do
		local tp = m:FindFirstChild(dc.part)
		if tp then
			local d = Instance.new("Decal"); d.Name = "cloth"
			d.Face = Enum.NormalId[dc.face or "Front"]; d.Texture = "rbxassetid://" .. dc.id; d.Parent = tp
		end
	end
	if cfg.scale then m:ScaleTo(cfg.scale) end
	for _, d in ipairs(m:GetDescendants()) do
		if d:IsA("BasePart") then d.Anchored = false; d.CanCollide = false; d.CanQuery = false; d.CanTouch = false; d.CastShadow = true end
	end
	m.HumanoidRootPart.Anchored = true; m.HumanoidRootPart.Transparency = 1
	local c = setmetatable({m = m, hrp = m.HumanoidRootPart, FH = head, scale = cfg.scale or 1, name = name, j = {}, base = {}}, Cc15)
	for _, n in ipairs(J15) do
		local mo = m:FindFirstChild(n, true)
		if mo and mo:IsA("Motor6D") then c.j[n] = mo end
	end
	c.cfg = cfg
	m.Parent = parent or workspace
	c.face = head:FindFirstChild("face")
	c:setFace("neutral")
	return c
end
function K.charAvatar(name, src, cfg, parent)
	K.preloadFaces()
	local m = src:Clone(); m.Name = name
	for _, d in ipairs(m:GetDescendants()) do
		if d:IsA("LuaSourceContainer") then d:Destroy()
		elseif d:IsA("BasePart") then d.Anchored = false; d.CanCollide = false; d.CanQuery = false; d.CanTouch = false; d.CastShadow = true end
	end
	local hum = m:FindFirstChildOfClass("Humanoid"); if hum then hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None end
	if cfg.scale and cfg.scale ~= 1 then m:ScaleTo(cfg.scale) end
	m.HumanoidRootPart.Anchored = true; m.HumanoidRootPart.Transparency = 1
	-- newer avatars come with AnimationConstraint joints instead of Motor6D: poses only drive Motor6D.Transform, so convert them
	-- (without this the arms stay in a T-pose)
	for _, d in ipairs(m:GetDescendants()) do
		if d:IsA("AnimationConstraint") then
			local ok, p0, p1, c0, c1 = pcall(function() return d.Part0, d.Part1, d.C0, d.C1 end)
			if ok and p0 and p1 then
				local mo = Instance.new("Motor6D"); mo.Name = d.Name; mo.Part0 = p0; mo.Part1 = p1; mo.C0 = c0; mo.C1 = c1
				d:Destroy(); mo.Parent = p1
			end
		end
	end
	local head = m.Head
	local c = setmetatable({m = m, hrp = m.HumanoidRootPart, FH = head, scale = cfg.scale or 1, name = name, j = {}, base = {}}, Cc15)
	for _, n in ipairs(J15) do
		local mo = m:FindFirstChild(n, true)
		if mo and mo:IsA("Motor6D") then c.j[n] = mo end
	end
	c.cfg = cfg
	m.Parent = parent or workspace
	c.face = head:FindFirstChild("face")
	if not c.face then c.face = Instance.new("Decal"); c.face.Name = "face"; c.face.Face = Enum.NormalId.Front; c.face.Parent = head end
	c:setFace(cfg.face or "neutral")
	return c
end
-- Verity (ThatMob horror monster, free R15 rig "Verity rig" by Plumones11c, stored as ReplicatedStorage.VerityTemplate)
function K.charVerity(name, cfg, parent)
	cfg = cfg or {}
	local m = RS:WaitForChild("VerityTemplate"):Clone(); m.Name = name
	for _, d in ipairs(m:GetDescendants()) do
		if d:IsA("LuaSourceContainer") or d:IsA("BallSocketConstraint") or d:IsA("NoCollisionConstraint") then d:Destroy() end
	end
	local hum = m:FindFirstChildOfClass("Humanoid"); if hum then hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None end
	m:ScaleTo(cfg.scale or 0.33)
	for _, d in ipairs(m:GetDescendants()) do
		if d:IsA("BasePart") then d.Anchored = false; d.CanCollide = false; d.CanQuery = false; d.CanTouch = false; d.CastShadow = true end
	end
	local hrp = m.HumanoidRootPart
	hrp.Anchored = true; hrp.Transparency = 1
	local cf, sz = m:GetBoundingBox()
	local hOff = hrp.Position.Y - (cf.Position.Y - sz.Y / 2)
	local c = setmetatable({m = m, hrp = hrp, FH = m.Head, scale = cfg.scale or 0.33, name = name, j = {}, base = {}, hOff = hOff}, Cc15)
	for _, n in ipairs(J15) do
		local mo = m:FindFirstChild(n, true)
		if mo and mo:IsA("Motor6D") then c.j[n] = mo end
	end
	m.Parent = parent or workspace
	return c
end
function Cc15:setFace(n)
	if self.faceName == n then return end
	self.faceName = n
	if self.face then self.face.Texture = "rbxassetid://" .. (K.FACE[n] or K.FACE.neutral) end
end
function Cc15:hide() self.hrp.CFrame = CF(0, -800, 0); self.hidden = true end
local function A3(v, sx, sy, sz) v = v or ZERO; return CFrame.Angles(rad(v[1] * sx), rad(v[2] * sy), rad(v[3] * sz)) end
function Cc15:applyPose(p)
	local j, t = self.j, p.t or 0
	local RS_, LS_, RH, LH, N = p.RS or ZERO, p.LS or ZERO, p.RH or ZERO, p.LH or ZERO, p.N or ZERO
	local breath = sin(t * 2.1)
	local function set(n, cf) if j[n] then j[n].Transform = cf end end
	-- upper body
	set("Waist", CFrame.Angles(rad(breath * 0.8 + (p.lean or 0)), rad(p.twist or 0), 0))
	set("Neck", A3(N, 1, 1, 1))
	set("RightShoulder", A3(RS_, -1, 1, 1)); set("LeftShoulder", A3(LS_, -1, 1, 1))
	local function elbow(v) return rad(clamp(8 + abs(v[1]) * 0.55 + (abs(v[3]) > 100 and 22 or 0) + sin(t * 2.3) * 1.5, 0, 140)) end
	set("RightElbow", CFrame.Angles(elbow(RS_), 0, 0)); set("LeftElbow", CFrame.Angles(elbow(LS_), 0, 0))
	set("RightWrist", CFrame.Angles(0, 0, rad(sin(t * 2.7) * 3))); set("LeftWrist", CFrame.Angles(0, 0, rad(-sin(t * 2.7) * 3)))
	-- legs: knees bend as the thigh swings forward (walking, sitting)
	set("RightHip", A3(RH, 1, 1, 1)); set("LeftHip", A3(LH, 1, 1, 1))
	local function knee(v) return -rad((v[1] > 0 and v[1] * 0.95 or v[1] * 0.1) + 4) end
	set("RightKnee", CFrame.Angles(knee(RH), 0, 0)); set("LeftKnee", CFrame.Angles(knee(LH), 0, 0))
	local function ankle(v) return rad(v[1] > 0 and -v[1] * 0.35 or -v[1] * 0.1) end
	set("RightAnkle", CFrame.Angles(ankle(RH), 0, 0)); set("LeftAnkle", CFrame.Angles(ankle(LH), 0, 0))
end
function Cc15:put(pos, yaw, p)
	p = p or K.P.stand
	local s = self.scale
	local h = self.hOff and (self.hOff + (p.y or 0)) or ((p.sit and 1.2 or 3) * s + (p.y or 0))
	self.hrp.CFrame = CF(pos + V3(0, h, 0)) * CFrame.Angles(0, rad(yaw or 0), 0) * CFrame.Angles(rad(p.pitch or 0), 0, rad(p.roll or 0))
	self:applyPose(p)
end

-- walk cycle pose from a phase (radians); amp in degrees
function K.walk(phase, amp, base)
	amp = amp or 32
	local s = sin(phase)
	local p = K.pose({RH = {s * amp, 0, 2}, LH = {-s * amp, 0, -2}, RS = {-s * amp * 0.75, 0, 5}, LS = {s * amp * 0.75, 0, -5},
		N = {0, 0, 0}, y = abs(s) * 0.12}, base)
	return p
end

-- position track: keys = { {t, x,y,z, yaw?}, ... } -> function(t) returns pos, yaw, phase, moving
local STRIDE = 1.35 -- radians of walk phase per stud
function K.track(keys)
	local cum = {0}
	for i = 2, #keys do
		local a, b = keys[i - 1], keys[i]
		cum[i] = cum[i - 1] + (V3(b[2], b[3], b[4]) - V3(a[2], a[3], a[4])).Magnitude
	end
	return function(t)
		if t <= keys[1][1] then local k = keys[1]; return V3(k[2], k[3], k[4]), k[5] or 0, 0, false end
		for i = 2, #keys do
			local a, b = keys[i - 1], keys[i]
			if t <= b[1] then
				local u = (t - a[1]) / math.max(b[1] - a[1], 1e-4)
				local pa, pb = V3(a[2], a[3], a[4]), V3(b[2], b[3], b[4])
				local pos = pa:Lerp(pb, u)
				local seg = (pb - pa).Magnitude
				local yaw = b[5] or a[5] or 0
				if a[5] and b[5] and a[5] ~= b[5] then yaw = lerp(a[5], b[5], u) end
				local dist = cum[i - 1] + seg * u
				local spd = seg / math.max(b[1] - a[1], 1e-4)
				return pos, yaw, dist * STRIDE, seg > 0.01 and spd > 0.3
			end
		end
		local k = keys[#keys]
		return V3(k[2], k[3], k[4]), k[5] or 0, cum[#cum] * STRIDE, false
	end
end

------------------------------------------------------------ lighting presets
K.LP = {}
local function fx(class, name)
	local e = Lighting:FindFirstChild(name)
	if e and e.ClassName ~= class then e:Destroy(); e = nil end
	if not e then e = Instance.new(class); e.Name = name; e.Parent = Lighting end
	return e
end
function K.initLighting()
	for _, c in ipairs(Lighting:GetChildren()) do
		if c:IsA("PostEffect") or c:IsA("SunRaysEffect") or c:IsA("Atmosphere") then c:Destroy() end
	end
	fx("BloomEffect", "Bloom"); fx("ColorCorrectionEffect", "Grade"); fx("DepthOfFieldEffect", "DOF"); fx("Atmosphere", "Atm")
	fx("ColorCorrectionEffect", "Flash")
	local sr = fx("SunRaysEffect", "Rays"); sr.Intensity = 0
	Lighting.GlobalShadows = true
	pcall(function() Lighting.ShadowSoftness = 0.2 end)
end
function K.applyLight(name, over)
	local P = K.LP[name]
	if not P then return end
	local function g(k) if over and over[k] ~= nil then return over[k] end return P[k] end
	Lighting.ClockTime = g("clock") or 0
	Lighting.Brightness = g("brightness") or 1
	Lighting.Ambient = g("ambient") or Color3.fromRGB(60, 60, 80)
	Lighting.OutdoorAmbient = g("outdoor") or Color3.fromRGB(60, 60, 80)
	Lighting.ColorShift_Top = g("shift") or Color3.new(0, 0, 0)
	Lighting.ExposureCompensation = (g("exposure") or 0) + (K.EXPO or 0)
	Lighting.FogColor = g("fogColor") or Color3.fromRGB(10, 12, 30)
	Lighting.FogStart = g("fogStart") or 80; Lighting.FogEnd = g("fogEnd") or 600
	Lighting.EnvironmentDiffuseScale = g("envDiffuse") or 0.3; Lighting.EnvironmentSpecularScale = g("envSpec") or 0.3
	local a = Lighting.Atm
	a.Density = g("atmDensity") or 0.3; a.Offset = g("atmOffset") or 0.2; a.Color = g("atmColor") or Color3.fromRGB(120, 130, 170)
	a.Decay = g("atmDecay") or Color3.fromRGB(80, 90, 130); a.Glare = g("atmGlare") or 0; a.Haze = g("atmHaze") or 1
	local b = Lighting.Bloom; b.Intensity = g("bloom") or 0.6; b.Size = g("bloomSize") or 28; b.Threshold = (g("bloomThr") or 0.9) + (K.BTHR or 0)
	local c = Lighting.Grade; c.Contrast = g("contrast") or 0.08; c.Saturation = g("sat") or 0.1; c.TintColor = g("tint") or Color3.new(1, 1, 1); c.Brightness = g("gradeBright") or 0
	local sky = Lighting:FindFirstChildOfClass("Sky")
	if sky then sky.StarCount = g("stars") or 3000 end
end

-- blend two lighting presets (numbers and colours interpolate, everything else switches at the half-way point)
function K.mixLight(a, b, u)
	local A, B = K.LP[a], K.LP[b]
	local o = {}
	for k, v in pairs(A) do
		local w = B[k]
		if type(v) == "number" and type(w) == "number" then o[k] = v + (w - v) * u
		elseif typeof(v) == "Color3" and typeof(w) == "Color3" then o[k] = v:Lerp(w, u)
		else o[k] = (u < 0.5) and v or w end
	end
	K.applyLight(a, o)
end

------------------------------------------------------------ camera shots
-- shot = {t0, t1, p0=, p1=, l0=, l1=, fov0=, fov1=, roll0=, roll1=, shake=, ease=, light=, focus=, dofFar=, dofRadius=}
-- p*/l* are Vector3 or function(t) -> Vector3
local function val(v, t) if type(v) == "function" then return v(t) end return v end
function K.runShot(s, t)
	local u = clamp((t - s.t0) / (s.t1 - s.t0), 0, 1)
	local e = (s.ease or K.smooth)(u)
	local cam = workspace.CurrentCamera
	local p0, p1 = val(s.p0, t), val(s.p1 or s.p0, t)
	local l0, l1 = val(s.l0, t), val(s.l1 or s.l0, t)
	local pos = p0:Lerp(p1, e)
	local look = l0:Lerp(l1, e)
	local sh = s.shake or 0
	if sh > 0 then pos += V3(K.noise(t * 2.2, 1), K.noise(t * 2.2, 2), K.noise(t * 2.2, 3)) * sh end
	local roll = lerp(s.roll0 or 0, s.roll1 or s.roll0 or 0, e)
	cam.CameraType = Enum.CameraType.Scriptable
	local fv = lerp(s.fov0 or 50, s.fov1 or s.fov0 or 50, e)
	if K.LAND then fv = math.min(2 * math.deg(math.atan(math.tan(math.rad(fv) / 2) * 16 / 9)), 100) end -- same vertical coverage as the portrait cut
	cam.FieldOfView = fv
	cam.CFrame = CFrame.lookAt(pos, look) * CFrame.Angles(0, 0, rad(K.PORTRAIT + roll))
	K.camState = {cf = cam.CFrame, fov = cam.FieldOfView}
	local dof = Lighting.DOF
	local focus = s.focus and val(s.focus, t) or look
	dof.FocusDistance = math.max((pos - focus).Magnitude, 0.5)
	dof.InFocusRadius = s.dofRadius or math.max(3, (pos - focus).Magnitude * 0.6)
	dof.FarIntensity = s.dofFar or 0.35; dof.NearIntensity = s.dofNear or 0.25
	return pos, look
end
function K.findShot(shots, t)
	for i = #shots, 1, -1 do if t >= shots[i].t0 then return shots[i], i end end
	return shots[1], 1
end

------------------------------------------------------------ glowing motes / beams
function K.beam(parent, name, len, dia, color, transp)
	local p = K.cyl(parent, name, len, dia, CF(), color, Enum.Material.Neon)
	p.Transparency = transp or 0.82; p.CastShadow = false
	return p
end
-- put a cylinder beam so its base is at `from` pointing at `to` (cylinders run along local X)
function K.aimBeam(p, from, to, len)
	local dir = (to - from).Unit
	p.Size = V3(len, p.Size.Y, p.Size.Z)
	p.CFrame = CFrame.lookAt(from + dir * len / 2, from + dir * len) * CFrame.Angles(0, rad(90), 0)
end

------------------------------------------------------------ frame-code strip + render loops
local BITS = 12
function K.makeCode()
	local sg = game.StarterGui:FindFirstChild("FrameCode")
	if sg then sg:Destroy() end
	sg = Instance.new("ScreenGui"); sg.Name = "FrameCode"; sg.IgnoreGuiInset = true; sg.ResetOnSpawn = false
	for i = 0, BITS do
		local f = Instance.new("Frame"); f.Name = "B" .. i; f.BorderSizePixel = 0
		f.Size = UDim2.fromOffset(52, 52)
		f.Position = UDim2.fromOffset(24, 24 + i * 70)
		f.BackgroundColor3 = Color3.new(0, 0, 0); f.Parent = sg
	end
	sg.B12.BackgroundColor3 = Color3.new(1, 0, 0)
	sg.Parent = game.StarterGui
	K.code = sg
end
local function setCode(n)
	for i = 0, BITS - 1 do
		K.code["B" .. i].BackgroundColor3 = (bit32.band(n, bit32.lshift(1, i)) ~= 0) and Color3.new(1, 1, 1) or Color3.new(0, 0, 0)
	end
end
function K.Render(story, fps, hold, first, last)
	K.makeCode(); K.rendering = true
	task.spawn(function()
		local n = floor(story.Duration * fps + 0.5)
		first = first or 0; last = last or n - 1
		for i = first, last do
			if not K.rendering then break end
			story.Apply(i / fps)
			setCode(i + 1)
			task.wait(hold)
		end
		setCode(0); K.rendering = false
	end)
	return "render started"
end
function K.RenderTimes(story, times, hold)
	K.makeCode(); K.rendering = true
	task.spawn(function()
		for i, t in ipairs(times) do story.Apply(t); setCode(i); task.wait(hold) end
		setCode(0); K.rendering = false
	end)
	return "preview started"
end
-- keep the viewport drawing while idle (stills)
function K.Hold(story, t, seconds)
	for i = 1, math.floor(seconds * 60) do story.Apply(t); task.wait() end
end

_G.K = K
return K
