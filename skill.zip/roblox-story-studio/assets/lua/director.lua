-- RiloDirector (LocalScript in StarterPlayerScripts). Source is pushed by run.py on every sync.
-- Client side of the render: loads the kit + story, applies a time, and can free-run a whole frame range
-- while showing a binary frame counter in the left margin of the viewport (outside the portrait crop).
local RS = game:GetService("ReplicatedStorage")
local run = game:GetService("RunService")
local sg = game:GetService("StarterGui")
local Players = game:GetService("Players")
task.spawn(function()
	for i = 1, 80 do
		pcall(function() sg:SetCoreGuiEnabled(Enum.CoreGuiType.All, false); sg:SetCore("TopbarEnabled", false) end)
		task.wait(0.25)
	end
end)
local R = RS:WaitForChild("Rilo")
local St
local Kit
task.defer(function() Kit = require(R:WaitForChild("Kit")) end)
-- the default camera script keeps resetting the camera, so re-apply ours at the very end of every render step
run:BindToRenderStep("RiloCam", Enum.RenderPriority.Last.Value, function()
	local cs = Kit and Kit.camState
	if cs then
		local c = workspace.CurrentCamera
		c.CameraType = Enum.CameraType.Scriptable
		c.CFrame = cs.cf
		c.FieldOfView = cs.fov
	end
end)

workspace:GetAttributeChangedSignal("RiloLoad"):Connect(function()
	local name = workspace:GetAttribute("RiloLoad")
	if not name then return end
	local land = false
	if name:find("|land", 1, true) then land = true; name = name:gsub("|land", "") end -- 16:9 pass: unrotated camera, wider FOV
	local ok, res = pcall(function()
		local K = require(R.Kit)
		if land then K.LAND = true; K.PORTRAIT = 0 end
		St = require(R[name])
		St.setup(K)
		return St.Duration
	end)
	if ok then workspace:SetAttribute("RiloLoaded", tostring(res)) else warn("RiloDirector load error: " .. tostring(res)); workspace:SetAttribute("RiloLoaded", "ERR:" .. tostring(res)) end
end)

-- single frame on request (used for previews / re-rendering missed frames)
workspace:GetAttributeChangedSignal("RiloReq"):Connect(function()
	local req = workspace:GetAttribute("RiloReq")
	if not req then return end
	local id, t = req:match("^(%d+)|(.+)$")
	local ok, res = pcall(function()
		St.Apply(tonumber(t))
		run.RenderStepped:Wait(); run.RenderStepped:Wait()
	end)
	if not ok then warn("RiloDirector frame error: " .. tostring(res)); workspace:SetAttribute("RiloAck", "ERR:" .. tostring(res)) else workspace:SetAttribute("RiloAck", id) end
end)

-- free-running range: "first|last|fps|hold"
local BITS = 12
local strip
local function makeStrip()
	local pg = Players.LocalPlayer:WaitForChild("PlayerGui")
	if strip then strip:Destroy() end
	strip = Instance.new("ScreenGui"); strip.Name = "RiloCode"; strip.IgnoreGuiInset = true; strip.ResetOnSpawn = false; strip.DisplayOrder = 1000
	for i = 0, BITS do
		local f = Instance.new("Frame"); f.Name = "B" .. i; f.BorderSizePixel = 0
		f.Size = UDim2.fromOffset(40, 40); f.Position = UDim2.fromOffset(24, 96 + i * 52)
		f.BackgroundColor3 = Color3.new(0, 0, 0); f.Parent = strip
	end
	strip.B12.BackgroundColor3 = Color3.new(1, 0, 0)
	strip.Parent = pg
end
local function setCode(n)
	for i = 0, BITS - 1 do
		strip["B" .. i].BackgroundColor3 = (bit32.band(n, bit32.lshift(1, i)) ~= 0) and Color3.new(1, 1, 1) or Color3.new(0, 0, 0)
	end
end
workspace:GetAttributeChangedSignal("RiloAuto"):Connect(function()
	local cfg = workspace:GetAttribute("RiloAuto")
	if not cfg then return end
	local first, last, fps, hold = cfg:match("^(%d+)|(%d+)|(%d+)|(%d+)$")
	first, last, fps, hold = tonumber(first), tonumber(last), tonumber(fps), tonumber(hold)
	task.spawn(function()
		local ok, err = pcall(function()
			makeStrip()
			for i = first, last do
				St.Apply(i / fps)
				setCode(i + 1)
				for _ = 1, hold do run.RenderStepped:Wait() end
			end
			setCode(0)
			run.RenderStepped:Wait(); run.RenderStepped:Wait()
		end)
		if not ok then warn("RiloDirector auto error: " .. tostring(err)); workspace:SetAttribute("RiloAutoDone", "ERR:" .. tostring(err)) else workspace:SetAttribute("RiloAutoDone", "ok") end
	end)
end)
workspace:SetAttribute("RiloDirectorReady", true)
