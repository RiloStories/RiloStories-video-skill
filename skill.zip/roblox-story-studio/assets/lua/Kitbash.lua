-- Kitbash: build props out of plain Parts so they match the blocky R15 cast exactly (tested best for style match).
-- Use from a story spec (PROPS lines) or run once via MCP to add a reusable model to ReplicatedStorage.RiloAssets.
--
-- House rules (why: a prop that breaks these is the first thing that looks "off" next to the characters):
--   * Real-Roblox look: SmoothPlastic for toys/plastics, but use the material that matches the thing: Wood, Fabric, Metal, Concrete,
--     Brick, Glass (windows), Neon (glowing cores), Marble, Cobblestone. Pass it as the last argument. Avoid decals except faces/labels.
--   * Palette colours (KB.PAL) - saturated, never grey-brown mush. Max ~4 colours per prop + dark details. Props sit next to real
--     avatars and textured Creator Store sets, so give wood/fabric/metal their real material; flat blocks only for toys.
--   * Chunky: smallest visible part >= 0.12 studs; details read at 1080x1920 only if >= ~0.15 studs at prop scale.
--   * Real scale vs a 5-stud character: mug 0.5, book 0.6x0.8, chair seat 2, door 3.5x7, car 4.4x9, dog 3 tall.
--   * Front faces +Z, base sits on y = 0, pivot at the base centre. KB.finish() enforces this.
--   * Faces on animals/objects = 2 ink blocks for eyes (+ nose/mouth block). Same style as the cast faces.
local KB = {}
local V3, CF, rgb = Vector3.new, CFrame.new, Color3.fromRGB

KB.PAL = {
	red = rgb(225, 55, 55), orange = rgb(240, 140, 50), yellow = rgb(250, 205, 60), lime = rgb(140, 210, 80),
	green = rgb(70, 160, 90), teal = rgb(50, 170, 170), blue = rgb(70, 130, 230), navy = rgb(40, 60, 120),
	purple = rgb(150, 100, 210), pink = rgb(240, 130, 170), brown = rgb(150, 100, 64), tan = rgb(214, 150, 84),
	cream = rgb(246, 222, 190), white = rgb(250, 248, 240), grey = rgb(150, 154, 166), ink = rgb(24, 24, 30),
	wood = rgb(170, 120, 75), metal = rgb(190, 195, 205), gold = rgb(250, 200, 60),
}

function KB.model(name, parent)
	local m = Instance.new("Model"); m.Name = name; m.Parent = parent or workspace
	return m
end

-- part(m, name, size, cframe, colour[, shape][, material])
function KB.part(m, name, size, cf, col, shape, mat)
	local p = Instance.new("Part")
	p.Name = name; p.Size = size; p.CFrame = cf; p.Color = col or KB.PAL.white
	p.Anchored = true; p.CanCollide = false; p.CastShadow = true
	p.Material = mat or Enum.Material.SmoothPlastic
	p.TopSurface = Enum.SurfaceType.Smooth; p.BottomSurface = Enum.SurfaceType.Smooth
	if shape then p.Shape = shape end
	p.Parent = m
	return p
end
function KB.ball(m, n, d, cf, col) return KB.part(m, n, V3(d, d, d), cf, col, Enum.PartType.Ball) end
-- cylinder standing up (axis along Y)
function KB.cyl(m, n, h, d, cf, col) return KB.part(m, n, V3(h, d, d), cf * CFrame.Angles(0, 0, math.rad(90)), col, Enum.PartType.Cylinder) end
-- cylinder facing the camera (axis along Z), e.g. a clock face or a wheel seen side-on
function KB.disc(m, n, thick, d, cf, col) return KB.part(m, n, V3(thick, d, d), cf * CFrame.Angles(0, math.rad(90), 0), col, Enum.PartType.Cylinder) end
function KB.wedge(m, n, size, cf, col)
	local p = Instance.new("WedgePart"); p.Name = n; p.Size = size; p.CFrame = cf; p.Color = col; p.Anchored = true; p.CanCollide = false
	p.Material = Enum.Material.SmoothPlastic; p.Parent = m; return p
end
-- two ink eyes (+ optional nose) on a front face at height y, centred on x, at depth z (front surface)
function KB.face(m, x, y, z, spread, col)
	col = col or KB.PAL.ink
	for _, s in ipairs({-1, 1}) do KB.part(m, "Eye", V3(0.2, 0.28, 0.06), CF(x + s * spread, y, z + 0.03), col) end
end
-- flat sign with text on both sides
function KB.sign(m, n, w, h, cf, text, fg, bg)
	local p = KB.part(m, n, V3(w, h, 0.2), cf, bg or KB.PAL.white)
	for _, face in ipairs({Enum.NormalId.Front, Enum.NormalId.Back}) do
		local sg = Instance.new("SurfaceGui"); sg.Face = face; sg.PixelsPerStud = 60; sg.Parent = p
		local t = Instance.new("TextLabel"); t.Size = UDim2.fromScale(1, 1); t.BackgroundTransparency = 1; t.TextScaled = true
		t.Font = Enum.Font.FredokaOne; t.TextColor3 = fg or KB.PAL.ink; t.Text = text; t.Parent = sg
	end
	return p
end

-- finish: pivot at base centre, front +Z, PrimaryPart set, optional save into ReplicatedStorage.RiloAssets
function KB.finish(m, save)
	local cf, sz = m:GetBoundingBox()
	local base = KB.part(m, "Root", V3(0.1, 0.1, 0.1), CF(cf.Position.X, cf.Position.Y - sz.Y / 2, cf.Position.Z), KB.PAL.white)
	base.Transparency = 1; base.CastShadow = false
	m.PrimaryPart = base
	if save then
		local lib = game:GetService("ReplicatedStorage"):FindFirstChild("RiloAssets")
		if not lib then lib = Instance.new("Folder"); lib.Name = "RiloAssets"; lib.Parent = game:GetService("ReplicatedStorage") end
		local old = lib:FindFirstChild(m.Name); if old then old:Destroy() end
		m:PivotTo(CF(0, 0, 0)); m.Parent = lib
	end
	return m
end

return KB
