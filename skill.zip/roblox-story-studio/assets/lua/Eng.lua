-- Eng: data-driven scene engine for the Rilo stories (lighting presets, poses, auto-framing cameras, actor placement).
local RS = game:GetService("ReplicatedStorage")
local R = RS:WaitForChild("Rilo")
local K = require(R:WaitForChild("Kit"))
local S = require(R:WaitForChild("Sets"))
local V3, CF = Vector3.new, CFrame.new
local rad, sin, cos, abs = math.rad, math.sin, math.cos, math.abs
local rgb, lerp, smooth, clamp = K.rgb, K.lerp, K.smooth, K.clamp
local M = Enum.Material
local Eng = {}

------------------------------------------------------------ lighting
K.LP.night = {clock = 0, brightness = 0.6, ambient = rgb(104, 116, 170), outdoor = rgb(118, 130, 180), stars = 3000, atmDensity = 0.28, atmColor = rgb(52, 70, 134), atmDecay = rgb(24, 32, 74), atmHaze = 1.0,
	fogColor = rgb(14, 18, 46), fogStart = 140, fogEnd = 560, bloom = 0.7, bloomThr = 0.9, contrast = 0.1, sat = 0.1, tint = rgb(228, 236, 255), exposure = 0.3}
K.LP.morning = {clock = 8.0, brightness = 2.6, ambient = rgb(150, 150, 156), outdoor = rgb(170, 172, 176), stars = 0, atmDensity = 0.3, atmColor = rgb(255, 222, 190), atmDecay = rgb(255, 180, 130), atmGlare = 0.3, atmHaze = 1.0,
	fogColor = rgb(255, 224, 196), fogStart = 260, fogEnd = 1100, bloom = 0.4, bloomThr = 0.92, contrast = 0.06, sat = 0.24, tint = rgb(255, 246, 236), exposure = -0.05}
K.LP.noon = {clock = 12.5, brightness = 2.8, ambient = rgb(150, 154, 164), outdoor = rgb(172, 176, 186), stars = 0, atmDensity = 0.25, atmColor = rgb(200, 220, 255), atmDecay = rgb(255, 230, 190), atmGlare = 0.1, atmHaze = 0.8,
	fogColor = rgb(200, 220, 245), fogStart = 300, fogEnd = 1200, bloom = 0.3, bloomThr = 0.95, contrast = 0.06, sat = 0.26, tint = rgb(255, 250, 244), exposure = -0.05}
K.LP.sunset = {clock = 17.9, brightness = 1.8, ambient = rgb(118, 96, 112), outdoor = rgb(150, 112, 116), stars = 0, atmDensity = 0.36, atmColor = rgb(255, 170, 120), atmDecay = rgb(255, 112, 72), atmGlare = 0.5, atmHaze = 1.5,
	fogColor = rgb(255, 150, 110), fogStart = 160, fogEnd = 1000, bloom = 0.55, bloomThr = 0.92, contrast = 0.08, sat = 0.22, tint = rgb(255, 238, 226), exposure = -0.1}
K.LP.golden = {clock = 16.9, brightness = 2.4, ambient = rgb(150, 132, 120), outdoor = rgb(176, 150, 128), stars = 0, atmDensity = 0.34, atmColor = rgb(255, 196, 140), atmDecay = rgb(255, 140, 90), atmGlare = 0.6, atmHaze = 1.3,
	fogColor = rgb(255, 200, 150), fogStart = 220, fogEnd = 1000, bloom = 0.5, bloomThr = 0.9, contrast = 0.06, sat = 0.28, tint = rgb(255, 242, 224), exposure = -0.05}
K.LP.home = {clock = 14, brightness = 0.6, ambient = rgb(150, 142, 134), outdoor = rgb(150, 156, 170), stars = 0, atmDensity = 0, atmHaze = 0, fogColor = rgb(200, 210, 230), fogStart = 400, fogEnd = 3000,
	bloom = 0.3, bloomThr = 0.95, contrast = 0.05, sat = 0.12, tint = rgb(255, 248, 238), exposure = -0.05, envDiffuse = 0.2}
K.LP.homeDusk = {clock = 17.9, brightness = 1.0, ambient = rgb(168, 146, 146), outdoor = rgb(150, 112, 116), stars = 0, atmDensity = 0.3, atmColor = rgb(255, 170, 120), atmDecay = rgb(255, 112, 72), atmHaze = 1.2,
	fogColor = rgb(255, 150, 110), fogStart = 160, fogEnd = 1000, bloom = 0.5, bloomThr = 0.92, contrast = 0.08, sat = 0.2, tint = rgb(255, 236, 222), exposure = -0.1, envDiffuse = 0.15}
K.LP.homeNight = {clock = 0, brightness = 0.25, ambient = rgb(104, 98, 124), outdoor = rgb(70, 76, 110), stars = 0, atmDensity = 0, atmHaze = 0, fogColor = rgb(14, 18, 46), fogStart = 400, fogEnd = 3000,
	bloom = 0.5, bloomThr = 0.9, contrast = 0.08, sat = 0.1, tint = rgb(236, 236, 255), exposure = 0.05, envDiffuse = 0.2}
K.LP.magic = {clock = 0, brightness = 0.5, ambient = rgb(150, 138, 200), outdoor = rgb(120, 112, 180), stars = 0, atmDensity = 0, atmHaze = 0, fogColor = rgb(30, 20, 70), fogStart = 400, fogEnd = 3000,
	bloom = 0.9, bloomThr = 0.85, contrast = 0.1, sat = 0.2, tint = rgb(236, 226, 255), exposure = 0.05, envDiffuse = 0.2}
K.LP.cool = {clock = 14, brightness = 0.5, ambient = rgb(128, 138, 160), outdoor = rgb(140, 150, 170), stars = 0, atmDensity = 0, atmHaze = 0, fogColor = rgb(200, 210, 230), fogStart = 400, fogEnd = 3000,
	bloom = 0.3, bloomThr = 0.95, contrast = 0.06, sat = 0.04, tint = rgb(236, 242, 255), exposure = -0.1, envDiffuse = 0.2}

------------------------------------------------------------ poses
local function pz(o, base) return K.pose(o, base) end
Eng.poses = {
	stand = function(t) return pz({N = {sin(t * 1.3) * 1.5, 0, 0}}) end,
	talk = function(t) return pz({RS = {-28 + sin(t * 4.1) * 18, 0, 14}, LS = {-16 + sin(t * 3.3) * 8, 0, -12}, N = {sin(t * 1.5) * 3, sin(t * 0.9) * 5, 0}}) end,
	hold = function(t) return pz({RS = {-62, 0, 14}, LS = {-62, 0, -14}, N = {-6, 0, 0}}) end,
	point = function(t) return pz({RS = {-90, 0, 6}, LS = {-6, 0, -8}}) end,
	cheer = function(t) return pz({RS = {-8, 0, 150 + sin(t * 9) * 10}, LS = {-8, 0, -150 - sin(t * 9 + 1) * 10}, y = abs(sin(t * 7)) * 0.3}) end,
	wave = function(t) return pz({RS = {0, 0, 140 + sin(t * 8) * 16}}) end,
	sad = function(t) return pz({N = {-24, 0, 0}, RS = {0, 0, 6}, LS = {0, 0, -6}, pitch = 4}) end,
	scared = function(t) return pz({RS = {-100, 0, 18}, LS = {-100, 0, -18}, N = {8, 0, 0}, y = sin(t * 18) * 0.04}) end,
	shrug = function(t) return pz({RS = {0, 0, 32}, LS = {0, 0, -32}, N = {0, 6, 0}}) end,
	cry = function(t) return pz({RS = {-118, 0, -12}, LS = {-118, 0, 12}, N = {-26 + sin(t * 9) * 2, 0, 0}}) end,
	read = function(t) return pz({RS = {-72, 0, 10}, LS = {-72, 0, -10}, N = {-22, 0, 0}}) end,
	sit = function(t) return pz({sit = true, RH = {90, 0, 2}, LH = {90, 0, -2}, RS = {-40, 0, 10}, LS = {-40, 0, -10}, N = {-4, 0, 0}}) end,
	sitread = function(t) return pz({sit = true, RH = {90, 0, 2}, LH = {90, 0, -2}, RS = {-72, 0, 10}, LS = {-72, 0, -10}, N = {-22, 0, 0}}) end,
	sitsad = function(t) return pz({sit = true, RH = {90, 0, 2}, LH = {90, 0, -2}, RS = {-30, 0, 6}, LS = {-30, 0, -6}, N = {-30, 0, 0}}) end,
	sitdesk = function(t) return pz({sit = true, RH = {90, 0, 2}, LH = {90, 0, -2}, RS = {-80, 0, 8}, LS = {-80, 0, -8}, N = {-16, 0, 0}}) end,
	hug = function(t) return pz({RS = {-80, 0, -30}, LS = {-80, 0, 30}}) end,
	hands = function(t) return pz({RS = {-50, 0, 8}, LS = {-50, 0, -8}}) end,
	bow = function(t) return pz({RS = {0, 0, 5}, LS = {0, 0, -5}, pitch = -22}) end,
	kneel = function(t) return pz({sit = true, RH = {90, 0, 2}, LH = {90, 0, -2}, RS = {-50, 0, 8}, LS = {-50, 0, -8}, N = {-14, 0, 0}}) end,
}

------------------------------------------------------------ cameras
local function headOf(c, dy) return c.hrp.Position + V3(0, (dy or 1.1) * c.scale, 0) end
local function fwdOf(c) local l = c.hrp.CFrame.LookVector; return V3(l.X, 0, l.Z).Unit end

local function res(E, w)
	if type(w) == "table" then
		for _, n in ipairs(w) do local c = E.cast[n]; if c.hrp.Position.Y > -500 then return c end end
		return E.cast[w[1]]
	end
	return E.cast[w]
end

local function buildCam(E, s)
	local c = s.cam or {}
	s.fov0 = c.fov and c.fov[1] or c.fov0 or 40
	s.fov1 = c.fov and (c.fov[2] or c.fov[1]) or c.fov1 or s.fov0
	s.shake = c.shake or 0.02; s.ease = c.ease; s.roll0 = c.roll0; s.roll1 = c.roll1
	s.dofFar = c.dofFar or 0.4; s.dofRadius = c.dofR
	if c.p0 then s.p0, s.p1, s.l0, s.l1 = c.p0, c.p1, c.l0, c.l1; return end
	local d0 = c.d and c.d[1] or 6; local d1 = c.d and (c.d[2] or c.d[1]) or d0
	if c.face then d0 = d0 * 1.45; d1 = d1 * 1.45 end
	local h, side = c.h or 0.2, c.side or 0; local ldy = c.look or 0.8
	if c.face then
		local sgn = c.back and -1 or 1
		local function pf(d) return function()
			local who = res(E, c.face)
			local f, hd = fwdOf(who), headOf(who, ldy)
			local r = f:Cross(V3(0, 1, 0))
			return hd + f * d * sgn + r * side + V3(0, h, 0)
		end end
		s.p0, s.p1 = pf(d0), pf(d1)
		s.l0 = function() return headOf(res(E, c.face), ldy) end
		s.dofRadius = s.dofRadius or math.max(2.5, d0 * 0.55)
	elseif c.two then
		local sgn = c.flip and -1 or 1
		local function mid() return (headOf(res(E, c.two[1]), ldy) + headOf(res(E, c.two[2]), ldy)) / 2 end
		local function pf(d) return function()
			local a, b = res(E, c.two[1]), res(E, c.two[2])
			local dir = (b.hrp.Position - a.hrp.Position) * V3(1, 0, 1)
			dir = dir.Magnitude > 0.01 and dir.Unit or V3(1, 0, 0)
			return mid() + dir:Cross(V3(0, 1, 0)) * d * sgn + V3(0, h, 0) + dir * side
		end end
		s.p0, s.p1 = pf(d0), pf(d1)
		s.l0 = mid
		s.dofRadius = s.dofRadius or math.max(3, d0 * 0.6)
	elseif c.follow then
		local o0, o1 = c.off[1], c.off[2] or c.off[1]
		s.p0 = function() return res(E, c.follow).hrp.Position + o0 end
		s.p1 = function() return res(E, c.follow).hrp.Position + o1 end
		s.l0 = function() return headOf(res(E, c.follow), ldy) end
		s.dofRadius = s.dofRadius or 10
	end
end

------------------------------------------------------------ actors
local function posOf(a, t, s)
	if not a.to then return a.p, 0, false end
	local m0 = a.m and a.m[1] or 0
	local m1 = a.m and a.m[2] or (s.t1 - s.t0)
	local k = clamp((t - s.t0 - m0) / math.max(m1 - m0, 0.01), 0, 1)
	if a.ease then k = smooth(k) end
	return a.p:Lerp(a.to, k), k, (k > 0 and k < 1)
end

Eng.openFace = {scream = true, gasp = true, wide = true, shock = true, scared = true, joy = true, cry = true}
Eng.talkFace = {neutral = "happy", smile = "happy", bigsmile = "joy", grin = "joy", joy = "bigsmile", determined = "angry", worried = "wide", sad = "cry", confused = "wide", angry = "scream", tired = "droop", sleepy = "droop", blank = "happy", calm = "happy", suspicious = "confused", smirk = "grin"}
function Eng.apply(E, t)
	local s = K.findShot(E.scenes, t)
	for _, c in pairs(E.cast) do c:hide() end
	K.applyLight(s.light)
	if E.always then E.always(t, s) end
	local rel = t - s.t0
	local at = {}
	for _, a in ipairs(s.act or {}) do local p, k, mv = posOf(a, t, s); at[a.who] = p end
	for _, a in ipairs(s.act or {}) do
		local c = E.cast[a.who]
		local p, k, moving = posOf(a, t, s)
		local yaw = a.yaw
		if a.attach then
			local h = E.cast[a.attach[1]]
			p = (h.hrp.CFrame * a.attach[2]).Position
			local lv = h.hrp.CFrame.LookVector
			yaw = math.deg(math.atan2(-lv.X, -lv.Z)) + (a.dy or 0)
		end
		if a.to and not a.fyaw then yaw = nil end
		if a.look then
			local tp = typeof(a.look) == "Vector3" and a.look or at[a.look]
			if tp then yaw = K.yawTo(p, tp) end
		end
		if a.to and yaw == nil then yaw = K.yawTo(a.p, a.to) end
		local pose = Eng.poses[a.pose or "stand"](rel + (a.seed or 0))
			pose.t = rel + (a.seed or 0)
		if a.po then pose = K.pose(a.po, pose) end
		local ly = E.lift and E.lift(a.who, t) or 0
		if ly > 0 then pose.y = (pose.y or 0) + ly end
		if moving then
			local dist = (a.to - a.p).Magnitude * k
			local w = K.walk(dist * 1.35 * (a.run and 1.0 or 1.0), a.run and 46 or 30, pose)
			if a.keep then w.RS = pose.RS; w.LS = pose.LS end
			if not a.keep then w.RS = a.arms and a.arms[1] or w.RS; w.LS = a.arms and a.arms[2] or w.LS end
			pose = w
		end
		c:put(p, yaw or 0, pose)
		local f = a.face or "neutral"
		if a.face2 and rel >= (a.fs or (s.t1 - s.t0) * 0.5) then f = a.face2 end
		-- talking: the mouth flaps open and closed (open-mouth faces), unless the face is already an open-mouth emotion
		if (a.pose == "talk" or a.talk) and not Eng.openFace[f] then
			local ph = rel * 7.5 + (a.seed or 0) * 3.1
			if math.sin(ph) + 0.6 * math.sin(ph * 2.3 + 1) > -0.2 then f = Eng.talkFace[f] or "happy" end
		end
		c:setFace(f)
	end
	if s.fx then s.fx(t, clamp(rel / (s.t1 - s.t0), 0, 1), E, rel) end
	K.runShot(s, t)
end

-- finish a story's scene list: build cameras
function Eng.finish(E)
	for _, s in ipairs(E.scenes) do buildCam(E, s) end
end
function Eng.scene(E, t0, t1, light, cam, act, fx)
	local s = {t0 = t0, t1 = t1, light = light, cam = cam, act = act, fx = fx}
	table.insert(E.scenes, s)
	return s
end
-- actor-spec helper: A("ben", V3, {yaw=..})
function Eng.A(who, p, o)
	o = o or {}
	o.who = who; o.p = p
	return o
end

------------------------------------------------------------ shared set pieces
function Eng.noshadow(model) for _, d in ipairs(model:GetDescendants()) do if d:IsA("BasePart") then d.CanCollide = false; d.CanQuery = false; d.CanTouch = false end end end

function Eng.init(name)
	K.initLighting()
	for _, d in ipairs(workspace:GetChildren()) do if d:IsA("Folder") and (d.Name:match("^Stage") or d.Name == "SetStreet") then d:Destroy() end end
	local stage = Instance.new("Folder"); stage.Name = "Stage" .. name; stage.Parent = workspace
	for _, n in ipairs({"ALTIWYRE'S FACEPACK [UNGROUP]", "Wardrobe"}) do local o = workspace:FindFirstChild(n); if o then o:Destroy() end end
	return stage
end

-- outdoor town (the standard street)
function Eng.town(stage, groundColor)
	local lib = K.Lib
	local street = lib.street(CF(0, 0, 0)); street.Parent = stage
	local g = street:FindFirstChild("Ground"); if g then g.Size = V3(1600, 1, 900); g.Color = groundColor or rgb(96, 154, 88) end
	local lamps = {}
	for _, d in ipairs(street:GetChildren()) do
		if d:IsA("Model") and d.Name == "Lamp" then
			local bulb = d:FindFirstChild("Bulb")
			if bulb then local pl = bulb:FindFirstChildOfClass("PointLight"); if pl then pl.Brightness = 0.5; pl.Range = 22 end; table.insert(lamps, {p = bulb, l = pl}) end
		end
	end
	-- the north-row plot at x -70..-36 is cleared for a shop built by the story
	for _, d in ipairs(street:GetChildren()) do
		if d:IsA("Model") and d.Name == "House" then
			local pos = d:GetBoundingBox().Position
			if pos.Z < 0 and pos.X > -70 and pos.X < -36 then d:Destroy() end
		end
	end
	-- swap the block houses for the modelled house assets (RiloAssets House_1..13), same footprint and facing
	local okA, assets = pcall(function() return game:GetService("ReplicatedStorage"):FindFirstChild("RiloAssets") end)
	if okA and assets then
		local order = {"House_1", "House_2", "House_4", "House_6", "House_7", "House_8", "House_5", "House_9", "House_10", "House_11", "House_3", "House_13"}
		local n = 0
		for _, d in ipairs(street:GetChildren()) do
			if d:IsA("Model") and d.Name == "House" then
				n = n + 1
				local src = assets:FindFirstChild(order[(n - 1) % #order + 1])
				if src then
					local cf, sz = d:GetBoundingBox()
					local a = src:Clone()
					a:PivotTo(CF())
					local _, asz = a:GetBoundingBox()
					local s = math.min(sz.X / asz.X, sz.Z / asz.Z) * 1.02
					a:ScaleTo(a:GetScale() * s)
					for _, p in ipairs(a:GetDescendants()) do if p:IsA("BasePart") then p.Anchored = true; p.CanCollide = false end end
					a.Parent = street
					a:PivotTo(CF(cf.Position.X, cf.Position.Y - sz.Y / 2, cf.Position.Z) * cf.Rotation)
					d:Destroy()
				end
			end
		end
	end
	Eng.noshadow(street)
	return street, lamps
end
-- cobbled plaza disc at (x, 0, z)
function Eng.plaza(stage, x, z, r)
	K.part(stage, "PlazaDisc", V3(0.5, r * 2, r * 2), CF(x, 0.4, z) * CFrame.Angles(0, 0, rad(90)), rgb(178, 172, 164), M.Cobblestone, Enum.PartType.Cylinder)
end
-- a shop on the cleared north plot, door side faces +Z (x -53, z -33)
function Eng.shop(stage, text, wall, roof, signBg, signFg)
	local bk = Instance.new("Model"); bk.Name = "Shop"; bk.Parent = stage
	K.Lib.house(bk, CF(-53, 0, -42) * CFrame.Angles(0, rad(180), 0), 26, 18, 14, wall, roof)
	S.sign(bk, CF(-53, 11.2, -33.6) * CFrame.Angles(0, rad(180), 0), 12, 3.2, text, signFg or rgb(255, 255, 255), signBg or rgb(50, 70, 140))
	K.part(bk, "ShopWindow", V3(8, 4.6, 0.3), CF(-53 + 6.5, 4.4, -32.9), rgb(200, 226, 250), M.Neon)
	K.part(bk, "ShopWindowFrame", V3(8.8, 5.4, 0.25), CF(-53 + 6.5, 4.4, -32.8), rgb(110, 70, 48), M.Wood)
	Eng.noshadow(bk)
	return bk
end
function Eng.lampsOn(lamps, on)
	for _, l in ipairs(lamps) do l.p.Material = on and M.Neon or M.SmoothPlastic; if l.l then l.l.Enabled = on end end
end

-- a furnished room; returns room table + lamp
function Eng.room(stage, O, W, D, H, style)
	style = style or {}
	local r = S.room(stage, O, W, D, H, {floor = style.floor or rgb(160, 114, 78), wall = style.wall or rgb(236, 226, 204), wains = style.wains, ceil = style.ceil,
		frontHole = style.frontHole, backHole = style.backHole, leftHole = style.leftHole, rightHole = style.rightHole})
	K.part(stage, "Outside", V3(500, 1, 500), CF(O.X, -0.8, O.Z), rgb(96, 154, 88), M.Grass)
	local bulb, light = S.ceilingLamp(stage, O.Position + V3(0, H, 0), 2.2, style.range or 52, style.bright or 1.8)
	r.bulb, r.light = bulb, light
	return r
end
function Eng.winOn(stage, O, W, D, x, y, color)
	local win, glass = S.window(stage, O * CF(x, y, D / 2 - 0.1), 6, 4.6, color or rgb(150, 196, 240))
	glass.Material = M.SmoothPlastic
	return glass
end
function Eng.doorOn(stage, O, D, x, color)
	local m, parts, hinge = S.door(stage, O * CF(x, 0, -D / 2 - 0.1), 4.6, 8.4, color or rgb(120, 78, 52))
	return {leaf = parts[1], knob = parts[2], hinge = hinge, w = 4.6, h = 8.4}
end
function Eng.setDoor(d, ang)
	local leafCF = d.hinge * CFrame.Angles(0, rad(-ang), 0) * CF(d.w / 2, d.h / 2, 0)
	d.leaf.CFrame = leafCF; d.knob.CFrame = leafCF * CF(d.w / 2 - 0.5, 0, -0.35)
end

-- school desk + chair as one model (chair back at +Z, sitter faces -Z toward the desk)
function Eng.deskSet(stage, cf, color)
	local m = Instance.new("Model"); m.Name = "DeskSet"; m.Parent = stage
	S.table(m, cf * CF(0, 0, -1.6), 3.2, 2.2, 2.7, color or rgb(196, 160, 110))
	S.chair(m, cf * CF(0, 0, 0.6), rgb(90, 120, 170))
	m.WorldPivot = cf
	return m
end
-- y of the ground point for a character sitting on a seat of height H
function Eng.seatY(c, H) return (H or 2.1) - 0.55 * c.scale end

function Eng.tree(stage, pos, h)
	h = h or 14
	local okT, assets = pcall(function() return game:GetService("ReplicatedStorage"):FindFirstChild("RiloAssets") end)
	if okT and assets then
		local names = {"Tree_1", "Tree_4", "Tree_2", "Tree_3", "Tree_4"}
		local src = assets:FindFirstChild(names[(math.floor(pos.X + pos.Z) % #names) + 1])
		if src then
			local a = src:Clone()
			a:PivotTo(CF())
			local _, asz = a:GetBoundingBox()
			a:ScaleTo(a:GetScale() * (h * 1.15) / asz.Y)
			for _, p in ipairs(a:GetDescendants()) do if p:IsA("BasePart") then p.Anchored = true; p.CanCollide = false end end
			a.Parent = stage
			a:PivotTo(CF(pos))
			return
		end
	end
	K.cyl(stage, "Trunk", h * 0.6, 2.2, CF(pos + V3(0, h * 0.3, 0)) * CFrame.Angles(0, 0, rad(90)), rgb(110, 78, 50), M.Wood)
	K.ball(stage, "Crown", h * 0.7, CF(pos + V3(0, h * 0.85, 0)), rgb(70, 140, 70), M.Grass)
	K.ball(stage, "Crown2", h * 0.5, CF(pos + V3(h * 0.22, h * 0.7, 0.8)), rgb(84, 156, 80), M.Grass)
end

-- floating orb / sparkle helper
function Eng.orb(parent, d, color)
	local o = K.ball(parent, "Orb", d, CF(0, -800, 0), color, M.Neon); o.Transparency = 0.15; o.CastShadow = false
	K.light(o, color, 8, 0.6)
	return o
end
function Eng.hideAway(p) p.CFrame = CF(0, -800, 0) end

-- sparkle burst: uses E.pops (small orbs); pos = centre, age = seconds since the pop started
function Eng.pop(E, pos, age, size)
	if age < 0 or age > 0.7 then return end
	local k = age / 0.7
	for i, o in ipairs(E.pops) do
		local a = i / #E.pops * 6.283 + i
		o.CFrame = CF(pos + V3(cos(a) * (0.4 + k * 2.2) * (size or 1), (0.3 + k * 1.6 + (i % 3) * 0.3) * (size or 1), sin(a) * (0.4 + k * 2.2) * (size or 1)))
		o.Transparency = 0.15 + k * 0.8
	end
end
function Eng.makePops(E, stage, n)
	E.pops = {}
	for i = 1, n or 10 do local o = K.ball(stage, "Pop", 0.35, CF(0, -800, 0), rgb(255, 232, 120), M.Neon); o.CastShadow = false; E.pops[i] = o end
end
function Eng.clearPops(E) for _, o in ipairs(E.pops) do o.CFrame = CF(0, -800, 0) end end


-- deterministic "physics" (every frame must be a pure function of time, so we never run the physics engine):
-- Eng.fall(p0, v0, t, groundY, bounce) -> position, vertical speed. Gravity 60 studs/s^2 feels right on screen.
-- Bounces lose `bounce` (0..1) of their speed each time and stop when they get small.
function Eng.fall(p0, v0, t, groundY, bounce, g)
	g = g or 60; bounce = bounce or 0.45
	local y, vy, x, z = p0.Y, v0.Y, p0.X + v0.X * t, p0.Z + v0.Z * t
	local tt = t
	for _ = 1, 8 do
		local disc = vy * vy + 2 * g * (y - groundY)
		local tl = (vy + math.sqrt(math.max(disc, 0))) / g       -- time until it reaches the ground from here
		if tt <= tl or bounce <= 0.01 then
			return V3(x, y + vy * tt - 0.5 * g * tt * tt, z), vy - g * tt
		end
		y = groundY; vy = (g * tl - vy) * bounce; tt = tt - tl
		if vy < 2 then return V3(x, groundY, z), 0 end
	end
	return V3(x, groundY, z), 0
end
-- spinning tumble for thrown things: angle at time t (rad/s per axis)
function Eng.tumble(t, ax, ay, az) return CFrame.Angles(ax * t, ay * t, az * t) end
-- squash and stretch for hops/impacts: scale factors (sx, sy) for a prop given how close it is to the ground and its vertical speed
function Eng.squash(vy) local s = clamp(math.abs(vy) / 70, 0, 0.35); return 1 - s * 0.5, 1 + s end

-- library sets (interiors / buildings) from ReplicatedStorage.RiloSets, imported with set_import.lua:
-- floor at y = 0, centred on x/z, the "front" wall (board, stage, counter) towards -Z, scripts stripped.
-- Eng.set(stage, "Classroom_A", CF(2000, 0, 0)) -> model (nil if missing, so stories can fall back to Eng.room)
function Eng.set(stage, name, cf)
	local lib = game:GetService("ReplicatedStorage"):FindFirstChild("RiloSets")
	local src = lib and lib:FindFirstChild(name)
	if not src then warn("missing set " .. tostring(name)); return nil end
	local m = src:Clone()
	for _, d in ipairs(m:GetDescendants()) do
		if d:IsA("LuaSourceContainer") then d:Destroy()
		elseif d:IsA("BasePart") then d.Anchored = true; d.CanCollide = false; d.CanTouch = false end
	end
	-- place by FLOOR: rotate about the set's own centre, then put the centre of its footprint at (cf.X, cf.Z) and its lowest point at cf.Y
	-- (PivotTo alone puts the model's pivot, i.e. its middle, at cf and buries half the set: the first test shot saw sky through the "ceiling")
	local bcf = m:GetBoundingBox()
	m:PivotTo(CF(bcf.Position) * cf.Rotation * CF(bcf.Position):Inverse() * m:GetPivot())
	local ncf, nsz = m:GetBoundingBox()
	m:PivotTo(m:GetPivot() + V3(cf.X - ncf.Position.X, cf.Y - (ncf.Position.Y - nsz.Y / 2), cf.Z - ncf.Position.Z))
	m.Parent = stage
	m:SetAttribute("RiloSet", true)
	-- white-heavy sets burn out under the bright presets: apply the exposure correction measured at import (set_import keep)
	K.EXPO = m:GetAttribute("Expo") or 0
	K.BTHR = m:GetAttribute("BloomThr") or 0
	return m
end
-- a simple outdoor view for interior windows: lawn, pavement, trees and house fronts beyond +/-X walls (or both)
function Eng.windowView(stage, centre, halfWidth, sides)
	local f = Instance.new("Folder"); f.Name = "WindowView"; f.Parent = stage
	for _, side in ipairs(sides or {1, -1}) do
		local x0 = centre.X + side * halfWidth
		K.part(f, "Lawn", V3(200, 1, 300), CF(x0 + side * 100, centre.Y - 0.6, centre.Z), rgb(110, 168, 96), M.Grass)
		K.part(f, "Path", V3(10, 0.3, 296), CF(x0 + side * 12, centre.Y - 0.05, centre.Z), rgb(190, 188, 182), M.Concrete)
		local walls = {rgb(240, 215, 170), rgb(200, 225, 240), rgb(235, 190, 190)}
		for i = -3, 3 do
			local z = centre.Z + i * 16
			Eng.tree(f, V3(x0 + side * 22, centre.Y, z + 4), 12)
			K.part(f, "HouseWall", V3(14, 12, 12), CF(x0 + side * 42, centre.Y + 6, z), walls[(i % 3) + 1], M.Concrete)
			K.part(f, "HouseRoof", V3(15, 1.2, 13), CF(x0 + side * 42, centre.Y + 12.6, z), rgb(150, 70, 60), M.Slate)
		end
	end
	return f
end

return Eng
