-- Shared set builders: rooms, furniture, windows, doors, lamps, props.
local RS = game:GetService("ReplicatedStorage")
local K = require(RS:WaitForChild("Rilo"):WaitForChild("Kit"))
local part, ball, cyl, rgb = K.part, K.ball, K.cyl, K.rgb
local V3, CF = Vector3.new, CFrame.new
local rad = math.rad
local M = Enum.Material
local S = {}

-- wall slab centred at cf; width along local X, height along local Y, thickness along local Z.
-- hole = {cx, cy, w, h} (relative to the wall centre) leaves an opening.
function S.wall(parent, name, cf, w, h, t, color, mat, hole)
	if not hole then return {part(parent, name, V3(w, h, t), cf, color, mat)} end
	local out = {}
	local hx0, hx1 = hole[1] - hole[3] / 2, hole[1] + hole[3] / 2
	local hy0, hy1 = hole[2] - hole[4] / 2, hole[2] + hole[4] / 2
	local x0, x1, y0, y1 = -w / 2, w / 2, -h / 2, h / 2
	local function slab(ax0, ax1, ay0, ay1)
		if ax1 - ax0 < 0.01 or ay1 - ay0 < 0.01 then return end
		table.insert(out, part(parent, name, V3(ax1 - ax0, ay1 - ay0, t), cf * CF((ax0 + ax1) / 2, (ay0 + ay1) / 2, 0), color, mat))
	end
	slab(x0, x1, y0, hy0); slab(x0, x1, hy1, y1); slab(x0, hx0, hy0, hy1); slab(hx1, x1, hy0, hy1)
	return out
end

-- room: origin o = floor centre. returns a table of named parts + dimensions
function S.room(parent, o, W, D, H, c)
	local f = Instance.new("Folder"); f.Name = "Room"; f.Parent = parent
	local R = {folder = f, o = o, W = W, D = D, H = H}
	R.floor = part(f, "Floor", V3(W, 1, D), o * CF(0, -0.5, 0), c.floor, c.floorMat or M.WoodPlanks)
	R.ceil = part(f, "Ceiling", V3(W, 1, D), o * CF(0, H + 0.5, 0), c.ceil or rgb(240, 236, 226), M.Plaster)
	R.walls = {}
	R.back = c.backHole and S.wall(f, "WallBack", o * CF(0, H / 2, D / 2 + 0.5), W + 2, H, 1, c.wall, M.Plaster, c.backHole) or {part(f, "WallBack", V3(W + 2, H, 1), o * CF(0, H / 2, D / 2 + 0.5), c.wall, M.Plaster)}
	R.front = c.frontHole and S.wall(f, "WallFront", o * CF(0, H / 2, -D / 2 - 0.5), W + 2, H, 1, c.wall, M.Plaster, c.frontHole) or {part(f, "WallFront", V3(W + 2, H, 1), o * CF(0, H / 2, -D / 2 - 0.5), c.wall, M.Plaster)}
	R.left = c.leftHole and S.wall(f, "WallLeft", o * CF(-W / 2 - 0.5, H / 2, 0) * CFrame.Angles(0, rad(90), 0), D + 2, H, 1, c.wall, M.Plaster, c.leftHole) or {part(f, "WallLeft", V3(1, H, D + 2), o * CF(-W / 2 - 0.5, H / 2, 0), c.wall, M.Plaster)}
	R.right = c.rightHole and S.wall(f, "WallRight", o * CF(W / 2 + 0.5, H / 2, 0) * CFrame.Angles(0, rad(90), 0), D + 2, H, 1, c.wall, M.Plaster, c.rightHole) or {part(f, "WallRight", V3(1, H, D + 2), o * CF(W / 2 + 0.5, H / 2, 0), c.wall, M.Plaster)}
	-- wainscot + baseboard + crown
	if c.wains then
		part(f, "WainscotBack", V3(W, 3.6, 0.3), o * CF(0, 1.8, D / 2 - 0.15), c.wains, M.Wood)
		part(f, "WainscotLeft", V3(0.3, 3.6, D), o * CF(-W / 2 + 0.15, 1.8, 0), c.wains, M.Wood)
		part(f, "WainscotRight", V3(0.3, 3.6, D), o * CF(W / 2 - 0.15, 1.8, 0), c.wains, M.Wood)
		part(f, "WainscotFront", V3(W, 3.6, 0.3), o * CF(0, 1.8, -D / 2 + 0.15), c.wains, M.Wood)
		local rail = c.wains:Lerp(rgb(255, 255, 255), 0.35)
		part(f, "RailBack", V3(W, 0.35, 0.45), o * CF(0, 3.7, D / 2 - 0.2), rail, M.Wood)
		part(f, "RailLeft", V3(0.45, 0.35, D), o * CF(-W / 2 + 0.2, 3.7, 0), rail, M.Wood)
		part(f, "RailRight", V3(0.45, 0.35, D), o * CF(W / 2 - 0.2, 3.7, 0), rail, M.Wood)
		part(f, "RailFront", V3(W, 0.35, 0.45), o * CF(0, 3.7, -D / 2 + 0.2), rail, M.Wood)
	end
	return R
end

function S.table(parent, cf, w, d, h, color)
	local m = Instance.new("Model"); m.Name = "Table"; m.Parent = parent
	part(m, "Top", V3(w, 0.45, d), cf * CF(0, h, 0), color, M.Wood)
	part(m, "Apron", V3(w - 0.6, 0.5, d - 0.6), cf * CF(0, h - 0.45, 0), color:Lerp(rgb(0, 0, 0), 0.2), M.Wood)
	for _, sx in ipairs({-1, 1}) do for _, sz in ipairs({-1, 1}) do
		part(m, "Leg", V3(0.5, h, 0.5), cf * CF(sx * (w / 2 - 0.5), h / 2, sz * (d / 2 - 0.5)), color:Lerp(rgb(0, 0, 0), 0.25), M.Wood)
	end end
	return m
end
-- chair: seat at y=2, back at +Z (so a sitter faces -Z)
function S.chair(parent, cf, color)
	local m = Instance.new("Model"); m.Name = "Chair"; m.Parent = parent
	part(m, "Seat", V3(2.4, 0.4, 2.4), cf * CF(0, 1.9, 0), color, M.Wood)
	part(m, "Back", V3(2.4, 2.8, 0.35), cf * CF(0, 3.6, 1.1), color, M.Wood)
	for _, sx in ipairs({-1, 1}) do for _, sz in ipairs({-1, 1}) do
		part(m, "Leg", V3(0.3, 1.8, 0.3), cf * CF(sx * 1.0, 0.9, sz * 1.0), color:Lerp(rgb(0, 0, 0), 0.3), M.Wood)
	end end
	return m
end
function S.armchair(parent, cf, color)
	local m = Instance.new("Model"); m.Name = "Armchair"; m.Parent = parent
	part(m, "Seat", V3(4.4, 1.2, 4), cf * CF(0, 1.5, 0), color, M.Fabric)
	part(m, "Cushion", V3(3.4, 0.7, 3.2), cf * CF(0, 2.3, -0.1), color:Lerp(rgb(255, 255, 255), 0.12), M.Fabric)
	part(m, "Back", V3(4.6, 4.6, 1.2), cf * CF(0, 3.5, 1.7), color, M.Fabric)
	for _, sx in ipairs({-1, 1}) do part(m, "Arm", V3(0.9, 2.6, 4), cf * CF(sx * 2.45, 2.3, 0), color, M.Fabric) end
	for _, sx in ipairs({-1, 1}) do for _, sz in ipairs({-1, 1}) do part(m, "Foot", V3(0.5, 0.6, 0.5), cf * CF(sx * 2, 0.3, sz * 1.6), rgb(70, 45, 30), M.Wood) end end
	return m
end
function S.bed(parent, cf, blanket, pillow)
	local m = Instance.new("Model"); m.Name = "Bed"; m.Parent = parent
	part(m, "Frame", V3(5.2, 1.4, 9.6), cf * CF(0, 0.9, 0), rgb(120, 82, 55), M.Wood)
	part(m, "Mattress", V3(4.8, 0.9, 9), cf * CF(0, 1.9, 0), rgb(244, 240, 232), M.Fabric)
	part(m, "Blanket", V3(4.9, 0.5, 6.2), cf * CF(0, 2.4, -1.4), blanket, M.Fabric)
	part(m, "Pillow", V3(3.4, 0.8, 1.8), cf * CF(0, 2.6, 3.4), pillow or rgb(255, 255, 255), M.Fabric)
	part(m, "Headboard", V3(5.4, 3.4, 0.5), cf * CF(0, 2.6, 4.95), rgb(120, 82, 55), M.Wood)
	return m
end
function S.counter(parent, cf, w, color, top)
	local m = Instance.new("Model"); m.Name = "Counter"; m.Parent = parent
	part(m, "Base", V3(w, 3.4, 2.6), cf * CF(0, 1.7, 0), color, M.Wood)
	part(m, "Top", V3(w + 0.2, 0.35, 2.8), cf * CF(0, 3.55, 0), top or rgb(230, 228, 222), M.Marble)
	local n = math.max(1, math.floor(w / 2.6))
	for i = 1, n do
		part(m, "Door", V3(w / n - 0.3, 2.6, 0.12), cf * CF(-w / 2 + (i - 0.5) * (w / n), 1.8, -1.35), color:Lerp(rgb(255, 255, 255), 0.15), M.Wood)
		part(m, "Knob", V3(0.22, 0.22, 0.22), cf * CF(-w / 2 + (i - 0.5) * (w / n) + 0.7, 2.6, -1.5), rgb(220, 200, 120), M.Metal, Enum.PartType.Ball)
	end
	return m
end
function S.sink(parent, cf)
	local m = Instance.new("Model"); m.Name = "Sink"; m.Parent = parent
	part(m, "Basin", V3(2.8, 0.25, 1.8), cf * CF(0, 3.62, 0), rgb(170, 176, 182), M.Metal)
	part(m, "TapPost", V3(0.25, 1.2, 0.25), cf * CF(0, 4.3, 0.9), rgb(200, 204, 210), M.Metal)
	part(m, "TapSpout", V3(0.25, 0.25, 0.9), cf * CF(0, 4.85, 0.5), rgb(200, 204, 210), M.Metal)
	return m
end
function S.fridge(parent, cf, color)
	local m = Instance.new("Model"); m.Name = "Fridge"; m.Parent = parent
	part(m, "Body", V3(3.4, 7.4, 3), cf * CF(0, 3.7, 0), color or rgb(214, 226, 232), M.Metal)
	part(m, "Seam", V3(3.3, 0.12, 0.1), cf * CF(0, 5.4, -1.52), rgb(120, 130, 136), M.Metal)
	part(m, "Handle1", V3(0.2, 1.6, 0.2), cf * CF(1.3, 6.4, -1.65), rgb(150, 156, 160), M.Metal)
	part(m, "Handle2", V3(0.2, 2.6, 0.2), cf * CF(1.3, 3.0, -1.65), rgb(150, 156, 160), M.Metal)
	return m
end
function S.stove(parent, cf)
	local m = Instance.new("Model"); m.Name = "Stove"; m.Parent = parent
	part(m, "Body", V3(3.6, 3.5, 2.8), cf * CF(0, 1.75, 0), rgb(60, 64, 72), M.Metal)
	part(m, "Top", V3(3.6, 0.3, 2.8), cf * CF(0, 3.55, 0), rgb(34, 36, 42), M.Metal)
	for _, p in ipairs({{-0.8, -0.5}, {0.8, -0.5}, {-0.8, 0.6}, {0.8, 0.6}}) do cyl(m, "Burner", 0.12, 1.0, cf * CF(p[1], 3.76, p[2]) * CFrame.Angles(0, 0, rad(90)), rgb(20, 20, 24), M.Metal) end
	return m
end
function S.rug(parent, cf, w, d, color, trim)
	local m = Instance.new("Model"); m.Name = "Rug"; m.Parent = parent
	part(m, "Trim", V3(w, 0.08, d), cf * CF(0, 0.06, 0), trim or color:Lerp(rgb(255, 255, 255), 0.25), M.Fabric)
	part(m, "Rug", V3(w - 1, 0.1, d - 1), cf * CF(0, 0.1, 0), color, M.Fabric)
	return m
end

-- window: frame faces -Z of cf (sits in a wall whose normal is Z). glass is dark night by default.
function S.window(parent, cf, w, h, glassColor)
	local m = Instance.new("Model"); m.Name = "Window"; m.Parent = parent
	local fr = rgb(244, 242, 236)
	part(m, "FrameTop", V3(w + 0.9, 0.45, 0.8), cf * CF(0, h / 2 + 0.2, 0), fr, M.Wood)
	part(m, "FrameBottom", V3(w + 1.2, 0.5, 1.1), cf * CF(0, -h / 2 - 0.25, -0.15), fr, M.Wood)
	part(m, "FrameL", V3(0.45, h, 0.8), cf * CF(-w / 2 - 0.2, 0, 0), fr, M.Wood)
	part(m, "FrameR", V3(0.45, h, 0.8), cf * CF(w / 2 + 0.2, 0, 0), fr, M.Wood)
	local g = part(m, "Glass", V3(w, h, 0.15), cf * CF(0, 0, 0.1), glassColor or rgb(14, 20, 44), M.Neon)
	part(m, "MullV", V3(0.25, h, 0.3), cf * CF(0, 0, -0.1), fr, M.Wood)
	part(m, "MullH", V3(w, 0.25, 0.3), cf * CF(0, 0, -0.1), fr, M.Wood)
	return m, g
end
-- door in a wall with normal Z: hinge on the local -X edge. returns model, the swinging leaf, hinge CFrame
function S.door(parent, cf, w, h, color)
	local m = Instance.new("Model"); m.Name = "Door"; m.Parent = parent
	part(m, "FrameTop", V3(w + 1.2, 0.6, 1.2), cf * CF(0, h + 0.3, 0), rgb(236, 232, 222), M.Wood)
	part(m, "FrameL", V3(0.6, h, 1.2), cf * CF(-w / 2 - 0.3, h / 2, 0), rgb(236, 232, 222), M.Wood)
	part(m, "FrameR", V3(0.6, h, 1.2), cf * CF(w / 2 + 0.3, h / 2, 0), rgb(236, 232, 222), M.Wood)
	local leaf = part(m, "Leaf", V3(w, h, 0.4), cf * CF(0, h / 2, 0), color or rgb(110, 70, 48), M.Wood)
	local knob = ball(m, "Knob", 0.45, cf * CF(w / 2 - 0.5, h / 2, -0.35), rgb(236, 206, 110), M.Metal)
	local hinge = cf * CF(-w / 2, 0, 0) -- rotate the leaf about hinge Y axis
	return m, {leaf, knob}, hinge, cf
end
function S.picture(parent, cf, w, h, color, framec)
	local m = Instance.new("Model"); m.Name = "Picture"; m.Parent = parent
	part(m, "Frame", V3(w + 0.6, h + 0.6, 0.3), cf, framec or rgb(90, 62, 40), M.Wood)
	part(m, "Art", V3(w, h, 0.15), cf * CF(0, 0, -0.1), color, M.SmoothPlastic)
	return m
end
-- wall clock, face towards -Z of cf. returns hour & minute hand parts (pivot at the centre)
function S.clock(parent, cf, r)
	local m = Instance.new("Model"); m.Name = "Clock"; m.Parent = parent
	cyl(m, "Rim", 0.5, r * 2 + 0.5, cf * CFrame.Angles(0, rad(90), 0), rgb(70, 46, 30), M.Wood)
	cyl(m, "Face", 0.4, r * 2, cf * CF(0, 0, -0.12) * CFrame.Angles(0, rad(90), 0), rgb(250, 246, 234), M.SmoothPlastic)
	for i = 0, 11 do
		local a = rad(i * 30)
		part(m, "Tick", V3(0.16, i % 3 == 0 and 0.55 or 0.3, 0.1), cf * CF(math.sin(a) * (r - 0.5), math.cos(a) * (r - 0.5), -0.36) * CFrame.Angles(0, 0, -a), rgb(40, 34, 30))
	end
	local mh = part(m, "Minute", V3(0.18, r * 0.8, 0.1), cf, rgb(30, 26, 24)); mh.Name = "Minute"
	local hh = part(m, "Hour", V3(0.24, r * 0.55, 0.1), cf, rgb(30, 26, 24)); hh.Name = "Hour"
	return m, hh, mh
end
function S.setClock(cf, hh, mh, hour, minute, r)
	local ma = rad(minute * 6); local ha = rad((hour % 12) * 30 + minute * 0.5)
	mh.CFrame = cf * CF(0, 0, -0.45) * CFrame.Angles(0, 0, -ma) * CF(0, r * 0.4, 0)
	hh.CFrame = cf * CF(0, 0, -0.5) * CFrame.Angles(0, 0, -ha) * CF(0, r * 0.275, 0)
end
-- hanging ceiling lamp; returns the bulb and its light
function S.ceilingLamp(parent, pos, drop, range, bright)
	local m = Instance.new("Model"); m.Name = "CeilingLamp"; m.Parent = parent
	part(m, "Cord", V3(0.12, drop, 0.12), CF(pos - V3(0, drop / 2, 0)), rgb(30, 30, 30))
	local shade = part(m, "Shade", V3(3.2, 1.4, 3.2), CF(pos - V3(0, drop + 0.4, 0)), rgb(236, 214, 150), M.SmoothPlastic, Enum.PartType.Cylinder)
	shade.CFrame = CF(pos - V3(0, drop + 0.4, 0)) * CFrame.Angles(0, 0, rad(90)); shade.Size = V3(1.4, 3.2, 3.2)
	local bulb = ball(m, "Bulb", 1.5, CF(pos - V3(0, drop + 0.9, 0)), rgb(255, 240, 190), M.Neon)
	local l = K.light(bulb, rgb(255, 214, 150), range or 34, bright or 2.2)
	return bulb, l, m
end
function S.floorLamp(parent, pos, color)
	local m = Instance.new("Model"); m.Name = "FloorLamp"; m.Parent = parent
	cyl(m, "Base", 0.3, 1.8, CF(pos + V3(0, 0.15, 0)) * CFrame.Angles(0, 0, rad(90)), rgb(50, 40, 34), M.Metal)
	part(m, "Pole", V3(0.2, 5.4, 0.2), CF(pos + V3(0, 2.8, 0)), rgb(50, 40, 34), M.Metal)
	local sh = part(m, "Shade", V3(2.2, 1.8, 2.2), CF(pos + V3(0, 6, 0)), color or rgb(240, 214, 160), M.SmoothPlastic, Enum.PartType.Cylinder)
	sh.CFrame = CF(pos + V3(0, 6, 0)) * CFrame.Angles(0, 0, rad(90)); sh.Size = V3(1.8, 2.2, 2.2)
	local bulb = ball(m, "Bulb", 1.0, CF(pos + V3(0, 6, 0)), rgb(255, 238, 190), M.Neon)
	local l = K.light(bulb, rgb(255, 214, 150), 22, 1.6)
	return bulb, l
end

-- ===== exteriors =====
function S.streetLamp(parent, pos, face)
	local m = Instance.new("Model"); m.Name = "StreetLamp"; m.Parent = parent
	part(m, "Base", V3(1.4, 1.2, 1.4), CF(pos + V3(0, 0.6, 0)), rgb(36, 38, 44), M.Metal)
	part(m, "Pole", V3(0.5, 13, 0.5), CF(pos + V3(0, 7, 0)), rgb(36, 38, 44), M.Metal)
	local dir = face or 1
	part(m, "Arm", V3(2.6, 0.4, 0.4), CF(pos + V3(dir * 1.2, 13.2, 0)), rgb(36, 38, 44), M.Metal)
	local bulb = part(m, "Bulb", V3(1.6, 0.9, 1.6), CF(pos + V3(dir * 2.4, 12.8, 0)), rgb(255, 232, 170), M.Neon)
	local l = K.light(bulb, rgb(255, 214, 150), 34, 1.8)
	return m, bulb, l
end
function S.fence(parent, o, len, color)
	local m = Instance.new("Model"); m.Name = "Fence"; m.Parent = parent
	for i = 0, math.floor(len / 1.4) do part(m, "Picket", V3(0.5, 2.6, 0.2), o * CF(i * 1.4, 1.3, 0), color, M.Wood) end
	part(m, "RailA", V3(len, 0.3, 0.25), o * CF(len / 2, 0.8, 0.1), color, M.Wood)
	part(m, "RailB", V3(len, 0.3, 0.25), o * CF(len / 2, 1.9, 0.1), color, M.Wood)
	return m
end
function S.sign(parent, cf, w, h, text, textColor, bg, post)
	local m = Instance.new("Model"); m.Name = "Sign"; m.Parent = parent
	if post then part(m, "Post", V3(0.5, post, 0.5), cf * CF(0, -h / 2 - post / 2, 0.3), rgb(70, 52, 40), M.Wood) end
	part(m, "Back", V3(w + 0.8, h + 0.8, 0.5), cf * CF(0, 0, 0.1), rgb(60, 46, 36), M.Wood)
	local b = part(m, "Board", V3(w, h, 0.3), cf * CF(0, 0, -0.1), bg or rgb(34, 38, 60), M.SmoothPlastic)
	K.label(b, text, textColor, nil, Enum.NormalId.Front)
	return m, b
end
function S.horn(parent, pos)
	local m = Instance.new("Model"); m.Name = "SirenHorn"; m.Parent = parent
	part(m, "Pole", V3(0.8, 22, 0.8), CF(pos + V3(0, 11, 0)), rgb(60, 62, 70), M.Metal)
	local bell = part(m, "Bell", V3(5, 3.6, 3.6), CF(pos + V3(0, 22.5, 0)), rgb(210, 70, 60), M.Metal, Enum.PartType.Cylinder)
	bell.CFrame = CF(pos + V3(0, 22.5, 0)) * CFrame.Angles(0, 0, 0)
	part(m, "Mount", V3(1.8, 1.8, 1.8), CF(pos + V3(0, 21.6, 0)), rgb(50, 52, 60), M.Metal)
	return m, bell
end

return S
