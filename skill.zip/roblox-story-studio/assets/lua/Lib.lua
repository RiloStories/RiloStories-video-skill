-- Lib: R6 character maker + simple town set pieces. Works in an empty place: every external asset is optional.
local Lib = {}
local RS = game:GetService('ReplicatedStorage')

function Lib.rgb(r,g,b) return Color3.fromRGB(r,g,b) end

local function template()
  return RS:FindFirstChild('PreviewRig') or RS:WaitForChild('R15Template')
end

-- cfg: skin, shirt, sleeves(bool or color), pants, hair(name), hat(name), scale, hairColor
function Lib.make(name, cfg, cframe)
  local m = template():Clone()
  m.Name = name
  for _, d in ipairs(m:GetDescendants()) do
    if d:IsA("Shirt") then d.ShirtTemplate = "" elseif d:IsA("Pants") then d.PantsTemplate = "" end
  end
  local skin = cfg.skin or Color3.fromRGB(255, 204, 153)
  local function paint(n, c) local p = m:FindFirstChild(n); if p then p.Color = c end end
  paint("Head", skin)
  paint("Torso", cfg.shirt or Color3.fromRGB(70,110,200))
  local sl = cfg.sleeves
  local armc = (sl == true) and (cfg.shirt or Color3.fromRGB(70,110,200)) or (typeof(sl) == "Color3" and sl) or skin
  paint("Left Arm", armc); paint("Right Arm", armc)
  local pc = cfg.pants or Color3.fromRGB(50,50,70)
  paint("Left Leg", pc); paint("Right Leg", pc)
  m.Parent = workspace
  local hum = m:FindFirstChildOfClass("Humanoid")
  local wardrobe = RS:FindFirstChild("WardrobeRS") or workspace:FindFirstChild("Wardrobe")
  for _, key in ipairs({"hair","hat"}) do
    local an = cfg[key]
    if an and wardrobe and hum then
      local src = wardrobe:FindFirstChild(an)
      if src then
        local a = src:Clone(); a.Name = an
        if cfg.hairColor and key == "hair" then
          for _, p in ipairs(a:GetDescendants()) do
            if p:IsA("BasePart") then p.Color = cfg.hairColor end
            if p:IsA("SpecialMesh") then p.TextureId = "" end
            if p:IsA("MeshPart") then pcall(function() p.TextureID = "" end) end
          end
        end
        hum:AddAccessory(a)
      end
    end
  end
  if cfg.scale then m:ScaleTo(cfg.scale) end
  if cframe then m:PivotTo(cframe) end
  return m
end

-- ===== SET BUILDING =====
local function part(parent, name, size, cf, color, mat, shape)
  local p = Instance.new("Part")
  p.Name = name; p.Size = size; p.CFrame = cf; p.Color = color; p.Material = mat or Enum.Material.SmoothPlastic
  p.Anchored = true; p.TopSurface = Enum.SurfaceType.Smooth; p.BottomSurface = Enum.SurfaceType.Smooth
  p.CastShadow = true
  if shape then p.Shape = shape end
  p.Parent = parent
  return p
end
Lib.part = part

function Lib.house(parent, origin, w, d, h, wall, roof, facing)
  -- origin: CFrame of the house base centre on ground; front faces -Z of origin
  local m = Instance.new("Model"); m.Name = "House"; m.Parent = parent
  local cf = origin
  part(m, "Walls", Vector3.new(w, h, d), cf * CFrame.new(0, h/2, 0), wall, Enum.Material.Concrete)
  part(m, "Base", Vector3.new(w+0.6, 0.8, d+0.6), cf * CFrame.new(0, 0.4, 0), Color3.fromRGB(120,115,110), Enum.Material.Concrete)
  local half = w/2
  local rh = h*0.42
  local ang = math.atan2(rh, half)
  local L = math.sqrt(half*half + rh*rh) + 1.2
  for _, sgn in ipairs({1,-1}) do
    part(m, "RoofSlab", Vector3.new(L, 0.7, d+1.8), cf * CFrame.new(sgn*half/2, h+rh/2+0.2, 0) * CFrame.Angles(0, 0, -sgn*ang), roof, Enum.Material.Slate)
  end
  part(m, "RoofRidge", Vector3.new(1.2, 0.9, d+1.9), cf * CFrame.new(0, h+rh+0.45, 0), roof:Lerp(Color3.new(0,0,0), 0.25), Enum.Material.Slate)
  for _, zs in ipairs({-1, 1}) do
    for _, sgn in ipairs({1, -1}) do
      local wdg = Instance.new("WedgePart"); wdg.Name = "Gable"; wdg.Anchored = true
      wdg.Color = wall; wdg.Material = Enum.Material.Concrete
      wdg.Size = Vector3.new(0.8, rh, half)
      wdg.CFrame = cf * CFrame.new(sgn*half/2, h+rh/2, zs*(d/2-0.4)) * CFrame.Angles(0, math.rad(sgn > 0 and -90 or 90), 0)
      wdg.Parent = m
    end
  end
  part(m, "Chimney", Vector3.new(2.4, rh+3, 2.4), cf * CFrame.new(half*0.55, h+rh/2+1, d*0.25), Color3.fromRGB(140,90,80), Enum.Material.Brick)
  part(m, "Door", Vector3.new(3.2, 6.2, 0.4), cf * CFrame.new(0, 3.5, -d/2-0.15), Color3.fromRGB(80,50,35), Enum.Material.Wood)
  part(m, "DoorKnob", Vector3.new(0.4,0.4,0.4), cf * CFrame.new(1.0, 3.4, -d/2-0.45), Color3.fromRGB(230,200,90), Enum.Material.Metal, Enum.PartType.Ball)
  for _, sx in ipairs({-w/3, w/3}) do
    part(m, "WinFrame", Vector3.new(4.4, 4.4, 0.5), cf * CFrame.new(sx, h*0.6, -d/2-0.1), Color3.fromRGB(245,245,240))
    part(m, "Window", Vector3.new(3.6, 3.6, 0.3), cf * CFrame.new(sx, h*0.6, -d/2-0.3), Color3.fromRGB(255,215,130), Enum.Material.Neon)
    part(m, "Mull", Vector3.new(0.3, 3.6, 0.35), cf * CFrame.new(sx, h*0.6, -d/2-0.35), Color3.fromRGB(245,245,240))
    part(m, "Mull", Vector3.new(3.6, 0.3, 0.35), cf * CFrame.new(sx, h*0.6, -d/2-0.35), Color3.fromRGB(245,245,240))
  end
  return m
end

function Lib.lamp(parent, pos)
  local m = Instance.new("Model"); m.Name = "Lamp"; m.Parent = parent
  part(m, "Pole", Vector3.new(0.5, 13, 0.5), CFrame.new(pos + Vector3.new(0,6.5,0)), Color3.fromRGB(40,40,45), Enum.Material.Metal)
  part(m, "Arm", Vector3.new(2.5, 0.4, 0.4), CFrame.new(pos + Vector3.new(1,13,0)), Color3.fromRGB(40,40,45), Enum.Material.Metal)
  local b = part(m, "Bulb", Vector3.new(1.4, 0.8, 1.4), CFrame.new(pos + Vector3.new(2,12.6,0)), Color3.fromRGB(255,230,160), Enum.Material.Neon)
  local l = Instance.new("PointLight", b); l.Range = 28; l.Brightness = 1.6; l.Color = Color3.fromRGB(255,220,150)
  return m
end

function Lib.tree(parent, pos, s)
  s = s or 1
  local m = Instance.new("Model"); m.Name = "Tree"; m.Parent = parent
  part(m, "Trunk", Vector3.new(7*s, 1.6*s, 1.6*s), CFrame.new(pos + Vector3.new(0,3.5*s,0)) * CFrame.Angles(0,0,math.rad(90)), Color3.fromRGB(95,65,40), Enum.Material.Wood, Enum.PartType.Cylinder)
  part(m, "Leaves1", Vector3.new(9*s, 8*s, 9*s), CFrame.new(pos + Vector3.new(0,10*s,0)), Color3.fromRGB(70,140,70), Enum.Material.Grass, Enum.PartType.Ball)
  part(m, "Leaves2", Vector3.new(6*s, 6*s, 6*s), CFrame.new(pos + Vector3.new(2.5*s,12.5*s,1*s)), Color3.fromRGB(85,160,80), Enum.Material.Grass, Enum.PartType.Ball)
  return m
end

-- Town street set: road along X, houses on both sides. origin = street centre.
function Lib.street(origin)
  local f = workspace:FindFirstChild("SetStreet"); if f then f:Destroy() end
  f = Instance.new("Folder"); f.Name = "SetStreet"; f.Parent = workspace
  local o = origin
  part(f, "Ground", Vector3.new(400, 1, 200), o * CFrame.new(0,-0.5,0), Color3.fromRGB(90,150,85), Enum.Material.Grass)
  part(f, "Road", Vector3.new(400, 0.4, 22), o * CFrame.new(0,0.1,0), Color3.fromRGB(55,55,60), Enum.Material.Asphalt)
  for i = -9, 9 do part(f, "Dash", Vector3.new(6, 0.45, 0.6), o * CFrame.new(i*20, 0.12, 0), Color3.fromRGB(240,225,120)) end
  part(f, "SidewalkN", Vector3.new(400, 0.6, 8), o * CFrame.new(0,0.3,-15), Color3.fromRGB(190,188,182), Enum.Material.Concrete)
  part(f, "SidewalkS", Vector3.new(400, 0.6, 8), o * CFrame.new(0,0.3,15), Color3.fromRGB(190,188,182), Enum.Material.Concrete)
  local walls = {Color3.fromRGB(240,215,170), Color3.fromRGB(200,225,240), Color3.fromRGB(235,190,190), Color3.fromRGB(205,230,200), Color3.fromRGB(245,235,200)}
  local roofs = {Color3.fromRGB(150,70,60), Color3.fromRGB(70,80,110), Color3.fromRGB(100,90,80)}
  for i = -6, 6 do
    Lib.house(f, o * CFrame.new(i*28, 0, -42) * CFrame.Angles(0, math.rad(180), 0), 20, 16, 15 + (i%3)*2, walls[((i+6)%5)+1], roofs[((i+6)%3)+1])
    Lib.house(f, o * CFrame.new(i*28+14, 0, 42), 20, 16, 14 + ((i+1)%3)*2, walls[((i+8)%5)+1], roofs[((i+5)%3)+1])
    Lib.lamp(f, (o * CFrame.new(i*28, 0, -19)).Position)
    Lib.lamp(f, (o * CFrame.new(i*28+14, 0, 19)).Position)
    if i % 2 == 0 then Lib.tree(f, (o * CFrame.new(i*28+10, 0, -26)).Position, 1) end
  end
  return f
end

return Lib
