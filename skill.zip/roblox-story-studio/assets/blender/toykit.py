"""toykit.py - Blender (bpy) helpers for chunky toy-style props that match a blocky cast. Tested settings.
Paste into execute_blender_code (MCP for Blender) or run: blender -b -P toykit.py -- <out.glb>

Where it fits:
  * 3D-cartoon / stickman engine (engines/inkbeat): every prop and set piece -> export GLB -> load in three.js.
  * Roblox stories: only for hero props that need smooth or organic forms. Parts-kitbash in Studio is the default there
    (no upload step, exact style). A Blender mesh reaches Roblox via Studio's 3D Importer (File > Import 3D) or an
    Open Cloud asset upload; then treat it like an AI mesh (ai_mesh_normalize.lua).
Settings that made it look right (first try looked milky and too soft):
  * view transform "Standard" (AgX/Filmic desaturates flat toy colours), roughness 0.8, no textures
  * bevel width 0.012 m, 2 segments (bigger bevels turn blocks into soap bars)
  * 1 Roblox stud = 1/3 m, Z up, the FRONT faces -Y (glTF export turns this into +Z forward / Y up)
"""
import bpy, math
from mathutils import Vector

STUD = 1 / 3.0
PAL = {"red": (0.75, 0.04, 0.04), "orange": (0.87, 0.26, 0.03), "yellow": (0.96, 0.62, 0.05), "green": (0.06, 0.35, 0.10),
       "blue": (0.06, 0.22, 0.79), "tan": (0.67, 0.29, 0.09), "cream": (0.93, 0.73, 0.52), "white": (0.95, 0.94, 0.88),
       "ink": (0.01, 0.01, 0.012), "brown": (0.30, 0.13, 0.05), "pink": (0.87, 0.22, 0.40), "grey": (0.30, 0.31, 0.37)}
_mats = {}


def setup_scene(clear=True):
    sc = bpy.context.scene
    if clear:
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
    try:
        sc.view_settings.view_transform = "Standard"
    except TypeError:
        pass
    col = bpy.data.collections.get("Toy") or bpy.data.collections.new("Toy")
    if col.name not in sc.collection.children:
        sc.collection.children.link(col)
    return col


def mat(name, rgb):
    if name in _mats:
        return _mats[name]
    m = bpy.data.materials.new(name); m.use_nodes = True
    b = next(n for n in m.node_tree.nodes if n.type == "BSDF_PRINCIPLED")
    b.inputs["Base Color"].default_value = (*rgb, 1); b.inputs["Roughness"].default_value = 0.8
    _mats[name] = m
    return m


def _finish(o, col, rgb, name, bevel):
    if bevel:
        md = o.modifiers.new("Bevel", "BEVEL"); md.width = bevel; md.segments = 2; md.limit_method = "NONE"
    key = rgb if isinstance(rgb, str) else None
    o.data.materials.append(mat(key or name + "_m", PAL[key] if key else rgb))
    bpy.ops.object.shade_smooth()
    for c in o.users_collection:
        c.objects.unlink(o)
    col.objects.link(o)
    return o


def box(col, name, size_studs, pos_studs, rgb, rot_deg=(0, 0, 0), bevel=0.012):
    """size/pos in studs, Roblox-style axes converted: (x, y_up, z_toward_camera) -> Blender (x, -z, y)."""
    sx, sy, sz = size_studs; px, py, pz = pos_studs
    bpy.ops.mesh.primitive_cube_add(size=1, location=(px * STUD, -pz * STUD, py * STUD), rotation=[math.radians(a) for a in rot_deg])
    o = bpy.context.object; o.name = name; o.scale = (sx * STUD, sz * STUD, sy * STUD)
    bpy.ops.object.transform_apply(scale=True)
    return _finish(o, col, rgb, name, bevel)


def cyl(col, name, height_studs, dia_studs, pos_studs, rgb, facing_camera=False, bevel=0.01):
    px, py, pz = pos_studs
    rot = (math.radians(90), 0, 0) if facing_camera else (0, 0, 0)
    bpy.ops.mesh.primitive_cylinder_add(vertices=24, radius=dia_studs * STUD / 2, depth=height_studs * STUD, location=(px * STUD, -pz * STUD, py * STUD), rotation=rot)
    return _finish(bpy.context.object, col, rgb, name, bevel)


def ball(col, name, dia_studs, pos_studs, rgb):
    px, py, pz = pos_studs
    bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=12, radius=dia_studs * STUD / 2, location=(px * STUD, -pz * STUD, py * STUD))
    return _finish(bpy.context.object, col, rgb, name, 0)


def preview_rig(target_height_m=1.0):
    """ground, sun, sky and a 3/4 camera so `look(mode='camera')` shows the prop like a story shot."""
    bpy.ops.mesh.primitive_plane_add(size=10); g = bpy.context.object; g.data.materials.append(mat("Ground", (0.25, 0.5, 0.2)))
    bpy.ops.object.light_add(type="SUN"); s = bpy.context.object; s.data.energy = 3.5; s.rotation_euler = (math.radians(50), 0, math.radians(30))
    w = bpy.context.scene.world or bpy.data.worlds.new("W"); bpy.context.scene.world = w; w.use_nodes = True
    bg = next(n for n in w.node_tree.nodes if n.type == "BACKGROUND"); bg.inputs[0].default_value = (0.55, 0.72, 0.95, 1)
    d = target_height_m * 3.2
    bpy.ops.object.camera_add(location=(d * 0.45, -d, target_height_m * 1.6)); cam = bpy.context.object
    cam.rotation_euler = (Vector((0, 0, target_height_m * 0.55)) - cam.location).to_track_quat("-Z", "Y").to_euler()
    bpy.context.scene.camera = cam


def export_glb(col, path):
    bpy.ops.object.select_all(action="DESELECT")
    for o in col.objects:
        o.select_set(True)
    bpy.ops.export_scene.gltf(filepath=path, use_selection=True, export_apply=True)
    return path


if __name__ == "__main__":
    # demo: the tested toy dog (same proportions as assets/studio/example_kitbash_props.lua)
    import sys
    col = setup_scene()
    fur, dark, light = "tan", "brown", "cream"
    box(col, "Body", (1.6, 1.6, 2.0), (0, 1.2, -0.2), fur, (25, 0, 0))
    box(col, "Head", (1.5, 1.3, 1.3), (0, 2.55, 0.45), fur)
    box(col, "Snout", (0.8, 0.55, 0.6), (0, 2.3, 1.35), light)
    box(col, "Nose", (0.35, 0.25, 0.2), (0, 2.52, 1.68), "ink")
    for sx in (-1, 1):
        box(col, "Eye", (0.22, 0.3, 0.1), (sx * 0.38, 2.75, 1.12), "ink", bevel=0.004)
        box(col, "Ear", (0.35, 0.9, 0.5), (sx * 0.85, 2.45, 0.35), dark, (0, sx * 12, 0))
        box(col, "Leg", (0.42, 1.2, 0.42), (sx * 0.45, 0.6, 0.55), fur)
        box(col, "Paw", (0.5, 0.25, 0.6), (sx * 0.45, 0.125, 0.65), light)
        box(col, "Haunch", (0.6, 0.8, 1.1), (sx * 0.7, 0.45, -0.6), fur)
    box(col, "Tail", (0.3, 0.3, 0.9), (0, 0.7, -1.45), dark, (35, 0, 0))
    box(col, "Collar", (1.6, 0.2, 1.4), (0, 1.98, 0.45), "red")
    preview_rig(1.1)
    if "--" in sys.argv:
        export_glb(col, sys.argv[sys.argv.index("--") + 1])
