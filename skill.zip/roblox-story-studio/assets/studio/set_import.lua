-- set_import.lua : make an inserted Creator Store set (classroom, town hall, kitchen ...) safe and reusable.
-- 1) insert candidates with insert_asset into workspace.RSS_SetCandidates (one Model each)
-- 2) PASS="review": strips every script (free models can carry malicious code), anchors everything, spreads the
--    candidates 300 studs apart at x=70000 and returns, per candidate, its size and a camera position/target for an
--    inside view -> screen_capture each one and score it (references/07-sets-and-assets.md rubric)
-- 3) PASS="keep": (also measures sky gaps, near-white exposure and brand/poster candidates) moves the winner to ReplicatedStorage.RiloSets[NAME] with the floor at y=0, centred, and the main
--    wall (board/stage/counter) toward -Z (set YAW so that is true), then deletes the other candidates.
local PASS, KEEP, NAME, YAW = "@PASS@", "@KEEP@", "@NAME@", tonumber("@YAW@") or 0
local RS = game:GetService("ReplicatedStorage")
local box = workspace:FindFirstChild("RSS_SetCandidates")
if not box then return "put candidates in workspace.RSS_SetCandidates first" end
local function clean(m)
	local n = 0
	for _, d in ipairs(m:GetDescendants()) do
		if d:IsA("LuaSourceContainer") then d:Destroy(); n += 1
		elseif d:IsA("BasePart") then d.Anchored = true; d.CanCollide = false
		elseif d:IsA("Sound") or d:IsA("ParticleEmitter") and d.Rate > 200 then d:Destroy() end
	end
	return n
end
local function floorY(m)
	-- the floor is the LOWEST large flat surface (the ceiling and roof slabs are large and flat too, so never take the highest)
	local cf, sz = m:GetBoundingBox(); local best = math.huge
	for _, d in ipairs(m:GetDescendants()) do
		if d:IsA("BasePart") and d.Size.X * d.Size.Z > sz.X * sz.Z * 0.35 and d.Size.Y < 3 then best = math.min(best, d.Position.Y + d.Size.Y / 2) end
	end
	if best == math.huge then best = cf.Position.Y - sz.Y / 2 end
	return best
end
if PASS == "review" then
	local out = {}
	for i, m in ipairs(box:GetChildren()) do
		local n = clean(m)
		local cf, sz = m:GetBoundingBox()
		local fy = floorY(m)
		local base = Vector3.new(70000 + (i - 1) * 300, 0, 0)
		m:PivotTo(m:GetPivot() + (base - Vector3.new(cf.Position.X, fy, cf.Position.Z)))
		local parts = 0 for _, d in ipairs(m:GetDescendants()) do if d:IsA("BasePart") then parts += 1 end end
		table.insert(out, string.format('%s: %dx%dx%d studs, %d parts, %d scripts removed | camera {%d, 6, %d} look {%d, 4, %d} (and the reverse)',
			m.Name, sz.X, sz.Y, sz.Z, parts, n, base.X, base.Z + sz.Z * 0.4, base.X, base.Z - sz.Z / 2))
	end
	return table.concat(out, "\n")
elseif PASS == "keep" then
	local m = box:FindFirstChild(KEEP)
	if not m then return "no candidate " .. KEEP end
	clean(m)
	local cf = m:GetBoundingBox()
	local fy = floorY(m)
	m:PivotTo(CFrame.new(0, 0, 0) * CFrame.Angles(0, math.rad(YAW), 0) * CFrame.new(-cf.Position.X, -fy, -cf.Position.Z) * m:GetPivot())
	-- everything that needs raycasts happens HERE, while the set is still in workspace (raycasts cannot hit ReplicatedStorage:
	-- an earlier version measured after reparenting, saw "100% sky" on every set and put ceilings on top of the roofs)
	local bcf, sz = m:GetBoundingBox()
	local rp = RaycastParams.new(); rp.FilterType = Enum.RaycastFilterType.Include; rp.FilterDescendantsInstances = {m}
	local miss, tot = 0, 0
	for ix = 1, 9 do for iz = 1, 9 do
		local pt = Vector3.new(bcf.Position.X + (ix / 10 - 0.5) * sz.X, 4, bcf.Position.Z + (iz / 10 - 0.5) * sz.Z)
		local below = workspace:Raycast(pt, Vector3.new(0, -8, 0), rp)          -- only count points that stand on the set's own floor
		if below then
			tot += 1
			if not workspace:Raycast(pt, Vector3.new(0, sz.Y + 10, 0), rp) then miss += 1 end
		end
	end end
	local skyPct = tot > 0 and math.floor(miss / tot * 100) or 0
	local roofNote = string.format("sky above %d%% of the floor plan", skyPct)
	-- add a ceiling only for a single-room-height interior (a classroom shell open at the top). Houses and halls with roofs/gardens
	-- are reported but never capped (a slab over a whole house with a garden lands on the roof): choose camera angles that avoid the gaps.
	if skyPct > 40 and sz.Y < 25 then
		local under = math.huge
		for _, d in ipairs(m:GetDescendants()) do
			if d:IsA("BasePart") and d.Size.X * d.Size.Z > sz.X * sz.Z * 0.2 and d.Size.Y < 3 and d.Position.Y > sz.Y * 0.5 then under = math.min(under, d.Position.Y - d.Size.Y / 2) end
		end
		if under == math.huge then under = sz.Y - 0.3 end
		local ceil = Instance.new("Part"); ceil.Name = "AddedCeiling"; ceil.Anchored = true; ceil.CanCollide = false
		ceil.Size = Vector3.new(sz.X, 0.4, sz.Z); ceil.Color = Color3.fromRGB(232, 232, 236); ceil.Material = Enum.Material.SmoothPlastic
		ceil.CFrame = CFrame.new(bcf.Position.X, under + 0.45, bcf.Position.Z); ceil.Parent = m
		roofNote ..= " -> added a ceiling"
	elseif skyPct > 10 then
		roofNote ..= " -> NOT capped (building has roofs/garden); keep cameras away from the gaps, the audit flags SKY_INDOORS"
	end
	-- exposure: white sets (white walls, white furniture) burn out under the engine's bright presets (brightness 2.6-2.8, bloom threshold 0.9).
	-- Measure how much of the set's surface area is near-white and store a correction that Eng.set applies when the set loads.
	local whiteA, totalA = 0, 0
	for _, d in ipairs(m:GetDescendants()) do
		if d:IsA("BasePart") and d.Transparency < 0.5 then
			local a = (d.Size.X * d.Size.Y + d.Size.Y * d.Size.Z + d.Size.X * d.Size.Z)
			local c = d.Color; local lum = 0.2126 * c.R + 0.7152 * c.G + 0.0722 * c.B
			totalA += a; if lum > 0.78 and d.Material ~= Enum.Material.Neon then whiteA += a end
		end
	end
	local whitePct = totalA > 0 and whiteA / totalA or 0
	local expoNote = "exposure normal"
	if whitePct > 0.5 then m:SetAttribute("Expo", -0.8); m:SetAttribute("BloomThr", 0.5); expoNote = string.format("%d%% near-white -> Expo -0.8, bloom threshold +0.5", whitePct * 100)
	elseif whitePct > 0.3 then m:SetAttribute("Expo", -0.4); m:SetAttribute("BloomThr", 0.3); expoNote = string.format("%d%% near-white -> Expo -0.4, bloom threshold +0.3", whitePct * 100) end
	-- brand / poster scan: list text and decals that could carry logos, posters or other games' IP. LOOK at each one in a capture;
	-- delete the decal or replace it with a neutral picture. Never ship a set with real logos.
	local brandWords = {"netflix", "youtube", "spotify", "apple", "nike", "adidas", "coca", "pepsi", "mcdonald", "disney", "pokemon", "fnaf", "minecraft", "roblox", "brookhaven", "bloxburg", "meepcity", "google", "tiktok", "instagram", "facebook", "samsung", "sony", "playstation", "xbox", "nintendo", "marvel", "star wars"}
	local flags = {}
	for _, d in ipairs(m:GetDescendants()) do
		local lname = d.Name:lower()
		for _, w in ipairs(brandWords) do
			if lname:find(w, 1, true) or (d:IsA("TextLabel") and d.Text:lower():find(w, 1, true)) then table.insert(flags, w .. ": " .. d:GetFullName():sub(-60)); break end
		end
		if d:IsA("Decal") and d.Parent and d.Parent:IsA("BasePart") then
			local pn = d.Parent.Name:lower()
			if pn:find("poster") or pn:find("picture") or pn:find("sign") or pn:find("screen") or pn:find("tv") or pn:find("frame") or pn:find("painting") then
				table.insert(flags, "LOOK decal " .. (d.Texture:match("%d+") or "?") .. " on " .. d.Parent.Name .. " at " .. string.format("(%d,%d,%d)", d.Parent.Position.X, d.Parent.Position.Y, d.Parent.Position.Z))
			end
		end
	end
	local lib = RS:FindFirstChild("RiloSets") or Instance.new("Folder", RS); lib.Name = "RiloSets"
	local old = lib:FindFirstChild(NAME); if old then old:Destroy() end
	m.Name = NAME; m.Parent = lib
	box:Destroy()
	-- spots for blocking: where the seats, desks, boards and doors are (set-local coordinates, floor y = 0)
	local spots, seen = {}, 0
	for _, d in ipairs(m:GetDescendants()) do
		local nm = d.Name:lower()
		for _, k in ipairs({"chair", "seat", "desk", "table", "board", "door", "bed", "sofa", "couch", "counter", "podium", "stage"}) do
			if nm:find(k, 1, true) and (d:IsA("BasePart") or d:IsA("Model")) and seen < 60 then
				local pos = d:IsA("Model") and d:GetPivot().Position or d.Position
				table.insert(spots, string.format("%s(%.1f, %.1f, %.1f)", k, pos.X, pos.Y, pos.Z)); seen += 1; break
			end
		end
	end
	m:SetAttribute("Spots", table.concat(spots, " "))
	return string.format("saved RiloSets.%s (%dx%dx%d)" .. string.char(10) .. "roof: %s" .. string.char(10) .. "light: %s" .. string.char(10) .. "BRAND/POSTER CHECK (%d to look at): %s" .. string.char(10) .. "Spots: %s" .. string.char(10) .. "Save the place (save_place) so the library persists.", NAME, sz.X, sz.Y, sz.Z, roofNote, expoNote, #flags, table.concat(flags, " | "), table.concat(spots, " "))
end
