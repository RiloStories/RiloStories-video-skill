-- cast_build.lua : builds real Roblox avatars (catalog clothes + accessories) into ReplicatedStorage.CastAvatars.
-- cast.py fills @CAST_JSON@ and runs this in Edit (CreateHumanoidModelFromDescription only works in Edit/server,
-- never in the client render, so the cast is built once here and cloned by K.charAvatar at render time).
-- Each entry: {key, shirt, pants, hair:{ids}, hats:{ids}, face:{ids}, back:{ids}, neck:{ids}, waist:{ids}, skin:{r,g,b}, scale, rig:"R15"}
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local RS = game:GetService("ReplicatedStorage")
local cast = HttpService:JSONDecode([==[@CAST_JSON@]==])
local folder = RS:FindFirstChild("CastAvatars") or Instance.new("Folder")
folder.Name = "CastAvatars"; folder.Parent = RS
local report = {}
for _, c in ipairs(cast) do
	local d = Instance.new("HumanoidDescription")
	if c.shirt then d.Shirt = c.shirt end
	if c.pants then d.Pants = c.pants end
	if c.tshirt then d.GraphicTShirt = c.tshirt end
	-- every accessory id (hair, hats, glasses, bags, neck...) goes into the HumanoidDescription field its real asset type needs
	-- (the catalog files "hair" items under several types, e.g. 42 = FaceAccessory), looked up with GetProductInfo
	local FIELD = {[8] = "HatAccessory", [41] = "HairAccessory", [42] = "FaceAccessory", [43] = "NeckAccessory", [44] = "ShoulderAccessory",
		[45] = "FrontAccessory", [46] = "BackAccessory", [47] = "WaistAccessory"}
	local buckets = {}
	local all = {}
	for _, k in ipairs({"hair", "hats", "faceacc", "back", "neck", "waist", "front", "shoulder"}) do for _, v in ipairs(c[k] or {}) do table.insert(all, v) end end
	for _, id in ipairs(all) do
		local ok, info = pcall(function() return game:GetService("MarketplaceService"):GetProductInfo(id, Enum.InfoType.Asset) end)
		local field = ok and FIELD[info.AssetTypeId] or "HairAccessory"
		if not ok then table.insert(report, c.key .. ": could not look up accessory " .. tostring(id)) end
		buckets[field] = buckets[field] or {}
		table.insert(buckets[field], tostring(id))
	end
	for field, list in pairs(buckets) do d[field] = table.concat(list, ",") end
	local skin = c.skin and Color3.fromRGB(c.skin[1], c.skin[2], c.skin[3]) or Color3.fromRGB(234, 184, 146)
	for _, k in ipairs({"HeadColor", "LeftArmColor", "RightArmColor", "TorsoColor", "LeftLegColor", "RightLegColor"}) do d[k] = skin end
	if c.height then d.HeightScale = c.height end
	if c.width then d.WidthScale = c.width end
	local ok, m = pcall(function() return Players:CreateHumanoidModelFromDescription(d, Enum.HumanoidRigType.R15) end)
	if not ok then
		table.insert(report, c.key .. ": FAILED " .. tostring(m))
	else
		m.Name = c.key
		for _, s in ipairs(m:GetDescendants()) do
			if s:IsA("LuaSourceContainer") then s:Destroy() elseif s:IsA("BasePart") then s.Anchored = false end
		end
		m.HumanoidRootPart.Anchored = true
		local head = m:FindFirstChild("Head")
		-- the engine swaps expressions on a decal face, so drop the dynamic-head controls (the head mesh itself stays)
		local fcs = head and head:FindFirstChildOfClass("FaceControls"); if fcs then fcs:Destroy() end
		if head and not head:FindFirstChild("face") then
			local fd = Instance.new("Decal"); fd.Name = "face"; fd.Face = Enum.NormalId.Front; fd.Texture = "rbxassetid://7802852507"; fd.Parent = head
		end
		local hum = m:FindFirstChildOfClass("Humanoid"); if hum then hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None end
		local old = folder:FindFirstChild(c.key); if old then old:Destroy() end
		m.Parent = folder
		local acc = 0 for _, a in ipairs(m:GetChildren()) do if a:IsA("Accessory") then acc += 1 end end
		table.insert(report, string.format("%s: ok (shirt %s, pants %s, %d accessories)", c.key, tostring(c.shirt), tostring(c.pants), acc))
	end
end
return table.concat(report, "\n")
