-- asset_check.lua : style + scale check bench. Puts RiloAssets[NAMES] next to a cast character on a clean stage at
-- x=40000, in story-like light. Then screen_capture: camera [40000,4.5,14] look [40000,1.6,0] (front) and
-- camera [40009,4.5,10] look [40000,1.6,0] (3/4). Accept the asset only if ALL are true (see references/07-assets.md):
--   1 same family as the cast (flat colours, chunky blocks, no realistic textures, no thin wires)
--   2 right size against the 5-stud character   3 face/front points at the camera   4 reads as the object at phone size
-- Delete workspace.RSS_AssetCheck afterwards (or re-run with NAMES = {}).
local NAMES = {"Dog_Kit", "AlarmClock_Kit"}
local RS = game:GetService("ReplicatedStorage")
local f = workspace:FindFirstChild("RSS_AssetCheck"); if f then f:Destroy() end
if #NAMES == 0 then return "cleared" end
f = Instance.new("Folder"); f.Name = "RSS_AssetCheck"; f.Parent = workspace
local O = Vector3.new(40000, 0, 0)
local g = Instance.new("Part"); g.Anchored = true; g.Size = Vector3.new(80, 1, 40); g.Position = O - Vector3.new(0, 0.5, 0)
g.Color = Color3.fromRGB(110, 168, 96); g.Material = Enum.Material.SmoothPlastic; g.Parent = f
local w = g:Clone(); w.Size = Vector3.new(80, 30, 1); w.Position = O + Vector3.new(0, 15, -10); w.Color = Color3.fromRGB(200, 225, 245); w.Parent = f
local ch = RS:FindFirstChild("R15Template")
if ch then
	ch = ch:Clone(); ch.Parent = f
	for _, p in ipairs(ch:GetDescendants()) do if p:IsA("BasePart") then p.Anchored = true end end
	local cf, sz = ch:GetBoundingBox(); ch:PivotTo(ch:GetPivot() + (O + Vector3.new(-3, sz.Y / 2, 0) - cf.Position))
end
local x = 0
local missing = {}
for _, n in ipairs(NAMES) do
	local src = RS:FindFirstChild("RiloAssets") and RS.RiloAssets:FindFirstChild(n)
	if not src then table.insert(missing, n) else
		local m = src:Clone(); m.Parent = f
		local cf, sz = m:GetBoundingBox()
		m:PivotTo(m:GetPivot() + (O + Vector3.new(x + sz.X / 2, sz.Y / 2, 0) - cf.Position))
		x = x + sz.X + 1.5
	end
end
return "bench ready" .. (#missing > 0 and (" (missing: " .. table.concat(missing, ", ") .. ")") or "")
