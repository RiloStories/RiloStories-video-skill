-- bootstrap_place.lua : run ONCE in the Edit datamodel of the place you will render from (Studio MCP execute_luau, Edit).
-- Creates everything the engine expects in an empty baseplate. Safe to re-run: it only adds what is missing.
--   ReplicatedStorage.Rilo            folder for the engine + story ModuleScripts (run.py fills them on every render)
--   ReplicatedStorage.R15Template     blocky R15 rig with a "face" decal (characters are clones of this)
--   ReplicatedStorage.PreviewRig      R6 rig (only for old R6 stories; harmless otherwise)
--   ReplicatedStorage.WardrobeRS      put hair / hat Accessories here, named e.g. hair_boy, hair_long, cop_hat, top_hat
--   ReplicatedStorage.RiloAssets      optional: your own prop / building Models (House_1.., Tree_1, Car, Dog ...)
--   StarterPlayer.StarterPlayerScripts.RiloDirector  LocalScript (source pushed by run.py)
local RS = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local made = {}

local function folder(name)
	local f = RS:FindFirstChild(name)
	if not f then f = Instance.new("Folder"); f.Name = name; f.Parent = RS; table.insert(made, name) end
	return f
end
folder("Rilo"); folder("WardrobeRS"); folder("RiloAssets")

local function rig(name, kind)
	if RS:FindFirstChild(name) then return end
	local desc = Instance.new("HumanoidDescription")
	desc.HeadColor = Color3.fromRGB(255, 204, 153); desc.TorsoColor = Color3.fromRGB(90, 140, 220)
	desc.LeftArmColor = desc.HeadColor; desc.RightArmColor = desc.HeadColor
	desc.LeftLegColor = Color3.fromRGB(50, 56, 84); desc.RightLegColor = desc.LeftLegColor
	local m = Players:CreateHumanoidModelFromDescription(desc, kind)
	m.Name = name
	local head = m:FindFirstChild("Head")
	if head and not head:FindFirstChild("face") then
		local d = Instance.new("Decal"); d.Name = "face"; d.Face = Enum.NormalId.Front
		d.Texture = "rbxasset://textures/face.png"; d.Parent = head
	end
	for _, s in ipairs(m:GetDescendants()) do if s:IsA("LuaSourceContainer") then s:Destroy() end end
	local hum = m:FindFirstChildOfClass("Humanoid")
	if hum then hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None end
	m.Parent = RS
	table.insert(made, name)
end
rig("R15Template", Enum.HumanoidRigType.R15)
rig("PreviewRig", Enum.HumanoidRigType.R6)

local sps = game:GetService("StarterPlayer"):WaitForChild("StarterPlayerScripts")
if not sps:FindFirstChild("RiloDirector") then
	local d = Instance.new("LocalScript"); d.Name = "RiloDirector"; d.Source = "-- filled by run.py"; d.Parent = sps
	table.insert(made, "RiloDirector")
end

-- a clean, bright default look; the engine sets its own lighting per shot
local L = game:GetService("Lighting")
L.GlobalShadows = true
-- real-Roblox look: Future lighting gives accurate shadows, reflections and light bleed (the single biggest upgrade).
-- Roblox blocks scripts from reading or setting Lighting.Technology, so the USER must set it once by hand:
-- Explorer > Lighting > Properties > Technology = Future. (Studio shows it as "Future" in the property list.)
pcall(function() L.ShadowSoftness = 0.2 end)
table.insert(made, "REMINDER: set Lighting.Technology = Future by hand in the Properties panel")
return "bootstrap ok; created: " .. (#made > 0 and table.concat(made, ", ") or "nothing (already set up)")
