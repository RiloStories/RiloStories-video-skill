-- Worked examples (tested): a sitting dog and a twin-bell alarm clock built with Kitbash, saved into RiloAssets.
-- Run via MCP execute_luau (Edit) AFTER run.py has synced the modules once (so ReplicatedStorage.Rilo.Kitbash exists),
-- or paste Kitbash.lua's body above this. Copy the pattern for any new prop: block out big shapes first, then 1-3 detail
-- parts that sell the idea (collar + tag, clock ticks), then ink eyes. Check it next to a character (asset_check.lua).
local KB = require(game:GetService("ReplicatedStorage").Rilo.Kitbash)
local V3, CF, P = Vector3.new, CFrame.new, KB.PAL
local rad = math.rad

-- DOG (sitting, ~3.2 studs tall, faces +Z)
local dog = KB.model("Dog_Kit")
local fur, dark, light = P.tan, Color3.fromRGB(120, 76, 44), P.cream
KB.part(dog, "Body", V3(1.6, 1.6, 2.0), CF(0, 1.2, -0.2) * CFrame.Angles(rad(-25), 0, 0), fur)
KB.part(dog, "Chest", V3(1.3, 1.0, 0.3), CF(0, 1.4, 0.65) * CFrame.Angles(rad(-25), 0, 0), light)
KB.part(dog, "Head", V3(1.5, 1.3, 1.3), CF(0, 2.55, 0.45), fur)
KB.part(dog, "Snout", V3(0.8, 0.55, 0.6), CF(0, 2.3, 1.35), light)
KB.part(dog, "Nose", V3(0.35, 0.25, 0.2), CF(0, 2.52, 1.68), P.ink)
KB.face(dog, 0, 2.75, 1.1, 0.38)
for _, s in ipairs({-1, 1}) do
	KB.part(dog, "Ear", V3(0.35, 0.9, 0.5), CF(s * 0.82, 2.45, 0.35) * CFrame.Angles(0, 0, rad(s * 12)), dark)
	KB.part(dog, "FrontLeg", V3(0.42, 1.2, 0.42), CF(s * 0.45, 0.6, 0.55), fur)
	KB.part(dog, "Paw", V3(0.5, 0.25, 0.6), CF(s * 0.45, 0.125, 0.65), light)
	KB.part(dog, "Haunch", V3(0.6, 0.8, 1.1), CF(s * 0.7, 0.45, -0.6), fur)
end
KB.part(dog, "Tail", V3(0.3, 0.3, 0.9), CF(0, 0.7, -1.45) * CFrame.Angles(rad(35), 0, 0), dark)   -- animate: rotate about its base
KB.part(dog, "Collar", V3(1.0, 0.2, 0.9), CF(0, 1.98, 0.5), P.red)
KB.ball(dog, "Tag", 0.22, CF(0, 1.82, 0.97), P.gold)
KB.finish(dog, true)

-- ALARM CLOCK (~2.9 studs, faces +Z)
local ck = KB.model("AlarmClock_Kit")
KB.disc(ck, "Body", 0.9, 2.0, CF(0, 1.35, 0), P.red)
KB.disc(ck, "Face", 0.12, 1.65, CF(0, 1.35, 0.46), P.white)
KB.part(ck, "HourHand", V3(0.12, 0.5, 0.06), CF(0, 1.55, 0.54), P.ink)
KB.part(ck, "MinHand", V3(0.62, 0.1, 0.06), CF(0.28, 1.35, 0.54), P.ink)
KB.ball(ck, "Pin", 0.16, CF(0, 1.35, 0.56), P.gold)
for _, s in ipairs({-1, 1}) do
	KB.ball(ck, "Bell", 0.8, CF(s * 0.62, 2.45, 0), P.gold)
	KB.part(ck, "Foot", V3(0.25, 0.4, 0.25), CF(s * 0.55, 0.2, 0) * CFrame.Angles(0, 0, rad(s * 18)), P.ink)
end
KB.part(ck, "Hammer", V3(0.12, 0.45, 0.12), CF(0, 2.5, 0), P.ink)
KB.part(ck, "Handle", V3(1.0, 0.14, 0.14), CF(0, 2.78, 0), P.ink)
for i = 0, 11 do
	local a = rad(i * 30)
	KB.part(ck, "Tick", V3(0.08, 0.16, 0.05), CF(math.sin(a) * 0.68, 1.35 + math.cos(a) * 0.68, 0.53) * CFrame.Angles(0, 0, -a), Color3.fromRGB(60, 60, 70))
end
KB.finish(ck, true)
return "saved Dog_Kit, AlarmClock_Kit to RiloAssets"
