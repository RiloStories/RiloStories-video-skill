-- ai_mesh_normalize.lua : make a Roblox AI mesh (generate_mesh) match the blocky cast. Tested pipeline.
-- Fill the CONFIG block, run via MCP execute_luau (Edit). Two passes:
--   PASS = "turntable" : puts 4 copies at yaw 0/90/180/270 in a row at x=30000 -> screen_capture
--                        camera [30000,3,11] look [30000,1.2,0]; pick the copy whose FACE points at the camera.
--   PASS = "finish"    : rotates by FRONT_YAW so the face points +Z, strips textures, recolours every segment from
--                        COLOURS (by part-name keyword), adds part-built ink eyes on the head, scales to HEIGHT,
--                        base on y=0, and saves to ReplicatedStorage.RiloAssets[NAME]. Then check it with asset_check.lua.
-- Generate with: segmentation="explicit" and partNames naming the moving parts (head, body, tail, legs...), so every
-- segment can be recoloured and animated. A single unsegmented mesh can't be recoloured per part (keep its texture or kitbash).
local CONFIG = {
	TAG = "Assistant-xxxxxxxx",          -- the `tag` returned by generate_mesh / wait_job_finished
	NAME = "Cat_AI", PASS = "turntable", FRONT_YAW = 180, HEIGHT = 2.4,
	COLOURS = {head = Color3.fromRGB(236, 140, 60), body = Color3.fromRGB(236, 140, 60), tail = Color3.fromRGB(200, 110, 44), leg = Color3.fromRGB(236, 140, 60)},
	DEFAULT = Color3.fromRGB(236, 140, 60), EYES = true, EYE_SPREAD = 0.24,
	KEEP_TEXTURE = false,                -- true = real-Roblox look: keep the generated texture/materials, only fix facing, scale and base
}
local CS = game:GetService("CollectionService")
local RS = game:GetService("ReplicatedStorage")
local src = CS:GetTagged(CONFIG.TAG)[1]
if not src then return "no instance with tag " .. CONFIG.TAG end
while src.Parent and src.Parent ~= workspace and not src.Parent:IsA("Folder") do src = src.Parent end
if not src:IsA("Model") then local m = Instance.new("Model"); m.Name = CONFIG.NAME; m.Parent = src.Parent; src.Parent = m; src = m end
for _, d in ipairs(src:GetDescendants()) do if d:IsA("BasePart") then d.Anchored = true; d.CanCollide = false end end
local function yawAboutCentre(m, deg)
	local cf = m:GetBoundingBox()
	m:PivotTo(CFrame.new(cf.Position) * CFrame.Angles(0, math.rad(deg), 0) * CFrame.new(cf.Position):Inverse() * m:GetPivot())
end
local function standAt(m, pos)
	local cf, sz = m:GetBoundingBox()
	m:PivotTo(m:GetPivot() + (Vector3.new(pos.X, pos.Y + sz.Y / 2, pos.Z) - cf.Position))
end
local _, sz0 = src:GetBoundingBox(); src:ScaleTo(src:GetScale() * CONFIG.HEIGHT / sz0.Y)

if CONFIG.PASS == "turntable" then
	local tt = workspace:FindFirstChild("RSS_Turntable"); if tt then tt:Destroy() end
	tt = Instance.new("Folder"); tt.Name = "RSS_Turntable"; tt.Parent = workspace
	local g = Instance.new("Part"); g.Anchored = true; g.Size = Vector3.new(30, 1, 20); g.Position = Vector3.new(30000, -0.5, 0); g.Color = Color3.fromRGB(110, 168, 96); g.Parent = tt
	for i, yaw in ipairs({0, 90, 180, 270}) do
		local c = src:Clone(); c.Name = "yaw" .. yaw; c.Parent = tt
		yawAboutCentre(c, yaw); standAt(c, Vector3.new(30000 + (i - 2.5) * 4, 0, 0))
	end
	return "turntable ready: left to right = yaw 0, 90, 180, 270. Capture, pick FRONT_YAW, delete workspace.RSS_Turntable after."
end

-- finish
local m = src:Clone(); m.Name = CONFIG.NAME
yawAboutCentre(m, CONFIG.FRONT_YAW)
local head
for _, p in ipairs(m:GetDescendants()) do
	if p:IsA("MeshPart") or p:IsA("Part") then
		local nm = p.Name:lower(); local col = CONFIG.DEFAULT
		if not CONFIG.KEEP_TEXTURE then
			pcall(function() p.TextureID = "" end)
			for _, sa in ipairs(p:GetChildren()) do if sa:IsA("SurfaceAppearance") then sa:Destroy() end end
			for k, c in pairs(CONFIG.COLOURS) do if nm:find(k, 1, true) then col = c end end
			p.Color = col; p.Material = Enum.Material.SmoothPlastic
		end
		if nm:find("head", 1, true) then head = p end
	end
end
m.Parent = workspace; standAt(m, Vector3.new(30000, 0, 30))
if CONFIG.EYES and head and not CONFIG.KEEP_TEXTURE then
	local rp = RaycastParams.new(); rp.FilterType = Enum.RaycastFilterType.Include; rp.FilterDescendantsInstances = {head}
	local hit = workspace:Raycast(head.Position + Vector3.new(0, 0.1, 6), Vector3.new(0, 0, -12), rp)
	local z = hit and hit.Position.Z or head.Position.Z + head.Size.Z / 2
	local function blk(dx, dy, s, col)
		local d = Instance.new("Part"); d.Name = "FaceDetail"; d.Anchored = true; d.CanCollide = false; d.Size = s; d.Color = col
		d.Material = Enum.Material.SmoothPlastic; d.CFrame = CFrame.new(head.Position.X + dx, head.Position.Y + dy, z + s.Z / 2 - 0.02); d.Parent = m
	end
	local u = head.Size.X / 1.1
	blk(-CONFIG.EYE_SPREAD * u, 0.12 * u, Vector3.new(0.16, 0.22, 0.06) * u, Color3.fromRGB(20, 20, 24))
	blk(CONFIG.EYE_SPREAD * u, 0.12 * u, Vector3.new(0.16, 0.22, 0.06) * u, Color3.fromRGB(20, 20, 24))
end
local cf, sz = m:GetBoundingBox()
local root = Instance.new("Part"); root.Name = "Root"; root.Size = Vector3.new(0.1, 0.1, 0.1); root.Transparency = 1; root.Anchored = true
root.CanCollide = false; root.CFrame = CFrame.new(cf.Position.X, cf.Position.Y - sz.Y / 2, cf.Position.Z); root.Parent = m; m.PrimaryPart = root
local lib = RS:FindFirstChild("RiloAssets") or Instance.new("Folder", RS); lib.Name = "RiloAssets"
local old = lib:FindFirstChild(CONFIG.NAME); if old then old:Destroy() end
m:PivotTo(CFrame.new()); m.Parent = lib
src:Destroy()
local tt = workspace:FindFirstChild("RSS_Turntable"); if tt then tt:Destroy() end
return "saved RiloAssets." .. CONFIG.NAME .. " (front +Z, base y=0). Now run asset_check.lua."
